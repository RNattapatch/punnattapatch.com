# Tested with

หลักฐานชุดนี้บันทึกจาก Delivery V2.0.4 เมื่อวันที่ 14 กันยายน 2026 ค่า SHA-256 ของ ZIP อยู่ในไฟล์ `.sha256.txt` ข้างแต่ละ ZIP เพื่อไม่ให้ archive อ้าง hash ของตัวเอง

## Runtime

- Node.js 24.14.1; minimum supported version 20
- macOS Darwin 24.6.0
- Node.js standard library only; no package install and no `node_modules`
- Launchers included for macOS and Windows
- Windows command selection, launcher guards and foreign-port protection verified by automated tests; a physical Windows machine was not used in this release cycle, so smoke-test `Open Workspace.bat` on one real Windows machine before a classroom that uses Windows
- macOS launcher verified by running it with `PATH` stripped to `/usr/bin:/bin`: the login shell still found Node and the workspace started; with no Node reachable it printed the Thai instructions and waited for Enter instead of closing

## Automated verification

- Source suite: 144/144 tests passed
- Reproducible package: unchanged source bytes produce the same ZIP SHA-256 even when file timestamps differ
- Package clean-room suite: 129/129 tests passed in an extracted ZIP
- Parity manifest: 525/525 checks passed
- Golden gate: 26/26 passed, counted as Golden Path 18 steps plus Definition of Ready 8 checks (`install` reports the combined 26/26)
- Launcher scripts: automated checks on the login-shell shebang, the Node fallback list, the Node 20 floor, a pause on every exit path, the executable bit that survives the archive, and CRLF line endings in the Windows file
- Detached launch: an agent-style `node tools/launch.mjs --detach` returned in about one second, the workspace kept serving after the parent process exited, a second call reported `WORKSPACE_ALREADY_RUNNING`, and a port that never answers is reported as a failure instead of success
- Agent skills: Claude Code and Codex copies are byte-equivalent
- Unified worker: queued Content and Intel work is discovered from the same local tables; the Queue copies a self-contained handoff with the exact extracted workspace, job ID, Claude Code `/worker`, and Codex `$worker`
- Queue-state safety: queued jobs expose only the Worker action; Retry and Agent Repair appear only for real failure states, so a queued job can no longer create a false repair request
- Scout lifecycle: claim, explicit evidence request, atomic completion rollback, staging boundary, media path/existence/size checks and terminal-state protection passed
- Scout intake: public URLs, supported workspace image/video, pasted evidence and advertiser queries classify without network access; private/credential/unsupported URLs are rejected
- Install portability: `DELIVERY-STATUS.json` stores `snapshots/starter-v1` as a relative path and does not expose the workstation path
- Credential scan: no credential pattern found in the delivery workspace
- RSS transport: HTTPS-only, public-address validation on every redirect, DNS pinning against rebinding and a 5 MB response limit
- Source readiness: Company Doctor fetched and parsed both example feeds; an injected 404/non-feed source failed delivery as designed
- Demo freshness: a future-dated rehearsal fetched 3 local feeds, inserted 3 current stories, wrote 3 briefs, materialized the example script and exposed 3 local Intel evidence pages
- Local secret file: Company config is tightened to owner-only permission after every browser write on supported filesystems
- Snapshot recovery: manifest, unlisted-file rejection, corrupt-snapshot refusal, rollback and byte-for-byte restore passed
- Update safety: the packaged updater migrated the V2.0.3 Client ZIP to V2.0.4 while preserving `company/`, `data/`, `wiki/` and `output/` byte-for-byte; an injected Company Doctor failure restored every system path and all four customer-owned roots to V2.0.3
- Update packaging: repeated builds produced identical ZIP bytes; the archive contains both launchers and the full system payload, excludes all customer-owned roots, and refuses any source version except V2.0.4

## Browser QA

Codex in-app browser QA covered five product routes at viewport widths 375, 768 and 1440 pixels, plus the complete Intel Worker bridge flow.

- Content Center
- News Desk
- Intel Room
- Jobs
- Settings

All 75 browser assertions passed. The 60-route matrix confirmed the product mark, H1, white canvas and no document overflow on all five routes at all three viewports. The 15 Worker-bridge checks confirmed the exact workspace path, both platform commands, job-specific clipboard handoff, queued-versus-failed action boundary, native button semantics, visible keyboard focus, responsive stacking and no console warnings or errors. Screenshots and the machine-readable report are stored outside the customer ZIP under `output/web-app/marketing-warroom-os-delivery-v2.0.4-classroom/qa-screenshots/` and `browser-worker-bridge-qa.json`.

## Package evidence

- Master archive: `dist/marketing-warroom-os-delivery-v2.0.4.zip`; exact SHA-256 is in the adjacent `.sha256.txt`
- Classroom Client Edition: `marketing-warroom-os-delivery-v2.0.4-marketing-warroom-os.zip`; exact SHA-256 is in the adjacent `.sha256.txt`
- Existing-user update: `marketing-warroom-os-update-v2.0.4-from-v2.0.3.zip`; exact SHA-256 is in the adjacent `.sha256.txt`
- Master and Client archives passed `unzip -tq`; both agent skill trees are byte-identical

## Recovery drill

The extracted Client Edition passed this full drill:

1. Start Demo Mode.
2. Stop Demo Mode.
3. Confirm the managed workspace hash returned byte-for-byte.
4. Corrupt a Company file deliberately.
5. Restore from the immutable `starter-v1` snapshot.
6. Run Company Doctor successfully.

## Re-run commands

Run from the workspace root:

```bash
node tools/build-kit.mjs
find app tools -type f \( -name '*.mjs' -o -name '*.js' \) -print0 | xargs -0 -n1 node --check
node --test tools/*.test.mjs
node tools/parity-check.mjs
node tools/golden-check.mjs
node tools/doctor.mjs --preflight
node tools/doctor.mjs --demo
```

For a clientized workspace, also run:

```bash
node tools/doctor.mjs --company
```
