# Security review

**Reviewed:** 2026-09-14  
**Scope:** Marketing Warroom OS Delivery V2 2.0.4  
**Standard used:** OWASP Top 10, CWE Top 25, PDPA-first handling and dev-level ISO 27001 control mapping

## Controls in this edition

| Area | Control |
|---|---|
| Network | HTTP server binds only to `127.0.0.1:4173`; Host header accepts only loopback names |
| Browser writes | POST, PUT, PATCH and DELETE with an Origin require the exact local origin |
| Input | JSON routes require `application/json`; request body limit is 1 MB |
| Company files | Fixed allowlist; Markdown and config use separate content-type allowlists |
| Filesystem | API and restore paths are resolved under fixed workspace roots; snapshot names cannot contain separators |
| RSS | HTTPS only; localhost, private/link-local IPs and private redirect targets are rejected; requests stay pinned to the validated DNS result; response body is capped at 5 MB |
| Feed readiness | Company Doctor fetches and parses every active RSS/Atom source; URL shape alone cannot pass delivery |
| Demo web | Intel fixture pages are served from a fixed three-slug allowlist; arbitrary file paths are not routable |
| Scout URL intake | Pure classification rejects credentials, unsupported protocols, localhost, private/link-local addresses and oversized input; the local server never fetches submitted URLs |
| Scout staging | CLI reads JSON only below `output/scout-staging/`, capped at 1 MB |
| Scout media | Completion accepts published files only below `data/files/newsroom/`, rejects traversal/missing files and caps each file at 100 MB |
| Meta Ads | Connector access is read-only through `ads_library_search`; browser automation and opening ad snapshot links are prohibited |
| Recovery | SHA-256 per file, immutable `starter-v1`, pre-restore backup and rollback after failed Doctor |
| Secrets | Package gate rejects non-empty `kie_api_key` and common credential/private-key patterns |
| Local secret file | Company config is reset to owner-only permission after every write on supported filesystems |
| External actions | No auto-post and no browser automation on Facebook or Instagram |
| Agent worker | Claude Code `/worker` or Codex `$worker` is one on-demand pass with explicit claim/complete/evidence-request states; copied prompts include only the local workspace path and do not spawn a nested AI CLI or store provider tokens |
| Usage data | No remote telemetry; optional Local usage log stays on the same machine |

## Data handling

Company files and operating data remain in the extracted workspace. AI prompts and attachments are processed through the company's Claude Code or Codex account, so the operator must remove unnecessary PII before sending work to the agent.

This is a local business tool. The review does not claim legal certification, penetration-test certification or ISO certification. Reassess before adding hosting, shared accounts, remote APIs, social tokens or automated publishing.
