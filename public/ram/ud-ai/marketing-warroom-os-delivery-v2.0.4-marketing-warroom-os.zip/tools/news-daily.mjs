import { createHash } from 'node:crypto';
import { lookup as dnsLookup } from 'node:dns/promises';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import https from 'node:https';
import net from 'node:net';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

import { parseFeed } from '../app/lib/rss.mjs';
import { createStore } from '../app/store.mjs';
import { writeJsonAtomic } from './delivery-state.mjs';

const USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36';
const TIMEOUT_MS = 15_000;
const MAX_REDIRECTS = 3;
const MAX_RESPONSE_BYTES = 5_000_000;
const MAX_AGE_MS = 7 * 86_400_000;

function hash(value) {
  return createHash('sha256').update(String(value)).digest('hex');
}

function plainText(value = '') {
  return String(value)
    .replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<\/(p|div|br|li|h[1-6]|tr)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/[ \t]+/g, ' ')
    .replace(/\n\s*\n+/g, '\n\n')
    .trim();
}

function sourceHost(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); }
  catch { return ''; }
}

function publishedThai(iso) {
  if (!iso) return '';
  const months = ['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
  const date = new Date(new Date(iso).getTime() + 7 * 3_600_000);
  return `${months[date.getUTCMonth()]} ${date.getUTCFullYear()}`;
}

function privateIpv4(address) {
  const parts = address.split('.').map(Number);
  return parts[0] === 0 || parts[0] === 10 || parts[0] === 127 ||
    (parts[0] === 169 && parts[1] === 254) ||
    (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) ||
    (parts[0] === 192 && parts[1] === 168) ||
    (parts[0] === 100 && parts[1] >= 64 && parts[1] <= 127) ||
    parts[0] >= 224;
}

function privateIp(address) {
  if (net.isIPv4(address)) return privateIpv4(address);
  if (!net.isIPv6(address)) return true;
  const normalized = address.toLowerCase();
  if (normalized === '::' || normalized === '::1') return true;
  const mapped = normalized.match(/^::ffff:(.+)$/)?.[1];
  if (mapped) {
    if (net.isIPv4(mapped)) return privateIpv4(mapped);
    const words = mapped.split(':').map((word) => Number.parseInt(word, 16));
    if (words.length === 2 && words.every(Number.isInteger)) {
      return privateIpv4(`${words[0] >> 8}.${words[0] & 255}.${words[1] >> 8}.${words[1] & 255}`);
    }
    return true;
  }
  return normalized.startsWith('fc') || normalized.startsWith('fd') || /^fe[89ab]/.test(normalized) || normalized.startsWith('ff');
}

async function resolvePublicHttpsUrl(url, { lookup = dnsLookup } = {}) {
  const target = new URL(url);
  if (target.protocol !== 'https:') throw new Error(`HTTPS required: ${target.protocol}`);
  const hostname = target.hostname.replace(/^\[|\]$/g, '').toLowerCase();
  if (hostname === 'localhost' || hostname.endsWith('.localhost') || hostname.endsWith('.local')) throw new Error('RSS target must be public, not local');
  const literalFamily = net.isIP(hostname);
  const addresses = literalFamily ? [{ address: hostname, family: literalFamily }] : await lookup(hostname, { all: true, verbatim: true });
  if (!Array.isArray(addresses) || addresses.length === 0 || addresses.some((entry) => privateIp(entry.address))) {
    throw new Error('RSS target resolves to a private or non-public address');
  }
  return { target, addresses };
}

export async function assertPublicHttpsUrl(url, options = {}) {
  return (await resolvePublicHttpsUrl(url, options)).target;
}

function pinnedLookup(addresses) {
  return (_hostname, options, callback) => {
    if (typeof options === 'function') {
      callback = options;
      options = {};
    }
    const requestedFamily = Number(options?.family || 0);
    const eligible = requestedFamily ? addresses.filter((entry) => entry.family === requestedFamily) : addresses;
    if (!eligible.length) {
      queueMicrotask(() => callback(new Error(`No validated IPv${requestedFamily} address`)));
      return;
    }
    if (options?.all) queueMicrotask(() => callback(null, eligible));
    else queueMicrotask(() => callback(null, eligible[0].address, eligible[0].family));
  };
}

export async function fetchHttpsText(url, { request = https.get, lookup = dnsLookup, timeoutMs = TIMEOUT_MS, maxRedirects = MAX_REDIRECTS, maxBytes = MAX_RESPONSE_BYTES, redirects = 0 } = {}) {
  const { target, addresses } = await resolvePublicHttpsUrl(url, { lookup });
  return new Promise((resolve, reject) => {
    const req = request(target, { lookup: pinnedLookup(addresses), headers: { 'User-Agent': USER_AGENT, Accept: 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*' } }, (response) => {
      const status = Number(response.statusCode || 0);
      if (status >= 300 && status < 400 && response.headers.location) {
        response.resume();
        if (redirects >= maxRedirects) {
          reject(new Error(`RSS redirect limit exceeded (${maxRedirects})`));
          return;
        }
        const next = new URL(response.headers.location, target).href;
        fetchHttpsText(next, { request, lookup, timeoutMs, maxRedirects, maxBytes, redirects: redirects + 1 }).then(resolve, reject);
        return;
      }
      if (status < 200 || status >= 300) {
        response.resume();
        reject(new Error(`RSS HTTP ${status || 'unknown'}`));
        return;
      }
      response.setEncoding('utf8');
      let body = '';
      let bytes = 0;
      response.on('data', (chunk) => {
        bytes += Buffer.byteLength(chunk);
        if (bytes > maxBytes) {
          response.destroy();
          reject(new Error(`RSS response exceeds ${maxBytes} bytes`));
          return;
        }
        body += chunk;
      });
      response.on('end', () => resolve(body));
      response.on('error', reject);
    });
    req.setTimeout(timeoutMs, () => req.destroy(new Error(`RSS timeout after ${timeoutMs} ms`)));
    req.on('error', reject);
  });
}

function fixtureName(sourceUrl) {
  try { return path.basename(new URL(sourceUrl).pathname); }
  catch { return path.basename(sourceUrl); }
}

async function sourceXml({ rootDir, fixturesDir, source, fetchText }) {
  if (fixturesDir) return readFile(path.join(fixturesDir, fixtureName(source.url)), 'utf8');
  if (String(source.url).startsWith('output/demo/rss/')) {
    const demoRoot = path.resolve(rootDir, 'output/demo/rss');
    const target = path.resolve(rootDir, source.url);
    if (!target.startsWith(`${demoRoot}${path.sep}`) || path.extname(target).toLowerCase() !== '.xml') {
      throw new Error('Demo RSS path is outside output/demo/rss');
    }
    return readFile(target, 'utf8');
  }
  return fetchText(source.url);
}

async function writeBrief(briefOutDir, news, source, body) {
  const brief = {
    news_item_id: news.id,
    title: news.title,
    url: news.url,
    source_host: sourceHost(news.url),
    topic: source.topic || null,
    tags: source.tags || [],
    published_at: news.published_at,
    published_th: publishedThai(news.published_at),
    summary: news.summary,
    body,
    body_source: 'rss',
    avoid_light: [],
    fetch_errors: []
  };
  await mkdir(briefOutDir, { recursive: true });
  const target = path.join(briefOutDir, `${news.id}.brief.json`);
  await writeFile(target, `${JSON.stringify(brief, null, 2)}\n`, { mode: 0o600 });
  return target;
}

export async function runNewsDaily({
  rootDir = path.resolve(import.meta.dirname, '..'),
  fixturesDir = null,
  briefOutDir = path.join(rootDir, 'output/content/news-briefs'),
  now = new Date(),
  fetchText = fetchHttpsText
} = {}) {
  const store = createStore({ rootDir });
  const sources = (await store.read('ca_sources')).items.filter((entry) => entry.active);
  const collected = [];
  const errors = [];
  let fetched = 0;

  for (const source of sources) {
    try {
      const xml = await sourceXml({ rootDir, fixturesDir, source, fetchText });
      const items = parseFeed(xml);
      if (!items.length) throw new Error('RSS/Atom ไม่พบรายการข่าว');
      fetched += items.length;
      for (const feedItem of items) collected.push({ source, feedItem });
    } catch (error) {
      errors.push({ source_id: source.id, url: source.url, error: error.message });
    }
  }

  const existing = await store.read('ca_news_items');
  const urls = new Set(existing.items.map((entry) => entry.url));
  const hashes = new Set(existing.items.map((entry) => entry.content_hash));
  let inserted = 0;
  let briefs = 0;
  const briefFiles = [];

  for (const { source, feedItem } of collected) {
    const published = feedItem.publishedAt ? new Date(feedItem.publishedAt) : null;
    if (published && Number.isFinite(published.getTime()) && now.getTime() - published.getTime() > MAX_AGE_MS) continue;
    const body = plainText(feedItem.content);
    const contentHash = hash(`${feedItem.title}\n${body}`);
    if (urls.has(feedItem.link) || hashes.has(contentHash)) continue;
    const news = {
      id: `NEWS-${hash(feedItem.link).slice(0, 12)}`,
      source_id: source.id,
      url: feedItem.link,
      title: feedItem.title,
      summary: body,
      published_at: feedItem.publishedAt || now.toISOString(),
      fetched_at: now.toISOString(),
      status: 'new',
      content_hash: contentHash
    };
    await store.create('ca_news_items', news);
    const briefFile = await writeBrief(briefOutDir, news, source, body);
    urls.add(news.url);
    hashes.add(contentHash);
    inserted += 1;
    briefs += 1;
    briefFiles.push(path.relative(rootDir, briefFile));
  }

  const summary = { sources: sources.length, fetched, inserted, briefs, brief_files: briefFiles, errors };
  await writeJsonAtomic(path.join(rootDir, 'data/.news-daily-run.json'), { ran_at: now.toISOString(), ...summary });
  return summary;
}

function valueAfter(flag) {
  const index = process.argv.indexOf(flag);
  return index >= 0 && process.argv[index + 1] ? process.argv[index + 1] : null;
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  const briefOut = valueAfter('--brief-out');
  if (!briefOut) {
    process.stderr.write('usage: node tools/news-daily.mjs --brief-out <directory> [--fixtures <directory>]\n');
    process.exitCode = 2;
  } else {
    const fixtures = valueAfter('--fixtures');
    const summary = await runNewsDaily({
      fixturesDir: fixtures ? path.resolve(fixtures) : null,
      briefOutDir: path.resolve(briefOut)
    });
    process.stdout.write(`${JSON.stringify(summary, null, 2)}\n`);
  }
}
