import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const MAX_EMDASH_IN_HOOKS = 3;
const MAX_NEGATIVE_PARALLEL = 1;
const HOOK_LENGTH = Object.freeze({ softMin: 90, softMax: 160, hardMin: 80, hardMax: 175 });
const OPENING_SIGNATURE = 12;
const COMMENT_ROLES = Object.freeze(['cta', 'article', 'source', 'angle2', 'cases']);
const OLD_TEMPLATE_OPENERS = Object.freeze(['ไม่ใช่แค่', 'หลายคนยังไม่รู้', 'ข่าวนี้ดูเหมือน', 'คนส่วนใหญ่อ่านข่าว', 'ระหว่างที่ยัง', 'ลองดูว่า', 'ไม่ต้องเดาแล้ว']);
const BANNED = Object.freeze([
  'สิ่งที่น่าสนใจคือ', 'ที่น่าสนใจคือ', 'ซึ่งสะท้อนให้เห็น', 'ซึ่งตอกย้ำ', 'ซึ่งแสดงให้เห็นถึง',
  'โดยสรุป', 'สรุปแล้ว', 'ก้าวสำคัญ', 'จุดเปลี่ยนสำคัญ', 'ทำหน้าที่เป็น', 'ผู้เชี่ยวชาญระบุ',
  'หลายการศึกษา', 'ในยุคที่', 'ในโลกที่', 'อย่างไรก็ตาม', 'ตอบโจทย์ทุกความต้องการ', 'ครอบคลุมทุกมิติ',
  'ครอบคลุมทุกด้าน', 'มุ่งมั่นในการ', 'เป็นมากกว่าแค่', 'ขับเคลื่อนการเติบโต', 'ขับเคลื่อนความสำเร็จ',
  'สร้างความแตกต่าง', 'เป็นสัญญาณที่ชัดเจนว่า', 'สะท้อนให้เห็นถึงความสำคัญ', 'เป็นที่ยอมรับว่า',
  'ลองนึกภาพว่า', 'เปลี่ยนแปลงครั้งสำคัญ'
]);
const NEGATIVE_PARALLEL = /ไม่(?:ใช่|ได้)[^.。\n]{0,60}?แต่/g;
const EMOJI = /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/u;
const CURLY_QUOTES = /[“”‘’]/;

function count(value, expression) {
  return (String(value).match(expression) || []).length;
}

function textWithoutSources(candidate) {
  const parts = [candidate.article_md || '', candidate.glance_line || ''];
  for (const hook of candidate.hooks || []) parts.push(hook.text || '');
  for (const comment of candidate.comment_thread || []) if (comment.role !== 'source') parts.push(comment.text || '');
  return parts.join('\n');
}

export function forbiddenWordsFromVoice(voiceText = '') {
  const line = String(voiceText).match(/^\s*-\s*Forbidden words:\s*(.*)$/im)?.[1] || '';
  return line.split(',').map((word) => word.trim()).filter(Boolean);
}

export function materializeCandidateFixture(entry) {
  if (!Array.isArray(entry.article_lines) || entry.article_md != null) return entry;
  const article = entry.article_lines.join('\n');
  return {
    ...entry,
    article_md: article,
    comment_thread: (entry.comment_thread || []).map((comment) => ({ ...comment, text: comment.text === '$article_md' ? article : comment.text }))
  };
}

export function lintCandidates(candidates, { voiceText = '' } = {}) {
  const red = [];
  const yellow = [];
  const batchOpenings = new Map();
  const companyBanned = forbiddenWordsFromVoice(voiceText);

  for (const candidate of candidates) {
    const label = candidate.id || 'candidate';
    const hooks = candidate.hooks || [];
    const allText = textWithoutSources(candidate);
    if (hooks.length !== 12) red.push(`${label}: hooks ต้องมี 12 มุม`);

    const ownOpenings = new Map();
    let emDashCount = 0;
    for (const hook of hooks) {
      const text = String(hook.text || '').trim();
      const where = `${label}: hook#${hook.id || '?'}`;
      const length = [...text].length;
      const opening = [...text].slice(0, OPENING_SIGNATURE).join('');
      if (!text) red.push(`${where} ว่าง`);
      if (text && (length < HOOK_LENGTH.hardMin || length > HOOK_LENGTH.hardMax)) red.push(`${where} ยาว ${length} ตัวอักษร (นอกกรอบ ${HOOK_LENGTH.hardMin}-${HOOK_LENGTH.hardMax})`);
      else if (text && (length < HOOK_LENGTH.softMin || length > HOOK_LENGTH.softMax)) yellow.push(`${where} ยาว ${length} ตัวอักษร (เป้า ${HOOK_LENGTH.softMin}-${HOOK_LENGTH.softMax})`);
      if (EMOJI.test(text)) red.push(`${where} มี emoji`);
      if (CURLY_QUOTES.test(text)) yellow.push(`${where} มีอัญประกาศโค้ง`);
      const oldOpener = OLD_TEMPLATE_OPENERS.find((value) => text.startsWith(value));
      if (oldOpener) red.push(`${where} ขึ้นต้นด้วยแม่พิมพ์เก่า “${oldOpener}”`);
      emDashCount += count(text, /—/g);
      if (opening) {
        ownOpenings.set(opening, [...(ownOpenings.get(opening) || []), hook.id || '?']);
        batchOpenings.set(opening, [...(batchOpenings.get(opening) || []), `${label}#${hook.id || '?'}`]);
      }
    }
    if (emDashCount > MAX_EMDASH_IN_HOOKS) red.push(`${label}: hooks มี em-dash ${emDashCount} อัน (เพดาน ${MAX_EMDASH_IN_HOOKS})`);
    for (const [opening, ids] of ownOpenings) {
      if (ids.length >= 2) (ids.length >= 3 ? red : yellow).push(`${label}: hook ${ids.join(',')} ขึ้นต้นเหมือนกัน “${opening}…”`);
    }
    if (hooks.length >= 8 && hooks.filter((hook) => /[?？]/.test(hook.text || '')).length === 0) yellow.push(`${label}: ไม่มี hook ที่เป็นคำถามเลย`);

    const negativeCount = count(allText, NEGATIVE_PARALLEL);
    if (negativeCount > MAX_NEGATIVE_PARALLEL) yellow.push(`${label}: โครง "ไม่ใช่ X แต่ Y" ${negativeCount} ครั้ง (เพดาน ${MAX_NEGATIVE_PARALLEL})`);
    for (const phrase of BANNED) if (allText.includes(phrase)) red.push(`${label}: เจอคำ/วลีต้องห้าม “${phrase}”`);
    for (const phrase of companyBanned) if (allText.includes(phrase)) red.push(`${label}: เจอ “${phrase}” จาก company/voice.md`);

    const article = String(candidate.edited_article_md || candidate.article_md || '');
    const thai = [...article].filter((character) => /[\u0E00-\u0E7F]/.test(character)).length;
    const pins = count(article, /📍/g);
    if (thai < 1_200) red.push(`${label}: บทความสั้นกว่ากรอบมาก (ได้ ${thai} ตัวอักษรไทย)`);
    else if (thai < 1_500 || thai > 2_100) yellow.push(`${label}: บทความได้ ${thai} ตัวอักษรไทย (เป้า 1,500–2,000)`);
    if (pins < 3 || pins > 4) yellow.push(`${label}: ต้องมี 📍 3–4 จุด (ได้ ${pins})`);
    const longLines = article.split('\n').filter((line) => line.trim() && !line.trim().startsWith('📍') && [...line.trim()].length > 48).length;
    if (longLines) red.push(`${label}: บรรทัดยาวเกิน 48 ตัวอักษร ${longLines} บรรทัด`);
    if (/\*\*|^#{1,6}\s|^>\s|`|\]\(/m.test(article)) red.push(`${label}: มี Markdown ค้างในบทความ`);
    if (/https?:\/\//.test(article)) red.push(`${label}: มี URL ในบทความ`);
    if (/^(สิ่งที่น่าสนใจ|ที่น่าสนใจ|ประเด็นคือ)/m.test(article)) red.push(`${label}: เปิดย่อหน้าด้วยสูตรเดิม`);
    if (/ปัญหาไม่ได้อยู่ที่[^\n]{0,40}(?:มัน)?อยู่ที่/.test(article)) red.push(`${label}: ปิดด้วยสูตรปฏิเสธสำเร็จรูป`);

    const glance = String(candidate.glance_line || '').trim();
    const glanceLength = [...glance].length;
    if (glanceLength > 60) red.push(`${label}: glance_line ยาว ${glanceLength} ตัวอักษร (เพดาน 60)`);
    else if (glanceLength > 44) yellow.push(`${label}: glance_line ยาว ${glanceLength} ตัวอักษร (เป้าไม่เกิน 44)`);
    if (glance && !/\[\[.+\]\]/.test(glance)) yellow.push(`${label}: glance_line ไม่มี [[คำเน้น]]`);
    if (EMOJI.test(glance)) red.push(`${label}: glance_line มี emoji`);

    const roles = (candidate.comment_thread || []).map((comment) => comment.role);
    if (roles.join(',') !== COMMENT_ROLES.join(',')) red.push(`${label}: comment_thread ต้องเรียง ${COMMENT_ROLES.join(',')} (ได้ ${roles.join(',') || 'ว่าง'})`);
    const articleComment = (candidate.comment_thread || []).find((comment) => comment.role === 'article')?.text;
    if (articleComment != null && articleComment.trim() !== article.trim()) red.push(`${label}: comment_thread role article ไม่ตรงกับ article_md`);
  }

  for (const [opening, locations] of batchOpenings) {
    const candidatesForOpening = new Set(locations.map((location) => location.split('#')[0]));
    if (candidatesForOpening.size >= 2) red.push(`hook เปิดซ้ำ “${opening}…” ข้ามข่าว ${locations.join(', ')}`);
  }
  return { ok: red.length === 0, red, yellow };
}

async function cli() {
  const args = process.argv.slice(2);
  let voiceFile = path.resolve(import.meta.dirname, '../company/voice.md');
  const files = [];
  for (let index = 0; index < args.length; index += 1) {
    if (args[index] === '--voice') {
      if (!args[index + 1]) throw new Error('--voice requires a file path');
      voiceFile = args[index + 1];
      index += 1;
    } else files.push(args[index]);
  }
  if (!files.length) {
    process.stderr.write('usage: node tools/lint-copy.mjs <candidate.json ...> [--voice company/voice.md]\n');
    process.exitCode = 2;
    return;
  }
  const candidates = [];
  for (const file of files) {
    const parsed = JSON.parse(await readFile(path.resolve(file), 'utf8'));
    const entries = Array.isArray(parsed) ? parsed : Array.isArray(parsed.items) ? parsed.items : [parsed];
    candidates.push(...entries.map(materializeCandidateFixture));
  }
  const voiceText = await readFile(path.resolve(voiceFile), 'utf8');
  const result = lintCandidates(candidates, { voiceText });
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
  process.exitCode = result.ok ? 0 : 1;
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) await cli();
