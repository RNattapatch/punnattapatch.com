import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const rootDir = path.resolve(import.meta.dirname, '..');

async function walk(dir) {
  const found = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const target = path.join(dir, entry.name);
    if (entry.isDirectory()) found.push(...await walk(target));
    else if (/\.(html|mjs)$/.test(entry.name)) found.push(target);
  }
  return found;
}

export async function checkParity({ root = rootDir } = {}) {
  const manifest = JSON.parse(await readFile(path.join(root, 'spec/parity-manifest.json'), 'utf8'));
  const source = (await Promise.all((await walk(path.join(root, 'app'))).map((file) => readFile(file, 'utf8')))).join('\n');
  const missing = [];
  let count = 0;
  for (const [page, contract] of Object.entries(manifest.pages)) {
    for (const value of [...(contract.ids || []), ...(contract.selectors || [])]) {
      count += 1;
      const id = value.match(/^#([\w-]+)$/)?.[1];
      const attribute = value.match(/^\[([\w-]+)(?:=([^\]]+))?\]$/);
      let found = source.includes(value);
      if (id) found ||= source.includes(`id="${id}"`) || source.includes(`id='${id}'`);
      if (attribute) {
        const name = attribute[1]; const wanted = attribute[2]?.replace(/^['"]|['"]$/g, '');
        found ||= (source.includes(`${name}=`) || source.includes(`${name} `)) && (!wanted || source.includes(wanted));
      }
      if (!found) missing.push({ page, value });
    }
    const enumValues = Object.values(contract.enums || {}).flatMap((values) => Array.isArray(values) ? values : Object.values(values));
    for (const value of [...(contract.tabs || []), ...(contract.labels || []), ...enumValues]) {
      count += 1;
      if (!source.includes(value)) missing.push({ page, value });
    }
  }
  return { ok: missing.length === 0, count, missing };
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  const output = await checkParity();
  process.stdout.write(`${output.ok ? '✅' : '❌'} parity ${output.count - output.missing.length}/${output.count}\n`);
  for (const item of output.missing) process.stdout.write(`- ${item.page}: ${item.value}\n`);
  process.exitCode = output.ok ? 0 : 1;
}
