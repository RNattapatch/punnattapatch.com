import assert from 'node:assert/strict';
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

import { TABLES, createStore } from '../app/store.mjs';
import { claimScoutJob, completeScoutJob, requestScoutEvidence } from './scout-job.mjs';

async function workspace(t) {
  const rootDir = await mkdtemp(path.join(os.tmpdir(), 'warroom-scout-job-'));
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  await mkdir(path.join(rootDir, 'data/files/newsroom'), { recursive: true });
  for (const table of TABLES) await writeFile(path.join(rootDir, 'data', `${table}.json`), '{"version":1,"items":[]}\n');
  return rootDir;
}

function queuedJob(id = 'NJ-1', status = 'queued') {
  return { id, kind: 'web', target: 'https://example.com', note: '', status, scout_job_id: null, item_id: null, error: null, created_at: '2026-09-13T00:00:00.000Z', updated_at: '2026-09-13T00:00:00.000Z', target_id: 'unassigned', batch_id: 'BATCH-1', lane: 'web', result: { capability_mode: 'pending', source_type: 'public-web', requested_media: ['page-html'] }, attempts: 0 };
}

function libraryItem(id = 'NR-1', media = []) {
  return { id, job_id: 'wrong-value', kind: 'web', platform: 'web', source_url: 'https://example.com', title: 'Example evidence', channel: 'example.com', summary: 'Public fixture summary', verdict: 'watch', score: 70, views: 0, duration_s: 0, cover_path: null, media, report_md: '# Report', report_path: 'wiki/intel/scout/example.md', tags: ['fixture'], scraped_at: '2026-09-13T01:00:00.000Z', created_at: '2026-09-13T01:00:00.000Z', target_id: 'unassigned' };
}

test('claim moves one queued job to running and increments attempts', async (t) => {
  const rootDir = await workspace(t); const store = createStore({ rootDir });
  await store.create('newsroom_jobs', queuedJob());
  const claimed = await claimScoutJob({ rootDir, now: '2026-09-13T01:00:00.000Z' });
  assert.equal(claimed.status, 'running');
  assert.equal(claimed.attempts, 1);
  assert.equal(claimed.updated_at, '2026-09-13T01:00:00.000Z');
  assert.equal((await store.read('newsroom_jobs')).items[0].status, 'running');
});

test('evidence request ends as preflight_failed with an explicit next action', async (t) => {
  const rootDir = await workspace(t); const store = createStore({ rootDir });
  await store.create('newsroom_jobs', queuedJob('NJ-EVIDENCE', 'running'));
  const job = await requestScoutEvidence({ rootDir, jobId: 'NJ-EVIDENCE', reason: 'Meta connector ไม่มี creative bytes', nextAction: 'แนบ screenshot หรือวิดีโอของแอดใน output/scout-staging/', sourceUrl: 'https://www.facebook.com/ads/library/', now: '2026-09-13T01:00:00.000Z' });
  assert.equal(job.status, 'preflight_failed');
  assert.equal(job.result.capability_mode, 'manual-evidence');
  assert.equal(job.result.next_action, 'แนบ screenshot หรือวิดีโอของแอดใน output/scout-staging/');
  assert.equal(job.result.source_url, 'https://www.facebook.com/ads/library/');
});

test('completion atomically adds one library item and links its id to the job', async (t) => {
  const rootDir = await workspace(t); const store = createStore({ rootDir });
  await store.create('newsroom_jobs', queuedJob('NJ-DONE', 'running'));
  const completed = await completeScoutJob({ rootDir, jobId: 'NJ-DONE', item: libraryItem('NR-DONE'), capabilityMode: 'public-web', now: '2026-09-13T01:00:00.000Z' });
  assert.equal(completed.item.job_id, 'NJ-DONE');
  assert.equal(completed.job.status, 'done');
  assert.equal(completed.job.item_id, 'NR-DONE');
  assert.equal(completed.job.result.item_id, 'NR-DONE');
  assert.equal((await store.read('newsroom_items')).items.length, 1);
});

test('completion rejects media outside data/files/newsroom and missing files', async (t) => {
  const rootDir = await workspace(t); const store = createStore({ rootDir });
  await store.create('newsroom_jobs', queuedJob('NJ-MEDIA', 'running'));
  await assert.rejects(completeScoutJob({ rootDir, jobId: 'NJ-MEDIA', item: libraryItem('NR-BAD', ['../secret.png']), capabilityMode: 'workspace-media' }), /data\/files\/newsroom/);
  await assert.rejects(completeScoutJob({ rootDir, jobId: 'NJ-MEDIA', item: libraryItem('NR-MISSING', ['newsroom/missing.png']), capabilityMode: 'workspace-media' }), /does not exist/);
  await writeFile(path.join(rootDir, 'data/files/newsroom/evidence.png'), 'fixture');
  const completed = await completeScoutJob({ rootDir, jobId: 'NJ-MEDIA', item: libraryItem('NR-GOOD', ['newsroom/evidence.png']), capabilityMode: 'workspace-media' });
  assert.equal(completed.item.media[0], 'newsroom/evidence.png');
});

test('claim never steals a running or terminal job', async (t) => {
  const rootDir = await workspace(t); const store = createStore({ rootDir });
  for (const [index, status] of ['running', 'done', 'failed', 'preflight_failed'].entries()) await store.create('newsroom_jobs', queuedJob(`NJ-${index}`, status));
  assert.equal(await claimScoutJob({ rootDir }), null);
  assert.equal(await claimScoutJob({ rootDir, jobId: 'NJ-0' }), null);
});
