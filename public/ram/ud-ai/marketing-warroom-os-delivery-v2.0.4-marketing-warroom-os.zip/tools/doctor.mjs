import { access, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { TABLES } from '../app/store.mjs';
import { parseFeed } from '../app/lib/rss.mjs';
import { getWorkspaceIdentity } from './delivery-state.mjs';
import { fetchHttpsText } from './news-daily.mjs';
import { verifySnapshot } from './snapshot.mjs';

const COMPANY_FILES = ['business.md', 'persona.md', 'offer.md', 'voice.md', 'niche-criteria.md', 'RULES.md', 'pre-work.md', 'config.json'];
const CORE_FILES = [
  'VERSION', 'CLAUDE.md', 'AGENTS.md', 'เริ่มตรงนี้.md', 'DELIVERY-GUIDE.md',
  'CLASSROOM-RUNBOOK.md', 'LOCAL-FEATURE-MATRIX.md', 'SECURITY-REVIEW.md', 'TESTED-WITH.md', 'DELIVERY-STATUS.json',
  'Open Workspace.command', 'Open Workspace.bat', 'app/server.mjs', 'app/brand.json',
  'examples/client-context.example.json', 'examples/seed/three-rooms.json'
];
const DEFAULT_COMPANY = 'บริษัทตัวอย่าง จำกัด';
const DEFAULT_OWNERS = new Set(['Owner', 'Reviewer', 'Operator']);
const TEMPLATE_PHRASES = [
  'อธิบายธุรกิจ ลูกค้า',
  'ระบุข้อเสนอ ผลลัพธ์',
  'ระบุกลุ่มลูกค้าหลัก',
  'เลือกข่าวที่กระทบปัญหา',
  'ก่อนเริ่ม ให้กรอกไฟล์ Company'
];

async function exists(filePath) {
  try { await access(filePath); return true; } catch { return false; }
}

function check(name, status, detail) {
  return { name, status, ok: status !== 'FAIL', detail };
}

async function defaultWritableProbe(directory) {
  const temporary = await mkdtemp(path.join(directory, '.doctor-'));
  await writeFile(path.join(temporary, 'probe'), 'ok', { mode: 0o600 });
  await rm(temporary, { recursive: true, force: true });
  return true;
}

function defaultCommandProbe(command) {
  const result = spawnSync(command, ['-version'], { stdio: 'ignore' });
  return !result.error && result.status === 0;
}

async function fetchRunningIdentity(port) {
  return new Promise((resolve) => {
    const request = http.get({ hostname: '127.0.0.1', port, path: '/api/meta', timeout: 800 }, (response) => {
      const chunks = [];
      response.on('data', (chunk) => chunks.push(chunk));
      response.on('end', () => {
        try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')).workspace_identity || null); }
        catch { resolve(null); }
      });
    });
    request.on('timeout', () => { request.destroy(); resolve(null); });
    request.on('error', (error) => resolve(error.code === 'ECONNREFUSED' ? 'AVAILABLE' : null));
  });
}

export async function probePort(port = 4173) {
  const identity = await fetchRunningIdentity(port);
  if (identity === 'AVAILABLE') return { state: 'available' };
  return { state: 'occupied', workspaceIdentity: identity };
}

async function scanFiles(rootDir, relativeRoot) {
  const absoluteRoot = path.join(rootDir, relativeRoot);
  if (!await exists(absoluteRoot)) return [];
  const found = [];
  for (const entry of await readdir(absoluteRoot, { withFileTypes: true })) {
    if (['.bak', 'dist', 'snapshots'].includes(entry.name)) continue;
    const relativePath = path.join(relativeRoot, entry.name);
    if (entry.isDirectory()) found.push(...await scanFiles(rootDir, relativePath));
    else if (entry.isFile() && /\.(json|md|txt|env)$/i.test(entry.name)) found.push(relativePath);
  }
  return found;
}

async function credentialFindings(rootDir) {
  const patterns = [
    /sk-[A-Za-z0-9_-]{8,}/g,
    /Bearer\s+[A-Za-z0-9._-]{12,}/gi,
    /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g,
    /(?:password|recovery_code|access_token)\s*[=:]\s*["']?[^\s"']{8,}/gi
  ];
  const findings = [];
  for (const relativePath of [...await scanFiles(rootDir, 'company'), ...await scanFiles(rootDir, 'examples')]) {
    const content = await readFile(path.join(rootDir, relativePath), 'utf8');
    if (patterns.some((pattern) => { pattern.lastIndex = 0; return pattern.test(content); })) findings.push(relativePath);
  }
  return findings;
}

async function checkTables(rootDir) {
  const failures = [];
  for (const table of TABLES) {
    try {
      const value = JSON.parse(await readFile(path.join(rootDir, 'data', `${table}.json`), 'utf8'));
      if (value?.version !== 1 || !Array.isArray(value.items)) failures.push(table);
    } catch {
      failures.push(table);
    }
  }
  return failures;
}

async function defaultSourceProbe(url) {
  try {
    const items = parseFeed(await fetchHttpsText(url));
    return items.length ? { ok: true, items: items.length } : { ok: false, items: 0, error: 'RSS/Atom ไม่พบรายการข่าว' };
  } catch (error) {
    return { ok: false, items: 0, error: error.message };
  }
}

async function companyChecks(rootDir, { requireStarter, sourceProbe }) {
  const checks = [];
  let config = {};
  try { config = JSON.parse(await readFile(path.join(rootDir, 'company/config.json'), 'utf8')); } catch {}
  const markdown = (await Promise.all(COMPANY_FILES.filter((name) => name.endsWith('.md')).map(async (name) => {
    try { return await readFile(path.join(rootDir, 'company', name), 'utf8'); } catch { return ''; }
  }))).join('\n');
  const contextReady = typeof config.company_name === 'string' && config.company_name.trim() && config.company_name !== DEFAULT_COMPANY && !TEMPLATE_PHRASES.some((phrase) => markdown.includes(phrase));
  checks.push(check('Company context', contextReady ? 'PASS' : 'FAIL', contextReady ? config.company_name : 'กรอก Company Context จริงให้ครบ'));

  const ownersReady = ['owner', 'reviewer', 'operator'].every((role) => typeof config.owners?.[role] === 'string' && config.owners[role].trim() && !DEFAULT_OWNERS.has(config.owners[role]));
  checks.push(check('Company owners', ownersReady ? 'PASS' : 'FAIL', ownersReady ? 'Owner, Reviewer, Operator พร้อม' : 'เปลี่ยน Owner, Reviewer, Operator จากค่าเริ่มต้น'));

  let sources = [];
  let targets = [];
  try { sources = JSON.parse(await readFile(path.join(rootDir, 'data/ca_sources.json'), 'utf8')).items || []; } catch {}
  try { targets = JSON.parse(await readFile(path.join(rootDir, 'data/intel_targets.json'), 'utf8')).items || []; } catch {}
  const activeSources = sources.filter((source) => source.active && source.type === 'rss' && String(source.url).startsWith('https://'));
  checks.push(check('Active sources', activeSources.length >= 2 ? 'PASS' : 'FAIL', `${activeSources.length}/2 active HTTPS sources`));
  const sourceResults = await Promise.all(activeSources.map(async (source) => {
    try { return { source, ...await sourceProbe(source.url) }; }
    catch (error) { return { source, ok: false, items: 0, error: error.message }; }
  }));
  const healthySources = sourceResults.filter((result) => result.ok && result.items > 0);
  const failures = sourceResults.filter((result) => !result.ok || result.items < 1);
  checks.push(check(
    'Source health',
    activeSources.length >= 2 && failures.length === 0 ? 'PASS' : 'FAIL',
    failures.length
      ? `${healthySources.length}/${activeSources.length} feeds reachable · ${failures.map((result) => `${result.source.id}: ${result.error || 'no feed items'}`).join(' · ')}`
      : `${healthySources.length}/${activeSources.length} active feeds reachable`
  ));
  checks.push(check('Intel targets', targets.length >= 1 ? 'PASS' : 'FAIL', `${targets.length}/1 target`));

  if (requireStarter) {
    let starterReady = false;
    try {
      starterReady = (await verifySnapshot({ rootDir, name: 'starter-v1' })).ok;
    } catch {}
    checks.push(check('Starter baseline', starterReady ? 'PASS' : 'FAIL', starterReady ? 'starter-v1 manifest พร้อม' : 'ติดตั้งให้สำเร็จเพื่อสร้าง starter-v1'));
  }
  return checks;
}

async function demoChecks(rootDir) {
  let seed = {};
  try { seed = JSON.parse(await readFile(path.join(rootDir, 'examples/seed/three-rooms.json'), 'utf8')); } catch {}
  const ready = ['ca_sources', 'content_items', 'intel_targets'].every((table) => Array.isArray(seed[table]) && seed[table].length > 0);
  return [check('Demo seed', ready ? 'PASS' : 'FAIL', ready ? 'News, Content, Intel seed พร้อม' : 'three-rooms seed ไม่ครบ')];
}

export async function runDoctor({
  rootDir = path.resolve(import.meta.dirname, '..'),
  mode = 'preflight',
  port = 4173,
  requireStarter = true,
  portProbe = probePort,
  writableProbe = defaultWritableProbe,
  commandProbe = defaultCommandProbe,
  sourceProbe = defaultSourceProbe
} = {}) {
  if (!['preflight', 'company', 'demo'].includes(mode)) throw new Error(`Unknown doctor mode: ${mode}`);
  const checks = [];
  const nodeMajor = Number(process.versions.node.split('.')[0]);
  checks.push(check('Node.js', nodeMajor >= 20 ? 'PASS' : 'FAIL', `v${process.versions.node}; requires v20+`));
  const supportedOs = ['darwin', 'win32'].includes(process.platform);
  checks.push(check('Operating system', supportedOs ? 'PASS' : 'FAIL', `${os.type()} ${os.release()}; supports macOS and Windows`));

  const portState = await portProbe(port);
  const sameWorkspace = portState.state === 'occupied' && portState.workspaceIdentity === getWorkspaceIdentity(rootDir);
  const portReady = portState.state === 'available' || sameWorkspace;
  checks.push(check('Port 4173', portReady ? 'PASS' : 'FAIL', portState.state === 'available' ? 'available' : sameWorkspace ? 'same workspace is already running' : 'occupied by another process'));

  const requiredFiles = [...CORE_FILES, ...COMPANY_FILES.map((name) => `company/${name}`), ...TABLES.map((table) => `data/${table}.json`)];
  const missing = [];
  for (const relativePath of requiredFiles) if (!await exists(path.join(rootDir, relativePath))) missing.push(relativePath);
  checks.push(check('Required files', missing.length === 0 ? 'PASS' : 'FAIL', missing.length === 0 ? `${requiredFiles.length} files present` : `missing: ${missing.join(', ')}`));

  const launchersReady = await exists(path.join(rootDir, 'Open Workspace.command')) && await exists(path.join(rootDir, 'Open Workspace.bat'));
  checks.push(check('Launchers', launchersReady ? 'PASS' : 'FAIL', launchersReady ? 'macOS and Windows' : 'launcher file missing'));

  const requiredSkills = ['install', 'doctor', 'demo', 'restore', 'snapshot', 'reset', 'news-daily', 'scout', 'worker'];
  const skillsReady = (await Promise.all(['.claude/skills', '.agents/skills'].flatMap((base) => requiredSkills.map((skill) => exists(path.join(rootDir, base, skill, 'SKILL.md')))))).every(Boolean);
  checks.push(check('Agent skills', skillsReady ? 'PASS' : 'FAIL', skillsReady ? 'Claude Code and Codex skill trees ready' : 'rebuild both agent skill trees'));

  const tableFailures = await checkTables(rootDir);
  checks.push(check('Local tables', tableFailures.length === 0 ? 'PASS' : 'FAIL', tableFailures.length === 0 ? `${TABLES.length} valid JSON tables` : `invalid: ${tableFailures.join(', ')}`));

  const unwritable = [];
  for (const relativePath of ['data', 'output', 'wiki']) {
    try { if (!await writableProbe(path.join(rootDir, relativePath))) unwritable.push(relativePath); }
    catch { unwritable.push(relativePath); }
  }
  checks.push(check('Writable workspace', unwritable.length === 0 ? 'PASS' : 'FAIL', unwritable.length === 0 ? 'data, output, wiki writable' : `not writable: ${unwritable.join(', ')}`));

  const findings = await credentialFindings(rootDir);
  checks.push(check('Credential scan', findings.length === 0 ? 'PASS' : 'FAIL', findings.length === 0 ? 'no credential pattern found' : `review: ${findings.join(', ')}`));

  const optional = ['yt-dlp', 'ffmpeg'].filter((command) => commandProbe(command));
  const config = await readFile(path.join(rootDir, 'company/config.json'), 'utf8').then(JSON.parse).catch(() => ({}));
  if (config.kie_api_key) optional.push('kie.ai key');
  checks.push(check('Optional tools', optional.length === 3 ? 'PASS' : 'WARN', optional.length ? `available: ${optional.join(', ')}` : 'kie.ai, yt-dlp, FFmpeg are optional'));

  if (mode === 'company') checks.push(...await companyChecks(rootDir, { requireStarter, sourceProbe }));
  if (mode === 'demo') checks.push(...await demoChecks(rootDir));
  return { ok: checks.every((item) => item.status !== 'FAIL'), mode, checks };
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  const requested = process.argv.includes('--company') ? 'company' : process.argv.includes('--demo') ? 'demo' : 'preflight';
  const result = await runDoctor({ mode: requested });
  for (const item of result.checks) process.stdout.write(`${item.status === 'PASS' ? '✅' : item.status === 'WARN' ? '⚠️' : '❌'} [${item.status}] ${item.name}: ${item.detail}\n`);
  process.exitCode = result.ok ? 0 : 1;
}
