import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import test from 'node:test';
import { clientize, validateClientContext } from './clientize.mjs';
import { hashTree, makeTestWorkspace } from './delivery-test-helpers.mjs';

const validContext = Object.freeze({
  company_name: 'Siam Signal Studio Co., Ltd.',
  business: 'ที่ปรึกษาการปฏิบัติการสำหรับธุรกิจค้าปลีกไทย',
  offer: 'เวิร์กช็อปจัดระบบข่าว คู่แข่ง และการผลิตเนื้อหา',
  persona: 'เจ้าของกิจการค้าปลีกที่มีทีมการตลาด 3-10 คน',
  voice: ['ตรงประเด็น', 'อ้างอิงหลักฐาน', 'ไม่ใช้คำรับประกันผล'],
  rules: ['ห้ามแต่งตัวเลข', 'ห้ามโพสต์อัตโนมัติ'],
  niche_criteria: ['ข่าวที่เปลี่ยนต้นทุนค้าปลีก', 'ความเคลื่อนไหวคู่แข่งในประเทศไทย'],
  owners: { owner: 'Managing Director', reviewer: 'Marketing Lead', operator: 'Content Operator' },
  sources: [
    { name: 'Retail Signal', url: 'https://example.com/retail.xml', topic: 'retail', tags: ['retail'] },
    { name: 'AI Operations', url: 'https://example.org/operations.atom', topic: 'operations', tags: ['ai', 'operations'] }
  ],
  intel_targets: [
    { name: 'North Market Lab', url: 'https://example.net/north-market', role: 'benchmark', why_watch: 'รูปแบบการสาธิตที่ชัดเจน' }
  ],
  kie_api_key: 'must-never-be-written'
});

test('invalid context leaves every workspace byte unchanged', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  const contextPath = path.join(workspace.rootDir, 'invalid-context.json');
  await writeFile(contextPath, JSON.stringify({ ...validContext, company_name: '', sources: validContext.sources.slice(0, 1) }));
  const before = await hashTree(workspace.rootDir);

  await assert.rejects(clientize({ rootDir: workspace.rootDir, contextPath }), /company_name|sources/);

  assert.equal(await hashTree(workspace.rootDir), before);
});

test('validator rejects non-HTTPS source URLs before clientization', () => {
  const result = validateClientContext({
    ...validContext,
    sources: [validContext.sources[0], { ...validContext.sources[1], url: 'http://example.org/feed.xml' }]
  });
  assert.equal(result.ok, false);
  assert.match(result.errors.join('\n'), /HTTPS/);
});

test('clientization writes complete company context and deduplicated operating records without secrets', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  const contextPath = path.join(workspace.rootDir, 'client-context.json');
  const duplicateContext = {
    ...validContext,
    sources: [...validContext.sources, { ...validContext.sources[0], name: 'Duplicate name' }],
    intel_targets: [...validContext.intel_targets, { ...validContext.intel_targets[0], name: 'Duplicate target name' }]
  };
  await writeFile(contextPath, JSON.stringify(duplicateContext));

  const result = await clientize({ rootDir: workspace.rootDir, contextPath });
  const config = JSON.parse(await readFile(path.join(workspace.rootDir, 'company/config.json'), 'utf8'));
  const sources = JSON.parse(await readFile(path.join(workspace.rootDir, 'data/ca_sources.json'), 'utf8'));
  const targets = JSON.parse(await readFile(path.join(workspace.rootDir, 'data/intel_targets.json'), 'utf8'));
  const allCompanyFiles = await Promise.all([
    'business.md', 'offer.md', 'persona.md', 'voice.md', 'niche-criteria.md', 'RULES.md', 'pre-work.md', 'config.json'
  ].map((name) => readFile(path.join(workspace.rootDir, 'company', name), 'utf8')));

  assert.deepEqual(result, { companyName: validContext.company_name, sources: 2, targets: 1 });
  assert.equal(config.company_name, validContext.company_name);
  assert.deepEqual(config.owners, validContext.owners);
  assert.equal(config.kie_api_key, '');
  assert.equal(sources.items.length, 2);
  assert.equal(targets.items.length, 1);
  assert.ok(sources.items.every((item) => item.active && item.type === 'rss' && item.url.startsWith('https://')));
  assert.ok(targets.items.every((item) => item.name && item.handles[0].ref.startsWith('https://')));
  assert.doesNotMatch(allCompanyFiles.join('\n'), /must-never-be-written/);
});
