import assert from 'node:assert/strict';
import test from 'node:test';
import { renderDossier, renderWatchlist } from './intel-export.mjs';

test('intel export includes target facts, suggestions, and evidence links without inventing metrics', () => {
  const output = renderDossier({ id:'T1', name:'Example Brand', role:['competitor'], threat:'orange', why_watch:'Product demos', handles:[{platform:'web',ref:'https://example.invalid'}], handle_suggestions:[{platform:'youtube',ref:'@example',confidence:'high'}], triggers:[] }, [{ title:'Launch', source_url:'https://example.invalid/launch', summary:'New plan' }]);
  assert.match(output, /Example Brand/);
  assert.match(output, /@example/);
  assert.match(output, /Launch/);
  assert.doesNotMatch(output, /undefined/);
});

test('intel exporter builds the kit watchlist index', () => {
  const output = renderWatchlist([{ id:'T1', slug:'example-brand', name:'Example Brand', role:['competitor'], threat:'orange', cadence_days:14, next_scout_at:'2026-09-19T00:00:00.000Z' }]);
  assert.match(output, /# Intel Watchlist/);
  assert.match(output, /\[Example Brand\]\(scout\/example-brand\.md\)/);
  assert.match(output, /orange/);
});
