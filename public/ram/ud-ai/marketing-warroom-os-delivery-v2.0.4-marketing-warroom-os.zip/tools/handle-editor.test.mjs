import assert from 'node:assert/strict';
import test from 'node:test';
import { normalizeHandle, slugifyHandle } from '../app/lib/handle-editor.mjs';

test('handle normalization strips tracking parameters and recognizes supported hosts', () => {
  assert.deepEqual(normalizeHandle('https://www.youtube.com/@Example?utm_source=x'), { platform: 'youtube', ref: '@Example', hint: 'normalized' });
  assert.deepEqual(normalizeHandle('https://example.invalid/path/?fbclid=abc'), { platform: 'web', ref: 'https://example.invalid/path', hint: 'normalized' });
});

test('non-page Facebook and non-profile Instagram links receive review hints', () => {
  assert.equal(normalizeHandle('https://facebook.com/groups/example').hint, 'facebook-not-page');
  assert.equal(normalizeHandle('https://instagram.com/p/ABC').hint, 'instagram-not-profile');
  assert.equal(slugifyHandle('Example Brand Thailand'), 'example-brand-thailand');
});
