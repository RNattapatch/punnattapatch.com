import { cp, mkdir, rename, rm } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createSnapshot, MANAGED_ROOTS, verifySnapshot } from './snapshot.mjs';

async function stageSnapshot(rootDir, verified, purpose) {
  const stageDir = path.join(rootDir, `.${purpose}-${process.pid}-${process.hrtime.bigint()}`);
  await mkdir(stageDir, { recursive: false });
  for (const managedRoot of MANAGED_ROOTS) {
    const source = path.join(verified.directory, managedRoot);
    const destination = path.join(stageDir, managedRoot);
    await cp(source, destination, { recursive: true });
  }
  return stageDir;
}

async function replaceManagedRoots(rootDir, stageDir) {
  for (const managedRoot of MANAGED_ROOTS) {
    const target = path.join(rootDir, managedRoot);
    await rm(target, { recursive: true, force: true });
    await rename(path.join(stageDir, managedRoot), target);
  }
  await rm(stageDir, { recursive: true, force: true });
}

async function applyVerified(rootDir, verified, purpose) {
  const stageDir = await stageSnapshot(rootDir, verified, purpose);
  try { await replaceManagedRoots(rootDir, stageDir); }
  finally { await rm(stageDir, { recursive: true, force: true }); }
}

async function defaultPostCheck(rootDir) {
  const { runDoctor } = await import('./doctor.mjs');
  return runDoctor({ rootDir, mode: 'preflight', portProbe: async () => ({ state: 'available' }) });
}

export async function restoreSnapshot({
  rootDir = path.resolve(import.meta.dirname, '..'),
  name,
  now = new Date(),
  runPostCheck = defaultPostCheck
} = {}) {
  const requested = await verifySnapshot({ rootDir, name });
  const backup = await createSnapshot({ rootDir, label: 'before-restore', now });
  const backupVerified = await verifySnapshot({ rootDir, name: backup.name });
  try {
    await applyVerified(rootDir, requested, 'restore-stage');
    const result = await runPostCheck(rootDir);
    if (!result?.ok) throw new Error('Post-restore check failed');
    return { restored: requested.name, backup, check: result };
  } catch (error) {
    await applyVerified(rootDir, backupVerified, 'rollback-stage');
    throw new Error(`Restore failed; rollback completed: ${error.message}`);
  }
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  try {
    const result = await restoreSnapshot({ name: process.argv[2] });
    process.stdout.write(`RESTORE_COMPLETE\nSnapshot: ${result.restored}\nSafety backup: ${result.backup.directory}\n`);
  } catch (error) {
    process.stderr.write(`RESTORE_FAILED\n${error.message}\n`);
    process.exitCode = 1;
  }
}
