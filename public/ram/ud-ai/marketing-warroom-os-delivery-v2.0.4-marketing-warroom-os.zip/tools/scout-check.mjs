// เช็คก่อนสืบ: target นี้เคยสืบแล้วไหม (วัน · การ์ด · รายงานเดิม) — ไม่เข้าคิว ไม่แตะเครือข่าย
// ใช้: node tools/scout-check.mjs <kind|auto> "<target>" [--force] [--json]
// agent ที่รัน /scout ต้องเรียกก่อนทำงานทุกรายการ (brain/30-scout.md)
import path from 'node:path';
import { pathToFileURL } from 'node:url';

import { historyFor, historyMessage, targetKey } from '../app/lib/target-key.mjs';
import { createStore } from '../app/store.mjs';

export async function checkTarget({ rootDir = path.resolve(import.meta.dirname, '..'), kind = 'auto', target, force = false, note = '' } = {}) {
  const store = createStore({ rootDir });
  const [items, jobs] = await Promise.all([store.read('newsroom_items'), store.read('newsroom_jobs')]);
  const { key, hits } = historyFor({ kind, target, items: items.items, jobs: jobs.items });
  const message = historyMessage({ kind, target, hits, force, note });
  return { key, hits, blocked: message.blocked, text: message.text };
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  const args = process.argv.slice(2);
  const json = args.includes('--json');
  const force = args.includes('--force');
  const positional = args.filter((arg) => !arg.startsWith('--'));
  const [kind = 'auto', target = ''] = positional;
  if (!target) { process.stderr.write('ใช้: node tools/scout-check.mjs <kind|auto> "<target>" [--force] [--json]\n'); process.exit(2); }
  const result = await checkTarget({ kind, target, force });
  if (json) process.stdout.write(`${JSON.stringify(result)}\n`);
  else if (!result.key) process.stdout.write('เทียบไม่ได้ (ภาพ/ข้อความ) — สืบได้เลย\n');
  else if (!result.hits.length) process.stdout.write(`ยังไม่เคยสืบ (${targetKey(kind, target)}) — สืบได้เลย\n`);
  else process.stdout.write(`${result.text}\n${result.hits.map((hit) => `- ${hit.day} · ${hit.source} · ${hit.id}${hit.report ? ` · ${hit.report}` : ''}`).join('\n')}\n`);
  process.exitCode = result.blocked ? 3 : 0;
}
