import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createStore } from '../app/store.mjs';

export function renderDossier(target, items = []) {
  return `# ${target.name}\n\n- ID: ${target.id}\n- Role: ${(target.role || []).join(', ')}\n- Threat: ${target.threat}\n- Why watch: ${target.why_watch || '—'}\n\n## Channels\n\n${(target.handles || []).map((item) => `- ${item.platform}: ${item.ref}`).join('\n') || '- —'}\n\n## Channel suggestions\n\n${(target.handle_suggestions || []).map((item) => `- ${item.platform}: ${item.ref} (${item.confidence})`).join('\n') || '- —'}\n\n## Evidence\n\n${items.map((item) => `- [${item.title}](${item.source_url}) — ${item.summary}`).join('\n') || '- —'}\n`;
}

export function renderWatchlist(targets = []) {
  const rows = [...targets].sort((left,right)=>left.name.localeCompare(right.name, 'en')).map((target) =>
    `| [${target.name}](scout/${target.slug}.md) | ${(target.role || []).join(', ') || '—'} | ${target.threat || '—'} | ${target.cadence_days || '—'} | ${target.next_scout_at ? new Date(target.next_scout_at).toISOString().slice(0,10) : '—'} |`
  );
  return `# Intel Watchlist\n\n| Target | Role | Threat | Cadence (days) | Next scout |\n|---|---|---|---:|---|\n${rows.join('\n') || '| — | — | — | — | — |'}\n`;
}

export async function exportIntel({ rootDir = path.resolve(import.meta.dirname, '..'), targetId } = {}) {
  const store = createStore({ rootDir });
  const target = (await store.read('intel_targets')).items.find((item) => item.id === targetId);
  if (!target) throw new Error('Target not found');
  const items = (await store.read('newsroom_items')).items.filter((item) => item.target_id === targetId);
  const relative = `wiki/intel/scout/${target.slug}.md`; const output = path.join(rootDir, relative);
  await mkdir(path.dirname(output), { recursive: true }); await writeFile(output, renderDossier(target, items), { mode: 0o600 });
  const targets = (await store.read('intel_targets')).items;
  const watchlist = path.join(rootDir, 'wiki/intel/watchlist.md');
  await mkdir(path.dirname(watchlist), { recursive: true });
  await writeFile(watchlist, renderWatchlist(targets), { mode: 0o600 });
  return relative;
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) process.stdout.write(`${await exportIntel({ targetId: process.argv[2] })}\n`);
