import assert from 'node:assert/strict';
import test from 'node:test';
import { parseGlance } from '../app/assets/card.mjs';

test('glance parser preserves forced line breaks and marks coral emphasis', () => {
  assert.deepEqual(parseGlance('เศรษฐกิจโต | แต่[[ยอดคุณยังนิ่ง]]'), [
    [{ text:'เศรษฐกิจโต ', accent:false }],
    [{ text:' แต่', accent:false },{ text:'ยอดคุณยังนิ่ง',accent:true }]
  ]);
});
