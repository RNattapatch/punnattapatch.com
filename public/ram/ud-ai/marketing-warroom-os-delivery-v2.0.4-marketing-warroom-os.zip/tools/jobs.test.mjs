import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

import { processQueuedJobs } from './jobs/run.mjs';
import { handoffScript, isWritten } from './jobs/handoff-script.mjs';
import { TABLES } from '../app/store.mjs';

test('text-card jobs create a local HTML artifact and transition to done', async (t) => {
  const rootDir = await mkdtemp(path.join(os.tmpdir(), 'warroom-jobs-'));
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  await mkdir(path.join(rootDir, 'data'), { recursive: true });
  for (const table of TABLES) await writeFile(path.join(rootDir, 'data', `${table}.json`), '{"version":1,"items":[]}\n');
  const job = { id: 'JOB-1', job_type: 'render_text_card', payload: { candidate_id: 'CAN-1', slug: 'example', glance_line: 'ทีมคุณ | พร้อมหรือยัง' }, status: 'queued', result: {}, error: null, created_at: '2026-09-05T00:00:00.000Z', started_at: null, finished_at: null };
  await writeFile(path.join(rootDir, 'data/wr_jobs.json'), `${JSON.stringify({ version: 1, items: [job] })}\n`);
  const candidate = { id:'CAN-1', news_item_id:'NEWS-1', article_md:'article', edited_article_md:null, hooks:[{id:'h1',style:'proof',text:'hook'}], images:[], status:'pending_review', selected_hook:null, selected_image:null, post_to_ig:false, scheduled_at:null, created_at:'2026-09-05T00:00:00.000Z', comment_thread:[{role:'cta',text:'cta'},{role:'article',text:'article'},{role:'source',text:'source'},{role:'angle2',text:'angle2'},{role:'cases',text:'cases'}], glance_line:'ทีมคุณ | พร้อมหรือยัง', scene_prompt:'scene', scene_field:'sales' };
  await writeFile(path.join(rootDir, 'data/ca_candidates.json'), `${JSON.stringify({ version:1, items:[candidate] })}\n`);
  const summary = await processQueuedJobs({ rootDir });
  assert.deepEqual(summary, { processed: 1, done: 1, errors: 0 });
  const saved = JSON.parse(await readFile(path.join(rootDir, 'data/wr_jobs.json'), 'utf8')).items[0];
  assert.equal(saved.status, 'done');
  assert.match(saved.result.path, /^content-images\/example\//);
  assert.match(await readFile(path.join(rootDir, 'data/files', saved.result.path), 'utf8'), /ทีมคุณ/);
  const savedCandidate = JSON.parse(await readFile(path.join(rootDir, 'data/ca_candidates.json'), 'utf8')).items[0];
  assert.deepEqual(savedCandidate.images, [{ style:'text-card', url:`/files/${saved.result.path}` }]);
  assert.equal(savedCandidate.selected_image, 0);
});

test('rewrite_reel opens a script record for the agent and refuses clips without a transcript', async (t) => {
  const rootDir = await mkdtemp(path.join(os.tmpdir(), 'warroom-rewrite-'));
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  await mkdir(path.join(rootDir, 'data'), { recursive: true });
  for (const table of TABLES) await writeFile(path.join(rootDir, 'data', `${table}.json`), '{"version":1,"items":[]}\n');

  const transcript = Array.from({ length: 8 }, (_, index) => `[0:${String(index * 7).padStart(2, '0')}] ประโยคที่ถอดมาจากคลิปต้นทาง`).join('\n');
  const clip = { id: 'NR-1', job_id: 'NJ-1', kind: 'clip', platform: 'tiktok', source_url: 'https://example.invalid/v/1', title: 'คลิปคู่แข่ง', channel: 'competitor', summary: 'สรุป', verdict: 'watch', score: 80, views: 1000, duration_s: 55, cover_path: null, media: [], report_md: `# รายงาน\n${transcript}`, report_path: 'wiki/intel/scout/clip.md', tags: ['clip'], scraped_at: '2026-09-08T00:00:00.000Z', created_at: '2026-09-08T00:00:00.000Z', target_id: 'TGT-1' };
  const bare = { ...clip, id: 'NR-2', report_md: '# รายงาน\nสรุปเฉยๆ ไม่มีบทพูด' };
  await writeFile(path.join(rootDir, 'data/newsroom_items.json'), `${JSON.stringify({ version: 1, items: [clip, bare] })}\n`);
  const job = (id, item_id) => ({ id, job_type: 'rewrite_reel', payload: { item_id, theme: 'บอกราคาในคอนเทนต์ ผิดไหม', pillar: 'sales_team', hook_style: 'question', length: 'mid', cta_keyword: 'AI', notes: '' }, status: 'queued', result: {}, error: null, created_at: '2026-09-08T00:00:00.000Z', started_at: null, finished_at: null });
  await writeFile(path.join(rootDir, 'data/wr_jobs.json'), `${JSON.stringify({ version: 1, items: [job('JOB-1', 'NR-1'), job('JOB-2', 'NR-2'), job('JOB-3', 'NR-404')] })}\n`);

  const summary = await processQueuedJobs({ rootDir });
  assert.deepEqual(summary, { processed: 3, done: 1, errors: 2 });

  const jobs = JSON.parse(await readFile(path.join(rootDir, 'data/wr_jobs.json'), 'utf8')).items;
  assert.equal(jobs[0].status, 'done');
  assert.equal(jobs[0].result.script_id, 'IS-JOB-1');
  assert.match(jobs[0].result.instruction, /handoff-script\.mjs IS-JOB-1/, 'ผลงานต้องบอก agent ว่าเขียนเสร็จแล้วส่งต่อด้วย tool ไหน');
  assert.match(jobs[1].error, /บทพูดถอดเสียง/);
  assert.match(jobs[2].error, /ไม่พบการ์ดต้นทาง/);

  const scripts = JSON.parse(await readFile(path.join(rootDir, 'data/intel_scripts.json'), 'utf8')).items;
  assert.equal(scripts.length, 1, 'งานที่พังต้องไม่ทิ้งแฟ้มเวอร์ชันค้างไว้');
  assert.deepEqual([scripts[0].item_id, scripts[0].job_id, scripts[0].content_id], ['NR-1', 'JOB-1', null]);
  assert.equal(scripts[0].brief.hook_style, 'question');
  assert.match(scripts[0].script_md, /# 📝 Caption/);
});

test('handoff-script sends a written script into Content Center by itself and refuses an empty scaffold', async (t) => {
  const rootDir = await mkdtemp(path.join(os.tmpdir(), 'warroom-handoff-'));
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  await mkdir(path.join(rootDir, 'data'), { recursive: true });
  for (const table of TABLES) await writeFile(path.join(rootDir, 'data', `${table}.json`), '{"version":1,"items":[]}\n');
  const transcript = Array.from({ length: 8 }, (_, index) => `[0:${String(index * 7).padStart(2, '0')}] ประโยคที่ถอดมาจากคลิปต้นทาง`).join('\n');
  const clip = { id: 'NR-1', job_id: 'NJ-1', kind: 'clip', platform: 'tiktok', source_url: 'https://example.invalid/v/1', title: 'คลิปคู่แข่ง', channel: 'competitor', summary: 'สรุป', verdict: 'watch', score: 80, views: 1000, duration_s: 55, cover_path: null, media: [], report_md: `# รายงาน\n${transcript}`, report_path: 'wiki/intel/scout/clip.md', tags: ['clip'], scraped_at: '2026-09-08T00:00:00.000Z', created_at: '2026-09-08T00:00:00.000Z', target_id: 'TGT-1' };
  await writeFile(path.join(rootDir, 'data/newsroom_items.json'), `${JSON.stringify({ version: 1, items: [clip] })}\n`);
  const job = { id: 'JOB-1', job_type: 'rewrite_reel', payload: { item_id: 'NR-1', theme: 'บอกราคาในคอนเทนต์ ผิดไหม', pillar: 'sales_team', hook_style: 'question', length: 'mid', cta_keyword: 'AI', notes: '' }, status: 'queued', result: {}, error: null, created_at: '2026-09-08T00:00:00.000Z', started_at: null, finished_at: null };
  await writeFile(path.join(rootDir, 'data/wr_jobs.json'), `${JSON.stringify({ version: 1, items: [job] })}\n`);
  await processQueuedJobs({ rootDir });
  const scriptId = JSON.parse(await readFile(path.join(rootDir, 'data/intel_scripts.json'), 'utf8')).items[0].id;

  await assert.rejects(() => handoffScript({ rootDir, scriptId }), /โครงเปล่า/, 'โครงเปล่าห้ามหลุดเข้า Content Center');
  let saved = JSON.parse(await readFile(path.join(rootDir, 'data/wr_jobs.json'), 'utf8')).items[0];
  assert.match(saved.result.handoff_error, /โครงเปล่า/, 'เหตุผลที่ส่งไม่ผ่านต้องอยู่บนงาน ให้หน้าเว็บบอกผู้ใช้ได้');
  assert.equal(JSON.parse(await readFile(path.join(rootDir, 'data/content_items.json'), 'utf8')).items.length, 0);

  const written = `# บอกราคาในคอนเทนต์ ผิดไหม\n\n# Hook\nบอกราคาแล้วลูกค้าหายไหม\n\n# Setup\nพาไปดู\n\n# Body\nเคสจาก company/\n\n↻ Rehook:\nแต่ที่หายจริงคือ\n\n# Payoff\nความไม่ชัดต่างหาก\n\n# CTA\nพิมพ์ AI\n\n# 🔤 Hook Text\nบอกราคา | ผิดไหม\n\n# 📝 Caption\n📍 หนึ่ง\n📍 สอง\n📍 พิมพ์ AI\n\n# 🧬 โครงที่ยืมมา\n- เปิดด้วยคำถาม`;
  assert.equal(isWritten(written), true);
  const scripts = JSON.parse(await readFile(path.join(rootDir, 'data/intel_scripts.json'), 'utf8'));
  scripts.items[0].script_md = written;
  await writeFile(path.join(rootDir, 'data/intel_scripts.json'), `${JSON.stringify(scripts)}\n`);

  const result = await handoffScript({ rootDir, scriptId });
  assert.equal(result.already, false);
  assert.match(result.content_id, /^CNT-\d{4}-\d{2}-\d{2}-001$/);
  assert.equal(result.variant_id, `${result.content_id}-RL`);
  const idea = JSON.parse(await readFile(path.join(rootDir, 'data/content_items.json'), 'utf8')).items[0];
  assert.equal(idea.title, 'บอกราคาในคอนเทนต์ ผิดไหม');
  assert.equal(idea.idea_status, 'active');
  assert.equal(idea.pillar_bucket, 'sales_team');
  assert.equal(idea.source_ref, 'intel:NR-1 https://example.invalid/v/1');
  const variant = JSON.parse(await readFile(path.join(rootDir, 'data/content_variants.json'), 'utf8')).items[0];
  assert.equal(variant.ai_result, written);
  assert.equal(variant.script_draft, '', 'ร่างของผู้ใช้ต้องว่าง — บทอยู่ช่อง AI');
  assert.equal(variant.variant_status, 'ai_improved');
  assert.equal(variant.cta_keyword, 'AI');
  assert.equal(JSON.parse(await readFile(path.join(rootDir, 'data/intel_scripts.json'), 'utf8')).items[0].content_id, result.content_id);
  saved = JSON.parse(await readFile(path.join(rootDir, 'data/wr_jobs.json'), 'utf8')).items[0];
  assert.deepEqual([saved.result.content_id, saved.result.handoff_error], [result.content_id, null]);

  const twice = await handoffScript({ rootDir, scriptId });
  assert.deepEqual(twice, { content_id: result.content_id, variant_id: result.variant_id, already: true }, 'ส่งซ้ำต้องไม่สร้างไอเดียซ้ำ');
  assert.equal(JSON.parse(await readFile(path.join(rootDir, 'data/content_items.json'), 'utf8')).items.length, 1);
});
