import { cp, mkdir, readFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

export function run(command, args, { cwd, allowFailure = false } = {}) {
  const result = spawnSync(command, args, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
  if (!allowFailure && (result.error || result.status !== 0)) {
    throw new Error(`${command} ${args.join(' ')} failed: ${(result.stderr || result.error?.message || '').trim()}`);
  }
  return result;
}

export function assertInside(rootDir, candidate, label = 'Path') {
  const root = path.resolve(rootDir);
  const resolved = path.resolve(rootDir, candidate);
  if (!(resolved === root || resolved.startsWith(`${root}${path.sep}`))) throw new Error(`${label} is outside workspace`);
  return resolved;
}

export async function copyReplace(source, destination) {
  await rm(destination, { recursive: true, force: true });
  await mkdir(path.dirname(destination), { recursive: true });
  await cp(source, destination, { recursive: true });
}

export async function readConfig(rootDir) {
  return JSON.parse(await readFile(path.join(rootDir, 'company/config.json'), 'utf8'));
}
