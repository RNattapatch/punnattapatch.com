import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';
import path from 'node:path';
import test from 'node:test';
import { clientize } from './clientize.mjs';
import { startDemo, stopDemo } from './demo.mjs';
import { hashTree, makeTestWorkspace } from './delivery-test-helpers.mjs';
import { runNewsDaily } from './news-daily.mjs';

async function managedHash(rootDir) {
  const values = [];
  for (const folder of ['company', 'data', 'output', 'wiki']) values.push(`${folder}:${await hashTree(path.join(rootDir, folder))}`);
  return values.join('|');
}

async function exists(filePath) {
  try { await access(filePath); return true; } catch { return false; }
}

test('demo start seeds all three rooms without changing company context and rejects nested sessions', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  await clientize({ rootDir: workspace.rootDir, contextPath: path.join(workspace.rootDir, 'examples/client-context.example.json'), now: new Date('2026-09-12T00:00:00.000Z') });
  const companyBefore = await hashTree(path.join(workspace.rootDir, 'company'));

  const session = await startDemo({ rootDir: workspace.rootDir, now: new Date('2026-09-12T05:00:00.000Z') });

  assert.match(session.snapshot_name, /^before-demo-/);
  assert.equal(await hashTree(path.join(workspace.rootDir, 'company')), companyBefore);
  assert.equal(JSON.parse(await readFile(path.join(workspace.rootDir, 'data/ca_sources.json'), 'utf8')).items.length, 3);
  assert.equal(JSON.parse(await readFile(path.join(workspace.rootDir, 'data/content_items.json'), 'utf8')).items.length, 2);
  assert.equal(JSON.parse(await readFile(path.join(workspace.rootDir, 'data/intel_targets.json'), 'utf8')).items.length, 3);
  await assert.rejects(startDemo({ rootDir: workspace.rootDir }), /already active/i);
});

test('demo start makes time-sensitive fixtures fresh and gives News plus Intel a complete local path', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  const now = new Date('2027-03-18T04:30:00.000Z');

  await startDemo({ rootDir: workspace.rootDir, now });
  const sources = JSON.parse(await readFile(path.join(workspace.rootDir, 'data/ca_sources.json'), 'utf8')).items;
  assert.equal(sources.length, 3);
  assert.ok(sources.every((source) => source.url.startsWith('output/demo/rss/')));

  const result = await runNewsDaily({
    rootDir: workspace.rootDir,
    briefOutDir: path.join(workspace.rootDir, 'output/content/news-briefs'),
    now
  });
  assert.equal(result.fetched, 3);
  assert.equal(result.inserted, 3);
  assert.equal(result.briefs, 3);
  assert.deepEqual(result.errors, []);

  const runStatus = JSON.parse(await readFile(path.join(workspace.rootDir, 'data/.news-daily-run.json'), 'utf8'));
  assert.equal(runStatus.ran_at, now.toISOString());
  assert.equal(runStatus.inserted, 3);

  const variants = JSON.parse(await readFile(path.join(workspace.rootDir, 'data/content_variants.json'), 'utf8')).items;
  assert.equal(new Date(variants[0].status_changed_at).toISOString(), now.toISOString());
  assert.equal(await exists(path.join(workspace.rootDir, variants[0].markdown_path)), true);

  const targets = JSON.parse(await readFile(path.join(workspace.rootDir, 'data/intel_targets.json'), 'utf8')).items;
  assert.ok(targets.every((target) => target.handles.some((handle) => handle.platform === 'web' && handle.ref.startsWith('http://127.0.0.1:4173/demo/'))));
});

test('demo stop snapshots demo work and restores company state byte-for-byte', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  await clientize({ rootDir: workspace.rootDir, contextPath: path.join(workspace.rootDir, 'examples/client-context.example.json'), now: new Date('2026-09-12T00:00:00.000Z') });
  const before = await managedHash(workspace.rootDir);
  await startDemo({ rootDir: workspace.rootDir, now: new Date('2026-09-12T06:00:00.000Z') });
  const markerPath = path.join(workspace.rootDir, 'snapshots/.demo-session.json');

  const result = await stopDemo({ rootDir: workspace.rootDir, now: new Date('2026-09-12T06:30:00.000Z') });

  assert.match(result.after_demo_snapshot, /^after-demo-/);
  assert.equal(await managedHash(workspace.rootDir), before);
  assert.equal(await exists(markerPath), false);
  assert.equal(await exists(path.join(workspace.rootDir, 'snapshots', result.after_demo_snapshot, 'manifest.json')), true);
});

test('demo stop refuses when no session exists', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  const before = await managedHash(workspace.rootDir);
  await assert.rejects(stopDemo({ rootDir: workspace.rootDir }), /no active demo/i);
  assert.equal(await managedHash(workspace.rootDir), before);
});
