import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { hashTree } from './delivery-test-helpers.mjs';
import { resetWorkspace } from './reset.mjs';
import { restoreSnapshot } from './restore.mjs';
import { createSnapshot, verifySnapshot } from './snapshot.mjs';

async function fixtureWorkspace() {
  const rootDir = await mkdtemp(path.join(os.tmpdir(), 'warroom-snapshot-'));
  for (const folder of ['company', 'data', 'output', 'wiki']) await mkdir(path.join(rootDir, folder), { recursive: true });
  await writeFile(path.join(rootDir, 'VERSION'), '2.0.0\n');
  await writeFile(path.join(rootDir, 'company/note.txt'), 'hello\n');
  await writeFile(path.join(rootDir, 'data/items.json'), '{"version":1,"items":[]}\n');
  await writeFile(path.join(rootDir, 'output/result.md'), '# Result\n');
  await writeFile(path.join(rootDir, 'wiki/index.md'), '# Index\n');
  return { rootDir, cleanup: () => rm(rootDir, { recursive: true, force: true }) };
}

async function managedHash(rootDir) {
  const digests = [];
  for (const folder of ['company', 'data', 'output', 'wiki']) digests.push(`${folder}:${await hashTree(path.join(rootDir, folder))}`);
  return digests.join('|');
}

test('snapshot manifest records sorted managed files with literal SHA-256 values', async (t) => {
  const workspace = await fixtureWorkspace();
  t.after(workspace.cleanup);
  const snapshot = await createSnapshot({ rootDir: workspace.rootDir, label: 'manual', now: new Date('2026-09-12T01:02:03.000Z') });
  const manifest = JSON.parse(await readFile(snapshot.manifestPath, 'utf8'));
  const note = manifest.files.find((file) => file.path === 'company/note.txt');

  assert.equal(snapshot.name, 'manual-2026-09-12T01-02-03-000Z');
  assert.equal(manifest.workspace_version, '2.0.0');
  assert.deepEqual(manifest.files.map((file) => file.path), [...manifest.files.map((file) => file.path)].sort());
  assert.deepEqual(note, { path: 'company/note.txt', size: 6, sha256: '5891b5b522d5df086d0ff0b110fbd9d21bb4fc7163af34d08286a2e846f6be03' });
  assert.equal((await verifySnapshot({ rootDir: workspace.rootDir, name: snapshot.name })).ok, true);
});

test('snapshot names cannot escape snapshots and immutable starter-v1 cannot be overwritten', async (t) => {
  const workspace = await fixtureWorkspace();
  t.after(workspace.cleanup);
  await assert.rejects(verifySnapshot({ rootDir: workspace.rootDir, name: '../outside' }), /snapshot name/i);
  await createSnapshot({ rootDir: workspace.rootDir, label: 'starter-v1', immutable: true });
  await assert.rejects(createSnapshot({ rootDir: workspace.rootDir, label: 'starter-v1', immutable: true }), /immutable|exists/i);
});

test('corrupt snapshot is rejected before live files change', async (t) => {
  const workspace = await fixtureWorkspace();
  t.after(workspace.cleanup);
  const snapshot = await createSnapshot({ rootDir: workspace.rootDir, label: 'safe', now: new Date('2026-09-12T02:00:00.000Z') });
  await writeFile(path.join(snapshot.directory, 'company/note.txt'), 'tampered\n');
  await writeFile(path.join(workspace.rootDir, 'company/note.txt'), 'live-state\n');

  await assert.rejects(restoreSnapshot({ rootDir: workspace.rootDir, name: snapshot.name, runPostCheck: async () => ({ ok: true }) }), /checksum/i);
  assert.equal(await readFile(path.join(workspace.rootDir, 'company/note.txt'), 'utf8'), 'live-state\n');
});

test('snapshot verification rejects unlisted files that would bypass manifest checks', async (t) => {
  const workspace = await fixtureWorkspace();
  t.after(workspace.cleanup);
  const snapshot = await createSnapshot({ rootDir: workspace.rootDir, label: 'listed-only', now: new Date('2026-09-12T02:30:00.000Z') });
  await writeFile(path.join(snapshot.directory, 'company/unlisted.txt'), 'not in manifest\n');
  await assert.rejects(verifySnapshot({ rootDir: workspace.rootDir, name: snapshot.name }), /unlisted|manifest/i);
});

test('restore returns all managed roots byte-for-byte and snapshots current state first', async (t) => {
  const workspace = await fixtureWorkspace();
  t.after(workspace.cleanup);
  const expected = await managedHash(workspace.rootDir);
  const snapshot = await createSnapshot({ rootDir: workspace.rootDir, label: 'known-good', now: new Date('2026-09-12T03:00:00.000Z') });
  await writeFile(path.join(workspace.rootDir, 'company/note.txt'), 'changed\n');
  await writeFile(path.join(workspace.rootDir, 'data/extra.json'), '{}\n');

  const result = await restoreSnapshot({ rootDir: workspace.rootDir, name: snapshot.name, now: new Date('2026-09-12T03:30:00.000Z'), runPostCheck: async () => ({ ok: true }) });

  assert.equal(await managedHash(workspace.rootDir), expected);
  assert.match(path.basename(result.backup.directory), /^before-restore-/);
  assert.equal((await verifySnapshot({ rootDir: workspace.rootDir, name: result.backup.name })).ok, true);
});

test('failed post-restore check rolls back to exact pre-restore state', async (t) => {
  const workspace = await fixtureWorkspace();
  t.after(workspace.cleanup);
  const snapshot = await createSnapshot({ rootDir: workspace.rootDir, label: 'old', now: new Date('2026-09-12T04:00:00.000Z') });
  await writeFile(path.join(workspace.rootDir, 'company/note.txt'), 'current-before-restore\n');
  await writeFile(path.join(workspace.rootDir, 'output/new.md'), 'keep me on rollback\n');
  const before = await managedHash(workspace.rootDir);

  await assert.rejects(restoreSnapshot({ rootDir: workspace.rootDir, name: snapshot.name, runPostCheck: async () => ({ ok: false }) }), /post-restore/i);

  assert.equal(await managedHash(workspace.rootDir), before);
});

test('reset refuses to mutate without an explicit mode', async (t) => {
  const workspace = await fixtureWorkspace();
  t.after(workspace.cleanup);
  const before = await managedHash(workspace.rootDir);

  await assert.rejects(resetWorkspace({ rootDir: workspace.rootDir }), /--demo|--starter/);

  assert.equal(await managedHash(workspace.rootDir), before);
});
