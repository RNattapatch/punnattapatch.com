import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import test from 'node:test';

const root = path.resolve(import.meta.dirname, '..');
const views = ['shell', 'content', 'news-desk', 'intel', 'jobs', 'settings', 'card'];

test('all app views use one product-only notebook shell', async () => {
  const pages = await Promise.all(views.map((name) => readFile(path.join(root, 'app/views', `${name}.html`), 'utf8')));
  for (const html of pages) {
    assert.match(html, />\{\{PRODUCT_NAME\}\}<\/a>/);
    assert.doesNotMatch(html, /brand-tagline|PRODUCT_TAGLINE|app-theme/);
    assert.match(html, /data-nav="content"/);
    assert.match(html, /data-nav="news"/);
    assert.match(html, /data-nav="intel"/);
    assert.match(html, /data-utility="jobs"/);
    assert.match(html, /data-utility="settings"/);
    assert.match(html, /<link rel="icon" href="data:,">/, 'browser must not request a missing favicon');
  }
  assert.equal(new Set(pages).size, 1, 'shell markup must not drift between routes');
});

test('visual tokens describe a white borders-only operations desk', async () => {
  const css = await readFile(path.join(root, 'app/assets/app.css'), 'utf8');
  assert.match(css, /--canvas:\s*#fff(?:fff)?/i);
  assert.match(css, /--brand-navy:\s*#072b4e/i);
  assert.match(css, /--brand-coral:\s*#dd4155/i);
  assert.match(css, /\.notebook-tabs/);
  assert.match(css, /background:\s*var\(--canvas\)/);
  assert.doesNotMatch(css, /body\s*\{[^}]*background:\s*var\(--sand\)/s);
  assert.match(css, /#app:focus-visible\s*\{\s*outline:\s*none;/, 'programmatic page focus must not draw a frame around the whole workspace');
});

test('programmatic page focus preserves the initial scroll position', async () => {
  const script = await readFile(path.join(root, 'app/assets/app.mjs'), 'utf8');
  assert.match(script, /app\.focus\(\{\s*preventScroll:\s*true\s*\}\);/);
});
