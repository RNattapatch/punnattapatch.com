import assert from 'node:assert/strict';
import test from 'node:test';

import { nextContentId, slugify, variantId } from '../app/lib/ids.mjs';
import { similarity, findSimilar } from '../app/lib/similar.mjs';
import { parseFeed } from '../app/lib/rss.mjs';

test('content IDs use the UTC+7 date and next available sequence', () => {
  const now = new Date('2026-09-04T18:00:00.000Z');
  assert.equal(nextContentId(['CNT-2026-09-05-001', 'CNT-2026-09-05-003'], now), 'CNT-2026-09-05-004');
  assert.equal(variantId('CNT-2026-09-05-004', 'reel'), 'CNT-2026-09-05-004-RL');
  assert.equal(slugify('AI ใช้จริง: Sales Team!'), 'ai-sales-team');
});

test('similarity finds overlapping ideas above the product threshold', () => {
  assert.equal(similarity('abcd', 'abce'), 1 / 3, 'similarity must be character-trigram Jaccard');
  const score = similarity('ใช้ AI ช่วยทีมขายทำ follow up', 'AI ช่วยทีมขาย follow up ลูกค้า');
  assert.ok(score >= 0.22);
  assert.equal(findSimilar('AI ช่วยทีมขาย follow up ลูกค้า', [
    { content_id: 'A', title: 'เมนูกาแฟประจำวัน', canonical_angle: '' },
    { content_id: 'B', title: 'ใช้ AI ช่วยทีมขายทำ follow up', canonical_angle: '' }
  ])[0].content_id, 'B');
});

test('RSS and Atom fixtures parse title, link, date, and encoded body without dependencies', () => {
  const rss = parseFeed('<?xml version="1.0"?><rss><channel><item><title>Story &amp; One</title><link>https://example.invalid/1</link><pubDate>Fri, 05 Sep 2026 00:00:00 GMT</pubDate><description>Short summary</description><content:encoded><![CDATA[<p>Full encoded body</p>]]></content:encoded></item></channel></rss>');
  assert.deepEqual(rss[0], { title: 'Story & One', link: 'https://example.invalid/1', publishedAt: '2026-09-05T00:00:00.000Z', content: '<p>Full encoded body</p>' });
  const atom = parseFeed('<feed><entry><title>Atom</title><link href="https://example.invalid/2"/><updated>2026-09-05T01:00:00Z</updated><content>Text</content></entry></feed>');
  assert.equal(atom[0].link, 'https://example.invalid/2');
  assert.equal(atom[0].content, 'Text');
});
