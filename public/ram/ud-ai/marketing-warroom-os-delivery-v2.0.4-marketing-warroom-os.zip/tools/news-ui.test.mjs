import assert from 'node:assert/strict';
import test from 'node:test';
import * as news from '../app/assets/news.mjs';

test('candidate cards use the linked news title and only fall back to the first hook', () => {
  const candidate={news_item_id:'NEWS-1',hooks:[{text:'Hook is not the title'}]};
  assert.equal(news.candidateTitle(candidate,[{id:'NEWS-1',title:'Source news title'}]),'Source news title');
  assert.equal(news.candidateTitle(candidate,[]),'Hook is not the title');
});

test('News Desk orders comment badges by the production roles and locates article by role instead of index zero', () => {
  assert.equal(typeof news.orderedCommentThread, 'function');
  const candidate = { comment_thread: [
    { role: 'cases', text: 'cases' },
    { role: 'source', text: 'source' },
    { role: 'article', text: 'article' },
    { role: 'cta', text: 'cta' },
    { role: 'angle2', text: 'angle2' }
  ] };
  const comments = news.orderedCommentThread(candidate);
  assert.deepEqual(comments.map((entry) => entry.role), ['cta', 'article', 'source', 'angle2', 'cases']);
  assert.equal(news.articleCommentIndex(comments), 1);
});

test('News Desk formats the persisted morning run instead of always saying no run exists', () => {
  assert.equal(news.formatNewsRun(null), 'ยังไม่มีข้อมูลการรัน');
  const label = news.formatNewsRun({ ran_at: '2026-09-13T02:00:00.000Z', sources: 3, inserted: 3, errors: [] });
  assert.match(label, /3 ข่าวใหม่/);
  assert.match(label, /3 แหล่ง/);
  assert.doesNotMatch(label, /ยังไม่มีข้อมูล/);
});
