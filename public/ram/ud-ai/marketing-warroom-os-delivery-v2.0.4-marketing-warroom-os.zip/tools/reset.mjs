import { cp, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createStore, TABLES } from '../app/store.mjs';
import { restoreSnapshot } from './restore.mjs';
import { createSnapshot } from './snapshot.mjs';

const DEMO_ANCHOR = new Date('2026-09-05T00:00:00.000Z').getTime();

function shiftDemoDates(value, deltaMs) {
  if (Array.isArray(value)) return value.map((item) => shiftDemoDates(item, deltaMs));
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, shiftDemoDates(item, deltaMs)]));
  if (typeof value === 'string' && /^2026-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)) {
    return new Date(new Date(value).getTime() + deltaMs).toISOString();
  }
  return value;
}

async function materializeDemoRss(rootDir, now) {
  const sourceDir = path.join(rootDir, 'examples/rss');
  const targetDir = path.join(rootDir, 'output/demo/rss');
  await mkdir(targetDir, { recursive: true });
  for (const entry of await readdir(sourceDir, { withFileTypes: true })) {
    if (!entry.isFile() || !entry.name.endsWith('.xml')) continue;
    const original = await readFile(path.join(sourceDir, entry.name), 'utf8');
    const fresh = original
      .replace(/<pubDate>[\s\S]*?<\/pubDate>/g, `<pubDate>${now.toUTCString()}</pubDate>`)
      .replace(/<updated>[\s\S]*?<\/updated>/g, `<updated>${now.toISOString()}</updated>`);
    await writeFile(path.join(targetDir, entry.name), fresh, { mode: 0o600 });
  }
}

async function copyDemoFiles(rootDir) {
  const filesDir = path.join(rootDir, 'examples/seed/files');
  for (const entry of await readdir(filesDir, { withFileTypes: true })) {
    await cp(path.join(filesDir, entry.name), path.join(rootDir, entry.name), { recursive: true, force: true });
  }
}

export async function loadDemoSeed(rootDir, { now = new Date() } = {}) {
  const store = createStore({ rootDir });
  for (const table of TABLES) await store.write(table, { version: 1, items: [] });
  const rawSeed = JSON.parse(await readFile(path.join(rootDir, 'examples/seed/three-rooms.json'), 'utf8'));
  const seed = shiftDemoDates(rawSeed, now.getTime() - DEMO_ANCHOR);
  await materializeDemoRss(rootDir, now);
  seed.ca_sources = seed.ca_sources.map((source) => ({ ...source, url: `output/demo/rss/${path.basename(source.url)}` }));
  seed.intel_targets = seed.intel_targets.map((target) => ({
    ...target,
    handles: [{ platform: 'web', ref: `http://127.0.0.1:4173/demo/${target.slug}` }],
    handle_suggestions: []
  }));
  await copyDemoFiles(rootDir);
  for (const [table, items] of Object.entries(seed)) for (const item of items) await store.create(table, item);
  return TABLES.length;
}

export async function resetWorkspace({ rootDir = path.resolve(import.meta.dirname, '..'), mode, now = new Date() } = {}) {
  if (!['demo', 'starter'].includes(mode)) throw new Error('Choose an explicit mode: --demo or --starter');
  if (mode === 'starter') return restoreSnapshot({ rootDir, name: 'starter-v1', now });
  const snapshot = await createSnapshot({ rootDir, label: 'before-reset-demo', now });
  const tables = await loadDemoSeed(rootDir, { now });
  return { mode, snapshot: snapshot.directory, tables };
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  try {
    const mode = process.argv.includes('--demo') ? 'demo' : process.argv.includes('--starter') ? 'starter' : undefined;
    const result = await resetWorkspace({ mode });
    process.stdout.write(`RESET_COMPLETE ${mode}\nSafety snapshot: ${result.snapshot || result.backup?.directory}\n`);
  } catch (error) {
    process.stderr.write(`RESET_FAILED\n${error.message}\n`);
    process.exitCode = 1;
  }
}
