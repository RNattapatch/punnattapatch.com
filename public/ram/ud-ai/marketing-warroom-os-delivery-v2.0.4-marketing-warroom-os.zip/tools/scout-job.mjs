import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

import { createStore, validateRecord } from '../app/store.mjs';

const TERMINAL = new Set(['done', 'failed', 'preflight_failed']);
const MAX_MEDIA_BYTES = 100 * 1024 * 1024;
const MAX_STAGING_JSON_BYTES = 1024 * 1024;

async function jobById(store, jobId) {
  const job = (await store.read('newsroom_jobs')).items.find((item) => item.id === jobId);
  if (!job) throw new Error(`newsroom job not found: ${jobId}`);
  return job;
}

export async function claimScoutJob({ rootDir = path.resolve(import.meta.dirname, '..'), jobId, now = new Date().toISOString() } = {}) {
  const store = createStore({ rootDir });
  const jobs = (await store.read('newsroom_jobs')).items;
  const job = jobId ? jobs.find((item) => item.id === jobId) : jobs.find((item) => item.status === 'queued');
  if (!job || job.status !== 'queued' || TERMINAL.has(job.status)) return null;
  return store.patch('newsroom_jobs', job.id, {
    status: 'running', error: null, attempts: Number(job.attempts || 0) + 1, updated_at: now,
    result: { ...(job.result || {}), capability_mode: 'claimed' }
  });
}

export async function requestScoutEvidence({ rootDir = path.resolve(import.meta.dirname, '..'), jobId, reason, nextAction, sourceUrl, now = new Date().toISOString() } = {}) {
  if (!String(reason || '').trim()) throw new Error('Evidence request requires a reason');
  if (!String(nextAction || '').trim()) throw new Error('Evidence request requires an explicit next action');
  const store = createStore({ rootDir });
  const job = await jobById(store, jobId);
  if (job.status !== 'running') throw new Error(`Only a running job can request evidence: ${jobId}`);
  return store.patch('newsroom_jobs', jobId, {
    status: 'preflight_failed', error: String(reason).trim(), updated_at: now,
    result: {
      ...(job.result || {}), capability_mode: 'manual-evidence', reason: String(reason).trim(),
      next_action: String(nextAction).trim(), ...(sourceUrl ? { source_url: String(sourceUrl).trim() } : {})
    }
  });
}

function mediaReferences(item) {
  const references = [];
  if (item.cover_path) references.push(item.cover_path);
  for (const media of item.media || []) {
    if (typeof media === 'string') references.push(media);
    else if (media && typeof media === 'object' && media.path) references.push(media.path);
  }
  return references;
}

async function validateMedia(rootDir, item) {
  const mediaRoot = path.resolve(rootDir, 'data/files/newsroom');
  for (const reference of mediaReferences(item)) {
    if (typeof reference !== 'string' || path.isAbsolute(reference) || /^[A-Za-z][A-Za-z0-9+.-]*:/.test(reference)) {
      throw new Error('Published media must be below data/files/newsroom');
    }
    const relative = reference.startsWith('data/files/') ? reference.slice('data/files/'.length) : reference;
    if (!relative.startsWith('newsroom/')) throw new Error('Published media must be below data/files/newsroom');
    const resolved = path.resolve(rootDir, 'data/files', relative);
    if (!resolved.startsWith(`${mediaRoot}${path.sep}`)) throw new Error('Published media must be below data/files/newsroom');
    let info;
    try { info = await stat(resolved); } catch (error) {
      if (error.code === 'ENOENT') throw new Error(`Published media does not exist: ${reference}`);
      throw error;
    }
    if (!info.isFile()) throw new Error(`Published media is not a file: ${reference}`);
    if (info.size > MAX_MEDIA_BYTES) throw new Error(`Published media exceeds ${MAX_MEDIA_BYTES} bytes: ${reference}`);
  }
}

export async function completeScoutJob({ rootDir = path.resolve(import.meta.dirname, '..'), jobId, item, capabilityMode, now = new Date().toISOString() } = {}) {
  if (!item || typeof item !== 'object' || Array.isArray(item)) throw new Error('Completion requires one newsroom item');
  if (!String(capabilityMode || '').trim()) throw new Error('Completion requires capabilityMode');
  const store = createStore({ rootDir });
  const job = await jobById(store, jobId);
  if (job.status !== 'running') throw new Error(`Only a running job can complete: ${jobId}`);
  const linkedItem = { ...item, job_id: jobId, target_id: item.target_id || job.target_id, created_at: item.created_at || now };
  validateRecord('newsroom_items', linkedItem);
  await validateMedia(rootDir, linkedItem);
  await store.create('newsroom_items', linkedItem);
  try {
    const completedJob = await store.patch('newsroom_jobs', jobId, {
      status: 'done', item_id: linkedItem.id, error: null, updated_at: now,
      result: { ...(job.result || {}), capability_mode: String(capabilityMode).trim(), item_id: linkedItem.id }
    });
    return { job: completedJob, item: linkedItem };
  } catch (error) {
    await store.remove('newsroom_items', linkedItem.id);
    throw error;
  }
}

function resolveStagingJson(rootDir, relativePath) {
  if (typeof relativePath !== 'string' || path.isAbsolute(relativePath)) throw new Error('Staging JSON must be below output/scout-staging');
  const stagingRoot = path.resolve(rootDir, 'output/scout-staging');
  const resolved = path.resolve(rootDir, relativePath);
  if (!resolved.startsWith(`${stagingRoot}${path.sep}`) || path.extname(resolved).toLowerCase() !== '.json') {
    throw new Error('Staging JSON must be below output/scout-staging');
  }
  return resolved;
}

async function readStagingJson(rootDir, relativePath) {
  const filename = resolveStagingJson(rootDir, relativePath);
  const info = await stat(filename);
  if (!info.isFile() || info.size > MAX_STAGING_JSON_BYTES) throw new Error('Staging JSON must be a file no larger than 1 MB');
  return JSON.parse(await readFile(filename, 'utf8'));
}

async function runCli(argv) {
  const rootDir = path.resolve(import.meta.dirname, '..');
  const [command, jobId, inputPath] = argv;
  if (command === 'claim') return claimScoutJob({ rootDir, jobId });
  if (command === 'needs-evidence') {
    if (!jobId || !inputPath) throw new Error('Usage: node tools/scout-job.mjs needs-evidence <job-id> <output/scout-staging/request.json>');
    const request = await readStagingJson(rootDir, inputPath);
    return requestScoutEvidence({ rootDir, jobId, reason: request.reason, nextAction: request.next_action || request.nextAction, sourceUrl: request.source_url || request.sourceUrl });
  }
  if (command === 'complete') {
    if (!jobId || !inputPath) throw new Error('Usage: node tools/scout-job.mjs complete <job-id> <output/scout-staging/item.json>');
    const payload = await readStagingJson(rootDir, inputPath);
    return completeScoutJob({ rootDir, jobId, item: payload.item || payload, capabilityMode: payload.capability_mode || payload.capabilityMode || 'agent-assisted' });
  }
  throw new Error('Usage: node tools/scout-job.mjs <claim|needs-evidence|complete> [job-id] [staging-json]');
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  try {
    const result = await runCli(process.argv.slice(2));
    process.stdout.write(`${result ? JSON.stringify(result, null, 2) : 'null'}\n`);
  } catch (error) {
    process.stderr.write(`❌ ${error.message}\n`);
    process.exitCode = 1;
  }
}

export { MAX_MEDIA_BYTES, MAX_STAGING_JSON_BYTES };
