import { mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { stableId, slugify } from './delivery-state.mjs';

const REQUIRED_TEXT = ['company_name', 'business', 'offer', 'persona'];
const REQUIRED_LISTS = ['voice', 'rules', 'niche_criteria'];
const OWNER_ROLES = ['owner', 'reviewer', 'operator'];
const TARGET_ROLES = new Set(['competitor', 'benchmark', 'mentor']);

function isNonEmptyText(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

function uniqueBy(items, getKey) {
  const seen = new Set();
  return items.filter((item) => {
    const key = getKey(item);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function validHttps(value) {
  try {
    return new URL(value).protocol === 'https:';
  } catch {
    return false;
  }
}

export function validateClientContext(value) {
  const errors = [];
  if (!value || typeof value !== 'object' || Array.isArray(value)) return { ok: false, errors: ['context must be a JSON object'] };

  for (const field of REQUIRED_TEXT) if (!isNonEmptyText(value[field])) errors.push(`${field} is required`);
  for (const field of REQUIRED_LISTS) {
    if (!Array.isArray(value[field]) || value[field].length === 0 || value[field].some((item) => !isNonEmptyText(item))) {
      errors.push(`${field} must contain non-empty text`);
    }
  }
  for (const role of OWNER_ROLES) if (!isNonEmptyText(value.owners?.[role])) errors.push(`owners.${role} is required`);

  const sources = Array.isArray(value.sources) ? value.sources : [];
  sources.forEach((source, index) => {
    if (!isNonEmptyText(source?.name)) errors.push(`sources[${index}].name is required`);
    if (!validHttps(source?.url)) errors.push(`sources[${index}].url must be HTTPS`);
    if (!isNonEmptyText(source?.topic)) errors.push(`sources[${index}].topic is required`);
    if (!Array.isArray(source?.tags) || source.tags.some((tag) => !isNonEmptyText(tag))) errors.push(`sources[${index}].tags must be text`);
  });
  if (uniqueBy(sources.filter((source) => validHttps(source?.url)), (source) => new URL(source.url).href).length < 2) {
    errors.push('sources must contain at least 2 unique HTTPS feeds');
  }

  const targets = Array.isArray(value.intel_targets) ? value.intel_targets : [];
  targets.forEach((target, index) => {
    if (!isNonEmptyText(target?.name)) errors.push(`intel_targets[${index}].name is required`);
    if (!validHttps(target?.url)) errors.push(`intel_targets[${index}].url must be HTTPS`);
    if (!TARGET_ROLES.has(target?.role)) errors.push(`intel_targets[${index}].role must be competitor, benchmark, or mentor`);
    if (!isNonEmptyText(target?.why_watch)) errors.push(`intel_targets[${index}].why_watch is required`);
  });
  if (uniqueBy(targets.filter((target) => validHttps(target?.url)), (target) => new URL(target.url).href).length < 1) {
    errors.push('intel_targets must contain at least 1 unique HTTPS target');
  }
  return { ok: errors.length === 0, errors };
}

function markdown(title, value) {
  const lines = Array.isArray(value) ? value.map((item) => `- ${item.trim()}`).join('\n') : value.trim();
  return `# ${title}\n\n${lines}\n`;
}

function sourceRecord(source, createdAt) {
  return {
    id: stableId('SRC', new URL(source.url).href),
    name: source.name.trim(),
    url: new URL(source.url).href,
    topic: source.topic.trim(),
    tags: source.tags.map((tag) => tag.trim()),
    type: 'rss',
    active: true,
    added_at: createdAt
  };
}

function targetRecord(target, createdAt) {
  const url = new URL(target.url).href;
  const role = target.role;
  return {
    id: stableId('TGT', url),
    slug: slugify(target.name),
    name: target.name.trim(),
    aliases: [],
    role: [role],
    threat: role === 'competitor' ? 'orange' : role === 'mentor' ? 'na' : 'green',
    section: role,
    handles: [{ platform: 'web', ref: url }],
    handle_suggestions: [],
    handles_enriched_at: null,
    reach: 'Not specified',
    sells: 'Not specified',
    icp: 'Not specified',
    why_watch: target.why_watch.trim(),
    triggers: [],
    deep_dive: '',
    cadence_days: 30,
    last_scouted_at: null,
    next_scout_at: createdAt,
    avatar_path: null,
    created_at: createdAt,
    updated_at: createdAt
  };
}

async function installStagedFiles(rootDir, stagedFiles) {
  const rollback = [];
  try {
    for (const { relativePath, stagedPath } of stagedFiles) {
      const targetPath = path.join(rootDir, relativePath);
      let prior = null;
      try { prior = await readFile(targetPath); } catch (error) { if (error.code !== 'ENOENT') throw error; }
      rollback.push({ targetPath, prior });
      await rename(stagedPath, targetPath);
    }
  } catch (error) {
    for (const item of rollback.reverse()) {
      if (item.prior === null) await rm(item.targetPath, { force: true });
      else await writeFile(item.targetPath, item.prior);
    }
    throw error;
  }
}

export async function clientize({ rootDir = path.resolve(import.meta.dirname, '..'), contextPath, now = new Date() } = {}) {
  if (!contextPath) throw new Error('contextPath is required');
  const context = JSON.parse(await readFile(path.resolve(contextPath), 'utf8'));
  const validation = validateClientContext(context);
  if (!validation.ok) throw new Error(validation.errors.join('\n'));

  const createdAt = now.toISOString();
  const sources = uniqueBy(context.sources, (source) => new URL(source.url).href).map((source) => sourceRecord(source, createdAt));
  const targets = uniqueBy(context.intel_targets, (target) => new URL(target.url).href).map((target) => targetRecord(target, createdAt));
  const outputs = new Map([
    ['company/business.md', markdown('Business', context.business)],
    ['company/offer.md', markdown('Offer', context.offer)],
    ['company/persona.md', markdown('Persona', context.persona)],
    ['company/voice.md', markdown('Voice', context.voice)],
    ['company/niche-criteria.md', markdown('Niche Criteria', context.niche_criteria)],
    ['company/RULES.md', markdown('Company Rules', context.rules)],
    ['company/pre-work.md', `# Pre-work\n\nClientized for ${context.company_name.trim()} on ${createdAt}.\n`],
    ['company/config.json', `${JSON.stringify({
      company_name: context.company_name.trim(),
      max_news_per_day: Number.isInteger(context.max_news_per_day) && context.max_news_per_day > 0 ? context.max_news_per_day : 3,
      kie_api_key: '',
      local_usage_log: false,
      owners: Object.fromEntries(OWNER_ROLES.map((role) => [role, context.owners[role].trim()]))
    }, null, 2)}\n`],
    ['data/ca_sources.json', `${JSON.stringify({ version: 1, items: sources }, null, 2)}\n`],
    ['data/intel_targets.json', `${JSON.stringify({ version: 1, items: targets }, null, 2)}\n`]
  ]);

  const stageDir = path.join(rootDir, `.clientize-stage-${process.pid}-${process.hrtime.bigint()}`);
  const stagedFiles = [];
  try {
    for (const [relativePath, content] of outputs) {
      const stagedPath = path.join(stageDir, relativePath);
      await mkdir(path.dirname(stagedPath), { recursive: true });
      await writeFile(stagedPath, content, { mode: 0o600 });
      if (relativePath.endsWith('.json')) JSON.parse(await readFile(stagedPath, 'utf8'));
      stagedFiles.push({ relativePath, stagedPath });
    }
    await installStagedFiles(rootDir, stagedFiles);
  } finally {
    await rm(stageDir, { recursive: true, force: true });
  }
  return { companyName: context.company_name.trim(), sources: sources.length, targets: targets.length };
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  try {
    const result = await clientize({ contextPath: process.argv[2] });
    process.stdout.write(`CLIENTIZED ${result.companyName}\nSources: ${result.sources}\nTargets: ${result.targets}\n`);
  } catch (error) {
    process.stderr.write(`CLIENTIZATION_FAILED\n${error.message}\n`);
    process.exitCode = 1;
  }
}
