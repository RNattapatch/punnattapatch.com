import { chmod } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { buildKit } from './build-kit.mjs';
import { runDoctor } from './doctor.mjs';

export async function setupWorkspace({ rootDir = path.resolve(import.meta.dirname, '..') } = {}) {
  await buildKit({ rootDir });
  await chmod(path.join(rootDir, 'Open Workspace.command'), 0o755);
  return runDoctor({ rootDir, mode: 'preflight' });
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  const result = await setupWorkspace();
  process.stdout.write(`${result.ok ? 'SETUP_READY' : 'SETUP_FAILED'}\n`);
  process.exitCode = result.ok ? 0 : 1;
}
