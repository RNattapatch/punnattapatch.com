import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

import { createStore, TABLES } from '../app/store.mjs';

const validItems = {
  ca_sources: { id: 'SRC-1', url: 'https://example.invalid/feed.xml', topic: 'AI', tags: ['ai'], type: 'rss', active: true, added_at: '2026-09-05T00:00:00.000Z' },
  ca_news_items: { id: 'NEWS-1', source_id: 'SRC-1', url: 'https://example.invalid/a', title: 'Example', summary: 'Summary', published_at: '2026-09-04T00:00:00.000Z', fetched_at: '2026-09-05T00:00:00.000Z', status: 'new', content_hash: 'abc' },
  ca_candidates: { id: 'CAN-1', news_item_id: 'NEWS-1', article_md: 'article', edited_article_md: null, hooks: [{ id: 'h1', style: 'insight', text: 'hook' }], images: [], status: 'pending_review', selected_hook: null, selected_image: null, post_to_ig: false, scheduled_at: null, created_at: '2026-09-05T00:00:00.000Z', comment_thread: [{ role: 'cta', text: 'cta' }, { role: 'article', text: 'article' }, { role: 'source', text: 'source' }, { role: 'angle2', text: 'angle2' }, { role: 'cases', text: 'cases' }], glance_line: 'glance', scene_prompt: 'scene', scene_field: 'office' },
  ca_post_log: { id: 'POST-1', candidate_id: 'CAN-1', platform: 'facebook', post_id: null, permalink: null, error: null, posted_at: '2026-09-05T00:00:00.000Z' },
  content_items: { content_id: 'CNT-2026-09-05-001', title: 'Idea', canonical_angle: 'Angle', topic_cluster: 'AI', funnel_stage: 'top', pillar_bucket: 'ai_in_business', angle_type: 'how_to', acid_test: 'pending', offer_link: null, source_type: 'webapp', source_ref: 'manual', idea_status: 'captured', freshness_score: 1, similarity_group: null, decision_label: null, created_at: '2026-09-05T00:00:00.000Z', last_used_at: null },
  content_variants: { variant_id: 'CNT-2026-09-05-001-RL', content_id: 'CNT-2026-09-05-001', format: 'reel', target_platforms: ['tiktok'], working_title: 'Idea reel', markdown_path: 'output/content/reel/CNT-2026-09-05-001-RL--idea.md', variant_status: 'draft', cta_keyword: 'AI', editorial_status: 'draft', publish_target_at: null, published_at: null, created_at: '2026-09-05T00:00:00.000Z', status_changed_at: '2026-09-05T00:00:00.000Z', script_draft: '', ai_result: null, ai_result_at: null },
  publications: { publication_id: 'PUB-1', variant_id: 'CNT-2026-09-05-001-RL', platform: 'facebook', post_url: 'https://example.invalid/post', post_id: null, published_at: '2026-09-05T00:00:00.000Z', caption_path: null, first_comment: null, utm_campaign: null, status: 'posted', decision_label: 'iterate', created_at: '2026-09-05T00:00:00.000Z' },
  analytics_snapshots: { snapshot_id: 'SNAP-1', publication_id: 'PUB-1', captured_at: '2026-09-05T00:00:00.000Z', source: 'manual', views: 10, reach: 8, watch_time_avg: 2, completion_rate: 0.2, likes: 2, comments: 1, shares: 0, saves: 1, profile_visits: 1, follows: 0, keyword_comments: 1, dm_count: 0, line_adds: 0, leads_created: 0, notes: '' },
  intel_targets: { id: 'TGT-1', slug: 'example-brand', name: 'Example Brand', aliases: [], role: ['competitor'], threat: 'orange', section: 'competitor', handles: [{ platform: 'web', ref: 'https://example.invalid' }], handle_suggestions: [], handles_enriched_at: null, reach: 'regional', sells: 'service', icp: 'SME', why_watch: 'positioning', triggers: [], deep_dive: '', cadence_days: 14, last_scouted_at: null, next_scout_at: '2026-09-20T00:00:00.000Z', avatar_path: null, created_at: '2026-09-05T00:00:00.000Z', updated_at: '2026-09-05T00:00:00.000Z' },
  intel_snapshots: { id: 'IS-1', target_id: 'TGT-1', item_id: 'NR-1', lane: 'web', metrics: { views: 10 }, created_at: '2026-09-05T00:00:00.000Z' },
  newsroom_items: { id: 'NR-1', job_id: 'NJ-1', kind: 'web', platform: 'web', source_url: 'https://example.invalid', title: 'Launch', channel: 'website', summary: 'Summary', verdict: 'watch', score: 70, views: 0, duration_s: 0, cover_path: null, media: [], report_md: '# Report', report_path: 'wiki/intel/scout/example.md', tags: ['launch'], scraped_at: '2026-09-05T00:00:00.000Z', created_at: '2026-09-05T00:00:00.000Z', target_id: 'TGT-1' },
  newsroom_jobs: { id: 'NJ-1', kind: 'web', target: 'https://example.invalid', note: '', status: 'queued', scout_job_id: null, item_id: null, error: null, created_at: '2026-09-05T00:00:00.000Z', updated_at: '2026-09-05T00:00:00.000Z', target_id: 'TGT-1', batch_id: 'B-1', lane: 'web', result: {}, attempts: 0 },
  intel_scripts: { id: 'IS-1', item_id: 'NR-1', job_id: 'JOB-1', title: 'ทำคอนเทนต์บอกราคา ผิดไหม', brief: { theme: 'ทำคอนเทนต์บอกราคา ผิดไหม', pillar: 'sales_team', hook_style: 'question', length: 'mid', cta_keyword: 'AI', notes: '' }, script_md: '# Hook', content_id: null, created_at: '2026-09-08T00:00:00.000Z' },
  wr_jobs: { id: 'JOB-1', job_type: 'ai_improve', payload: { variant_id: 'CNT-2026-09-05-001-RL' }, status: 'queued', result: {}, error: null, created_at: '2026-09-05T00:00:00.000Z', started_at: null, finished_at: null },
  notifications: { id: 'NOT-1', title: 'Morning brief', body: '3 stories', read: false, created_at: '2026-09-05T00:00:00.000Z' },
  agent_requests: { id: 'REQ-1', newsroom_job_id: 'NJ-1', title: 'Fix scout', prompt: 'Inspect the failed web lane.', status: 'open', created_at: '2026-09-05T00:00:00.000Z' }
};

async function fixture() {
  const rootDir = await mkdtemp(path.join(os.tmpdir(), 'warroom-store-'));
  await mkdir(path.join(rootDir, 'data'), { recursive: true });
  for (const table of TABLES) await writeFile(path.join(rootDir, 'data', `${table}.json`), '{"version":1,"items":[]}\n');
  return { rootDir, store: createStore({ rootDir }) };
}

test('all declared tables persist valid records through create, read, update, and delete', async (t) => {
  const { rootDir, store } = await fixture();
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  assert.deepEqual(new Set(TABLES), new Set(Object.keys(validItems)));
  for (const [table, item] of Object.entries(validItems)) {
    const created = await store.create(table, item);
    assert.equal(created.items.length, 1, `${table} create`);
    assert.equal((await store.read(table)).items.length, 1, `${table} read`);
    const key = store.idField(table);
    const updated = await store.update(table, item[key], { ...item, [key]: item[key] });
    assert.equal(updated[key], item[key], `${table} update`);
    assert.equal(await store.remove(table, item[key]), true, `${table} delete`);
    assert.equal((await store.read(table)).items.length, 0, `${table} empty`);
  }
});

test('invalid enums are rejected without corrupting the stored collection', async (t) => {
  const { rootDir, store } = await fixture();
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  await assert.rejects(store.create('ca_sources', { ...validItems.ca_sources, type: 'email' }), /Schema validation failed/);
  assert.deepEqual(JSON.parse(await readFile(path.join(rootDir, 'data/ca_sources.json'), 'utf8')).items, []);
});

test('query filters records and patch preserves unspecified fields', async (t) => {
  const { rootDir, store } = await fixture();
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  await store.create('ca_sources', validItems.ca_sources);
  await store.create('ca_sources', { ...validItems.ca_sources, id: 'SRC-2', active: false });
  assert.deepEqual((await store.query('ca_sources', { active: 'true' })).items.map((x) => x.id), ['SRC-1']);
  const patched = await store.patch('ca_sources', 'SRC-1', { topic: 'Sales' });
  assert.equal(patched.topic, 'Sales');
  assert.equal(patched.url, validItems.ca_sources.url);
});

test('path safety rejects traversal and direct markdown writes stay inside output/content', async (t) => {
  const { rootDir, store } = await fixture();
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  await assert.rejects(store.writeMarkdown('../outside.md', 'bad'), /outside allowed root/);
  const relative = 'output/content/reel/example.md';
  await store.writeMarkdown(relative, '# Safe');
  assert.equal(await readFile(path.join(rootDir, relative), 'utf8'), '# Safe\n');
});
