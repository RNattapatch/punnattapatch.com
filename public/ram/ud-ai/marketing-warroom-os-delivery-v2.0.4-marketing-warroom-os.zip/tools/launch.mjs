import { spawn } from 'node:child_process';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createAppServer } from '../app/server.mjs';
import { getWorkspaceIdentity } from './delivery-state.mjs';
import { probePort, runDoctor } from './doctor.mjs';

export function browserCommand(platform, url) {
  if (platform === 'darwin') return { command: 'open', args: [url] };
  if (platform === 'win32') return { command: 'cmd', args: ['/c', 'start', '', url] };
  return { command: 'xdg-open', args: [url] };
}

async function defaultOpenBrowser(url) {
  const selected = browserCommand(os.platform(), url);
  const child = spawn(selected.command, selected.args, { detached: true, stdio: 'ignore', windowsHide: true });
  child.unref();
}

function listen(server, port, host) {
  return new Promise((resolve, reject) => {
    const onError = (error) => reject(error);
    server.once?.('error', onError);
    server.listen(port, host, () => {
      server.off?.('error', onError);
      resolve();
    });
  });
}

function close(server) {
  return new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
}

export async function launch({
  rootDir = path.resolve(import.meta.dirname, '..'),
  port = 4173,
  portProbe = probePort,
  runPreflight = runDoctor,
  serverFactory = () => createAppServer({ rootDir }),
  openBrowser = defaultOpenBrowser
} = {}) {
  const url = `http://127.0.0.1:${port}/content`;
  const state = await portProbe(port);
  if (state.state === 'occupied') {
    if (state.workspaceIdentity !== getWorkspaceIdentity(rootDir)) throw new Error(`Port ${port} is occupied by another process`);
    await openBrowser(url);
    return { reused: true, url, close: async () => {} };
  }
  const doctor = await runPreflight({ rootDir, mode: 'preflight', port, portProbe: async () => state });
  if (!doctor.ok) throw new Error(`Preflight failed: ${doctor.checks.filter((item) => item.status === 'FAIL').map((item) => item.name).join(', ')}`);
  const server = serverFactory();
  await listen(server, port, '127.0.0.1');
  await openBrowser(url);
  return { reused: false, url, server, close: () => close(server) };
}

// Agent sessions (Claude Code, Codex) kill a tool call that does not return, which would kill a
// foreground server with it. --detach hands the server to a background process and returns as soon
// as the workspace answers on the port.
export async function launchDetached({
  rootDir = path.resolve(import.meta.dirname, '..'),
  port = 4173,
  scriptPath = import.meta.filename,
  portProbe = probePort,
  spawnProcess = spawn,
  waitMs = 20000,
  pollMs = 250,
  now = () => Date.now(),
  sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))
} = {}) {
  const url = `http://127.0.0.1:${port}/content`;
  const identity = getWorkspaceIdentity(rootDir);
  const state = await portProbe(port);
  if (state.state === 'occupied') {
    if (state.workspaceIdentity !== identity) throw new Error(`Port ${port} is occupied by another process`);
    return { reused: true, url, pid: null };
  }
  const child = spawnProcess(process.execPath, [scriptPath], { cwd: rootDir, detached: true, stdio: 'ignore', windowsHide: true });
  child.unref?.();
  const deadline = now() + waitMs;
  while (now() < deadline) {
    await sleep(pollMs);
    const probe = await portProbe(port);
    if (probe.state === 'occupied' && probe.workspaceIdentity === identity) return { reused: false, url, pid: child.pid };
  }
  throw new Error(`Workspace did not answer on 127.0.0.1:${port} within ${Math.round(waitMs / 1000)}s — run node tools/doctor.mjs --preflight`);
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  try {
    if (process.argv.includes('--detach')) {
      const running = await launchDetached();
      process.stdout.write(`${running.reused ? 'WORKSPACE_ALREADY_RUNNING' : 'WORKSPACE_RUNNING'}\n${running.url}\n${running.pid ? `pid ${running.pid}\n` : ''}`);
    } else {
      const running = await launch();
      process.stdout.write(`${running.reused ? 'WORKSPACE_ALREADY_RUNNING' : 'WORKSPACE_RUNNING'}\n${running.url}\n`);
      if (!running.reused) {
        await new Promise((resolve) => {
          const shutdown = async () => { await running.close(); resolve(); };
          process.once('SIGINT', shutdown);
          process.once('SIGTERM', shutdown);
        });
      }
    }
  } catch (error) {
    process.stderr.write(`LAUNCH_FAILED\n${error.message}\n`);
    process.exitCode = 1;
  }
}
