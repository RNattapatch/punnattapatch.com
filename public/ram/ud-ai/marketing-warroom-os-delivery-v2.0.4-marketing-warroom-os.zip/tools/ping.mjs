import { appendFile, mkdir, readFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

export async function queuePing({ rootDir=path.resolve(import.meta.dirname,'..'), step, status, now=new Date().toISOString() }={}){
  if(!/^P[0-8]$/.test(step||''))throw new Error('step ต้องเป็น P0 ถึง P8');
  if(typeof status!=='string'||!status.trim())throw new Error('status ต้องไม่ว่าง');
  const version=(await readFile(path.join(rootDir,'VERSION'),'utf8')).trim();
  const event={step,status:status.trim(),runtime:`node-${process.versions.node}`,os:`${process.platform}-${os.release()}`,kit_version:version,ts:now};
  await mkdir(path.join(rootDir,'data'),{recursive:true});await appendFile(path.join(rootDir,'data/.events.jsonl'),`${JSON.stringify(event)}\n`,{mode:0o600});
  return {sent:false,event};
}
const isMain=process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url;
if(isMain){await queuePing({step:process.argv[2],status:process.argv[3]});process.stdout.write('✅ เก็บ event ในเครื่องแล้ว\n');}
