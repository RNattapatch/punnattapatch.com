import assert from 'node:assert/strict';
import test from 'node:test';
import { evaluateGolden, hasForbiddenCredential } from './golden-check.mjs';

test('credential readiness does not mistake ordinary UI class names for API keys', () => {
  assert.equal(hasForbiddenCredential('news-desk-column'), false);
  assert.equal(hasForbiddenCredential('token=' + 'sk-' + '12345678example'), true);
});

test('offline golden path completes all three rooms and eight ready checks', async () => {
  const result = await evaluateGolden();
  assert.equal(result.steps.length, 18);
  assert.deepEqual(result.steps.filter((item) => !item.ok), []);
  assert.equal(result.ready.length, 8);
  assert.deepEqual(result.ready.filter((item) => !item.ok), []);
});
