import assert from 'node:assert/strict';
import { readFile, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import test from 'node:test';
import { clientize } from './clientize.mjs';
import { getWorkspaceIdentity } from './delivery-state.mjs';
import { runDoctor } from './doctor.mjs';
import { makeTemplateWorkspace, makeTestWorkspace } from './delivery-test-helpers.mjs';
import { createSnapshot } from './snapshot.mjs';

async function clientizeExample(rootDir) {
  return clientize({ rootDir, contextPath: path.join(rootDir, 'examples/client-context.example.json'), now: new Date('2026-09-12T00:00:00.000Z') });
}

function status(result, name) {
  return result.checks.find((check) => check.name === name)?.status;
}

test('preflight returns structured PASS WARN FAIL checks and treats missing optional tools as warnings', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  const result = await runDoctor({
    rootDir: workspace.rootDir,
    mode: 'preflight',
    portProbe: async () => ({ state: 'available' }),
    commandProbe: () => false
  });

  assert.equal(result.ok, true);
  assert.equal(status(result, 'Node.js'), 'PASS');
  assert.equal(status(result, 'Port 4173'), 'PASS');
  assert.equal(status(result, 'Optional tools'), 'WARN');
  assert.ok(result.checks.every((check) => ['PASS', 'WARN', 'FAIL'].includes(check.status)));
});

test('preflight fails for a foreign occupied port but accepts the same workspace identity', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  const foreign = await runDoctor({ rootDir: workspace.rootDir, mode: 'preflight', portProbe: async () => ({ state: 'occupied', workspaceIdentity: 'foreign' }) });
  const same = await runDoctor({ rootDir: workspace.rootDir, mode: 'preflight', portProbe: async () => ({ state: 'occupied', workspaceIdentity: getWorkspaceIdentity(workspace.rootDir) }) });

  assert.equal(status(foreign, 'Port 4173'), 'FAIL');
  assert.equal(foreign.ok, false);
  assert.equal(status(same, 'Port 4173'), 'PASS');
});

test('preflight catches malformed tables, unwritable runtime paths, and credentials', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  await writeFile(path.join(workspace.rootDir, 'data/ca_sources.json'), '{broken');
  await writeFile(path.join(workspace.rootDir, 'company/leaked-note.md'), 'token: sk-' + 'live-example-value');
  const result = await runDoctor({
    rootDir: workspace.rootDir,
    mode: 'preflight',
    portProbe: async () => ({ state: 'available' }),
    writableProbe: async (directory) => !directory.endsWith(`${path.sep}wiki`)
  });

  assert.equal(status(result, 'Local tables'), 'FAIL');
  assert.equal(status(result, 'Writable workspace'), 'FAIL');
  assert.equal(status(result, 'Credential scan'), 'FAIL');
  assert.equal(result.ok, false);
});

test('company mode rejects template context and requires a verified starter baseline', async (t) => {
  const workspace = await makeTemplateWorkspace();
  t.after(workspace.cleanup);
  const sourceProbe = async () => ({ ok: true, items: 1 });
  const template = await runDoctor({ rootDir: workspace.rootDir, mode: 'company', requireStarter: false, portProbe: async () => ({ state: 'available' }), sourceProbe });
  assert.equal(status(template, 'Company context'), 'FAIL');
  assert.equal(status(template, 'Company owners'), 'FAIL');
  assert.equal(status(template, 'Active sources'), 'FAIL');
  assert.equal(status(template, 'Intel targets'), 'FAIL');

  await clientizeExample(workspace.rootDir);
  const noStarter = await runDoctor({ rootDir: workspace.rootDir, mode: 'company', portProbe: async () => ({ state: 'available' }), sourceProbe });
  assert.equal(status(noStarter, 'Company context'), 'PASS');
  assert.equal(status(noStarter, 'Company owners'), 'PASS');
  assert.equal(status(noStarter, 'Active sources'), 'PASS');
  assert.equal(status(noStarter, 'Intel targets'), 'PASS');
  assert.equal(status(noStarter, 'Starter baseline'), 'FAIL');

  await createSnapshot({ rootDir: workspace.rootDir, label: 'starter-v1', immutable: true, now: new Date('2026-09-12T00:30:00.000Z') });
  const withStarter = await runDoctor({ rootDir: workspace.rootDir, mode: 'company', portProbe: async () => ({ state: 'available' }), sourceProbe });
  assert.equal(status(withStarter, 'Starter baseline'), 'PASS');
  assert.equal(withStarter.ok, true);

  await writeFile(path.join(workspace.rootDir, 'snapshots/starter-v1/company/business.md'), '# Tampered\n');
  const corruptStarter = await runDoctor({ rootDir: workspace.rootDir, mode: 'company', portProbe: async () => ({ state: 'available' }), sourceProbe });
  assert.equal(status(corruptStarter, 'Starter baseline'), 'FAIL');
  assert.equal(corruptStarter.ok, false);
});

test('company mode fails when an HTTPS source is unreachable or is not a feed', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  await clientizeExample(workspace.rootDir);
  const sourceProbe = async (url) => url.includes('example.com')
    ? { ok: true, items: 2 }
    : { ok: false, items: 0, error: 'RSS HTTP 404' };

  const result = await runDoctor({
    rootDir: workspace.rootDir,
    mode: 'company',
    requireStarter: false,
    portProbe: async () => ({ state: 'available' }),
    sourceProbe
  });

  assert.equal(status(result, 'Active sources'), 'PASS');
  assert.equal(status(result, 'Source health'), 'FAIL');
  assert.match(result.checks.find((item) => item.name === 'Source health').detail, /RSS HTTP 404/);
  assert.equal(result.ok, false);
});

test('demo mode requires a complete three-room seed but accepts template company data', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  const pass = await runDoctor({ rootDir: workspace.rootDir, mode: 'demo', portProbe: async () => ({ state: 'available' }) });
  assert.equal(status(pass, 'Demo seed'), 'PASS');
  assert.equal(pass.ok, true);

  const seedPath = path.join(workspace.rootDir, 'examples/seed/three-rooms.json');
  const seed = JSON.parse(await readFile(seedPath, 'utf8'));
  delete seed.intel_targets;
  await writeFile(seedPath, JSON.stringify(seed));
  const fail = await runDoctor({ rootDir: workspace.rootDir, mode: 'demo', portProbe: async () => ({ state: 'available' }) });
  assert.equal(status(fail, 'Demo seed'), 'FAIL');
  assert.equal(fail.ok, false);
});

test('preflight fails when a required launcher or built agent skill tree is missing', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  await rm(path.join(workspace.rootDir, '.agents/skills/news-daily'), { recursive: true, force: true });
  await rm(path.join(workspace.rootDir, 'Open Workspace.bat'));
  const result = await runDoctor({ rootDir: workspace.rootDir, mode: 'preflight', portProbe: async () => ({ state: 'available' }) });
  assert.equal(status(result, 'Launchers'), 'FAIL');
  assert.equal(status(result, 'Agent skills'), 'FAIL');
});

test('preflight fails when delivery documentation or an onboarding skill is missing', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  await rm(path.join(workspace.rootDir, 'DELIVERY-GUIDE.md'));
  await rm(path.join(workspace.rootDir, '.claude/skills/install'), { recursive: true, force: true });
  const result = await runDoctor({ rootDir: workspace.rootDir, mode: 'preflight', portProbe: async () => ({ state: 'available' }) });
  assert.equal(status(result, 'Required files'), 'FAIL');
  assert.equal(status(result, 'Agent skills'), 'FAIL');
});

test('preflight requires the local feature matrix and unified worker skill', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  await rm(path.join(workspace.rootDir, 'LOCAL-FEATURE-MATRIX.md'), { force: true });
  await rm(path.join(workspace.rootDir, '.agents/skills/worker'), { recursive: true, force: true });
  const result = await runDoctor({ rootDir: workspace.rootDir, mode: 'preflight', portProbe: async () => ({ state: 'available' }) });
  assert.equal(status(result, 'Required files'), 'FAIL');
  assert.equal(status(result, 'Agent skills'), 'FAIL');
});
