import { access, cp, mkdir, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

import { createRequestDispatcher } from '../app/server.mjs';
import { createStore, TABLES } from '../app/store.mjs';
import { findSimilar } from '../app/lib/similar.mjs';
import { exportIntel } from './intel-export.mjs';
import { processQueuedJobs } from './jobs/run.mjs';
import { handoffScript } from './jobs/handoff-script.mjs';
import { runNewsDaily } from './news-daily.mjs';
import { lintCandidates, materializeCandidateFixture } from './lint-copy.mjs';
import { checkParity } from './parity-check.mjs';

async function exists(file) { try { await access(file); return true; } catch { return false; } }
async function textFiles(dir) {
  const found = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (['dist', '.bak', '.git'].includes(entry.name)) continue;
    const target = path.join(dir, entry.name);
    if (entry.isDirectory()) found.push(...await textFiles(target));
    else if (/\.(md|html|mjs|json)$/.test(entry.name)) found.push(target);
  }
  return found;
}

const FORBIDDEN_CREDENTIAL = new RegExp([
  '\\bsk-[A-Za-z0-9_-]{8,}\\b', 'Bearer [A-Za-z0-9._-]{12,}', '100\\.64\\.', 'agent' + 'macmini'
].join('|'), 'i');

export function hasForbiddenCredential(content) {
  return FORBIDDEN_CREDENTIAL.test(String(content));
}

export async function evaluateGolden({ rootDir = path.resolve(import.meta.dirname, '..') } = {}) {
  const workDir = await mkdtemp(path.join(os.tmpdir(), 'marketing-warroom-golden-'));
  const steps = [];
  try {
    await mkdir(path.join(workDir, 'data'), { recursive: true });
    await cp(path.join(rootDir, 'company'), path.join(workDir, 'company'), { recursive: true });
    await cp(path.join(rootDir, 'app'), path.join(workDir, 'app'), { recursive: true });
    for (const table of TABLES) await writeFile(path.join(workDir, 'data', `${table}.json`), '{"version":1,"items":[]}\n');
    const store = createStore({ rootDir: workDir });
    const seed = JSON.parse(await readFile(path.join(rootDir, 'examples/seed/three-rooms.json'), 'utf8'));
    for (const [table, items] of Object.entries(seed)) for (const item of items) await store.create(table, item);
    steps.push({ name: '1. โหลดข้อมูลสมมติครบสามห้อง', ok: (await store.read('content_items')).items.length === 2 && (await store.read('intel_targets')).items.length === 3 && (await store.read('ca_sources')).items.length === 3 });

    const briefOutDir = path.join(workDir, 'briefs');
    const news = await runNewsDaily({ rootDir: workDir, fixturesDir: path.join(rootDir, 'examples/rss'), briefOutDir, now: new Date('2026-09-05T10:00:00.000Z') });
    const beforeAgent = (await store.read('ca_candidates')).items;
    const briefFiles = (await readdir(briefOutDir)).filter((name) => name.endsWith('.brief.json'));
    steps.push({ name: '2. News ingest offline ดึงทุก source และเขียน brief โดยไม่สร้าง copy', ok: news.inserted === 3 && news.briefs === 3 && news.errors.length === 0 && briefFiles.length === 3 && beforeAgent.length === 0 });

    const expectedDir = path.join(rootDir, 'examples/expected/candidates');
    const expectedCandidates = [];
    for (const name of (await readdir(expectedDir)).filter((entry) => entry.endsWith('.json')).sort()) {
      const fixture = JSON.parse(await readFile(path.join(expectedDir, name), 'utf8'));
      const materialized = materializeCandidateFixture(fixture);
      expectedCandidates.push({
        id: materialized.id,
        news_item_id: materialized.news_item_id,
        article_md: materialized.article_md,
        edited_article_md: null,
        hooks: materialized.hooks,
        images: [],
        status: 'pending_review',
        selected_hook: null,
        selected_image: null,
        post_to_ig: false,
        scheduled_at: null,
        created_at: '2026-09-05T10:05:00.000Z',
        comment_thread: materialized.comment_thread,
        glance_line: materialized.glance_line,
        scene_prompt: materialized.scene_prompt,
        scene_field: materialized.scene_field
      });
    }
    const voiceText = await readFile(path.join(workDir, 'company/voice.md'), 'utf8');
    const copyLint = lintCandidates(expectedCandidates, { voiceText });
    const newsIds = new Set((await store.read('ca_news_items')).items.map((item) => item.id));
    for (const candidate of expectedCandidates) {
      await store.create('ca_candidates', candidate);
      await store.patch('ca_news_items', candidate.news_item_id, { status: 'generated' });
    }
    await store.create('notifications', { id:'NOT-GOLDEN-NEWS', title:'ข่าวรอเลือก', body:`☀️ มี ${expectedCandidates.length} ข่าวรอเลือกวันนี้`, read:false, created_at:'2026-09-05T10:06:00.000Z' });
    const generated = (await store.read('ca_candidates')).items;
    const wantedRoles = 'cta,article,source,angle2,cases';
    const generatedValid = generated.every((item)=>item.hooks.length===12 && [...item.article_md].filter((char)=>/[\u0E00-\u0E7F]/.test(char)).length>=1500 && (item.article_md.match(/📍/g)||[]).length===3 && item.comment_thread.map((entry)=>entry.role).join(',')===wantedRoles && item.glance_line && item.scene_prompt && newsIds.has(item.news_item_id));
    const newsGenerated = (await store.read('ca_news_items')).items.every((item) => item.status === 'generated');
    steps.push({ name: '3. Agent-output fixtures ผ่าน copy lint และสร้าง candidate ครบสัญญา', ok: expectedCandidates.length === 3 && generated.length === 3 && generatedValid && newsGenerated && copyLint.red.length === 0 && copyLint.yellow.length === 0 });
    const candidate = (await store.read('ca_candidates')).items[0];
    await store.create('wr_jobs', { id:'JOB-GOLDEN-CARD', job_type:'render_text_card', payload:{candidate_id:candidate.id,slug:'golden-card',glance_line:candidate.glance_line}, status:'queued', result:{}, error:null, created_at:'2026-09-05T10:30:00.000Z', started_at:null, finished_at:null });
    const cardRun = await processQueuedJobs({ rootDir:workDir, jobId:'JOB-GOLDEN-CARD' });
    const cardCandidate = (await store.read('ca_candidates')).items.find((item)=>item.id===candidate.id);
    steps.push({ name:'4. News text card เขียน artifact และผูกกลับ candidate', ok:cardRun.done===1 && cardCandidate.images.length===1 && cardCandidate.selected_image===0 && await exists(path.join(workDir,'data/files',cardCandidate.images[0].url.replace('/files/',''))) });
    await store.patch('ca_candidates', candidate.id, { selected_hook: 0, status: 'posted' });
    await store.create('ca_post_log', { id:'POST-GOLDEN', candidate_id:candidate.id, platform:'facebook', post_id:null, permalink:null, error:null, posted_at:'2026-09-05T11:00:00.000Z' });
    steps.push({ name: '5. News manual-post บันทึกสถานะและ post log', ok: (await store.read('ca_post_log')).items.length === 1 });

    const idea = (await store.read('content_items')).items[0];
    const similar = findSimilar('ทีมขายค้นข้อมูลจากจุดเดียว', [idea]);
    steps.push({ name: '6. Content quick capture ตรวจ idea ซ้ำ', ok: similar[0]?.content_id === idea.content_id });
    const newIdea={ ...idea, content_id:'CNT-2026-09-05-003', title:'ลดเวลาหาข้อมูลก่อนตอบลูกค้า', canonical_angle:'รวมหลักฐานให้ทีมใช้ชุดเดียว', idea_status:'active', created_at:'2026-09-05T11:10:00.000Z' };
    await store.create('content_items',newIdea);
    const variant={ variant_id:'CNT-2026-09-05-003-RL', content_id:newIdea.content_id, format:'reel', target_platforms:['tiktok','instagram','facebook'], working_title:newIdea.title, markdown_path:'output/content/reel/CNT-2026-09-05-003-RL--customer-data.md', variant_status:'draft', cta_keyword:'DATA', editorial_status:'draft', publish_target_at:null, published_at:null, created_at:'2026-09-05T11:15:00.000Z', status_changed_at:'2026-09-05T11:15:00.000Z', script_draft:'# Hook\nทีมขายหาข้อมูลซ้ำ', ai_result:null, ai_result_at:null };
    await store.create('content_variants',variant);
    steps.push({ name:'7. Content สร้าง idea ID และ RL variant', ok:(await store.read('content_items')).items.some((item)=>item.content_id==='CNT-2026-09-05-003') && (await store.read('content_variants')).items.some((item)=>item.variant_id===variant.variant_id) });
    const expectedImprove=JSON.parse(await readFile(path.join(rootDir,'examples/expected/content-improve.json'),'utf8'));
    await store.patch('content_variants',variant.variant_id,{ai_result:expectedImprove.ai_result,ai_result_at:'2026-09-05T11:30:00.000Z',variant_status:'posted',published_at:'2026-09-05T12:30:00.000Z',status_changed_at:'2026-09-05T12:30:00.000Z'});
    await store.writeMarkdown(variant.markdown_path, `---\nvariant_id: ${variant.variant_id}\nstatus: "posted"\n---\n\n${expectedImprove.ai_result}`);
    steps.push({ name: '8. Content improve fixture, ย้ายคอลัมน์ และเขียน Markdown', ok: (await store.read('content_variants')).items.find((item)=>item.variant_id===variant.variant_id).ai_result.includes('# Payoff') && await exists(path.join(workDir, variant.markdown_path)) });
    await store.create('publications', { publication_id:'PUB-GOLDEN', variant_id:variant.variant_id, platform:'tiktok', post_url:'manual-record', post_id:null, published_at:'2026-09-05T12:30:00.000Z', caption_path:null, first_comment:null, utm_campaign:null, status:'posted', decision_label:'iterate', created_at:'2026-09-05T12:30:00.000Z' });
    await store.create('analytics_snapshots', { snapshot_id:'SNAP-GOLDEN', publication_id:'PUB-GOLDEN', captured_at:'2026-09-07T13:00:00.000Z', source:'manual', views:100, reach:80, watch_time_avg:12, completion_rate:0.35, likes:12, comments:3, shares:2, saves:4, profile_visits:5, follows:1, keyword_comments:2, dm_count:1, line_adds:0, leads_created:1, notes:'fixture' });
    steps.push({ name: '9. Content publication และ snapshot 11 ช่องบันทึกครบ', ok: (await store.read('analytics_snapshots')).items[0].leads_created === 1 && Object.hasOwn((await store.read('analytics_snapshots')).items[0],'notes') });

    const target = (await store.read('intel_targets')).items[0]; const suggestion = target.handle_suggestions[0];
    await store.patch('intel_targets', target.id, { handles:[...target.handles,{platform:suggestion.platform,ref:suggestion.ref}], handle_suggestions:[], handles_enriched_at:'2026-09-05T13:00:00.000Z' });
    steps.push({ name: '10. Intel รับ suggestion เข้าแฟ้มโดยผู้ใช้', ok: (await store.read('intel_targets')).items[0].handles.length === 2 });
    const job = { id:'NJ-GOLDEN', kind:'web', target:'examples/web/example-brand.html', note:'fixture', status:'failed', scout_job_id:null, item_id:null, error:'fixture timeout', created_at:'2026-09-05T13:00:00.000Z', updated_at:'2026-09-05T13:00:00.000Z', target_id:target.id, batch_id:'B-GOLDEN', lane:'web', result:{}, attempts:1 };
    await store.create('newsroom_jobs', job);
    await store.create('agent_requests', { id:'REQ-GOLDEN', newsroom_job_id:job.id, title:'Fix fixture job', prompt:'ตรวจ lane web และ error แล้วเขียนผลกลับคิว', status:'open', created_at:'2026-09-05T13:01:00.000Z' });
    steps.push({ name: '11. Intel job ที่ล้มเหลวสร้าง Agent Fix request', ok: (await store.read('agent_requests')).items.length === 1 });
    const scoutExpected=JSON.parse(await readFile(path.join(rootDir,'examples/expected/scout-web.json'),'utf8'));
    await store.create('newsroom_items',scoutExpected.item);
    await store.create('intel_snapshots',scoutExpected.snapshot);
    await mkdir(path.join(workDir,'wiki/intel/scout'),{recursive:true});
    await writeFile(path.join(workDir,'wiki/intel/scout/example-brand.md'),scoutExpected.item.report_md);
    const firedTriggers=structuredClone(target.triggers);firedTriggers[0].fired_at=scoutExpected.item.created_at;firedTriggers[0].fired_by_item=scoutExpected.item.id;
    await store.patch('intel_targets',target.id,{triggers:firedTriggers,last_scouted_at:scoutExpected.item.created_at});
    steps.push({ name:'12. Intel Scout fixture เขียน item, report, snapshot และจุด trigger', ok:await exists(path.join(workDir,'wiki/intel/scout/example-brand.md')) && (await store.read('intel_snapshots')).items.length===1 && (await store.read('intel_targets')).items[0].triggers[0].fired_at!==null });
    firedTriggers[0].fired_at=null;firedTriggers[0].fired_by_item=null;await store.patch('intel_targets',target.id,{triggers:firedTriggers});
    steps.push({ name:'13. Intel ปิดธง trigger ได้', ok:(await store.read('intel_targets')).items[0].triggers[0].fired_at===null });
    const dossier = await exportIntel({ rootDir: workDir, targetId: target.id });
    steps.push({ name: '14. Intel export เขียน dossier และ watchlist', ok: await exists(path.join(workDir, dossier)) && await exists(path.join(workDir,'wiki/intel/watchlist.md')) });

    // เกลาคลิปเป็นบทของเราแล้วส่งข้ามห้องเข้า Content Center
    const transcript = Array.from({ length: 8 }, (_, index) => `[0:${String(index * 7).padStart(2, '0')}] ประโยคที่ถอดมาจากคลิปต้นทาง`).join('\n');
    await store.create('newsroom_items', { ...scoutExpected.item, id:'NR-GOLDEN-CLIP', kind:'clip', platform:'tiktok', title:'คลิปคู่แข่งเรื่องราคา', report_md:`${scoutExpected.item.report_md}\n\nตัวอย่างที่เอาไปใช้ได้: เปิดด้วยราคาแล้วค่อยเล่าเหตุผล\n${transcript}` });
    await store.create('wr_jobs', { id:'JOB-GOLDEN-RW', job_type:'rewrite_reel', payload:{ item_id:'NR-GOLDEN-CLIP', theme:'บอกราคาในคอนเทนต์ ผิดไหม', pillar:'sales_team', hook_style:'question', length:'mid', cta_keyword:'AI', notes:'' }, status:'queued', result:{}, error:null, created_at:'2026-09-05T14:00:00.000Z', started_at:null, finished_at:null });
    const rewriteRun = await processQueuedJobs({ rootDir: workDir, jobId: 'JOB-GOLDEN-RW' });
    const rewritten = (await store.read('intel_scripts')).items[0];
    steps.push({ name:'15. Intel เกลาคลิปเป็นบทของเรา และเปิดแฟ้มเวอร์ชันให้ agent เขียนต่อ', ok: rewriteRun.done === 1 && rewritten?.item_id === 'NR-GOLDEN-CLIP' && rewritten.content_id === null && rewritten.script_md.includes('# 📝 Caption') });
    // agent เขียนบทจริงทับโครงเปล่า แล้ว tool ส่งเข้า Content Center ให้เอง (ระบบต้นทาง 2026-09-08)
    const writtenScript = `# บอกราคาในคอนเทนต์ ผิดไหม\n\n# Hook (0-2 วิ — front-load payload)\nบอกราคาในคลิปแล้วลูกค้าหายไหม\n\n# Setup (2-10 วิ — สัญญาว่าจะได้เห็นอะไร)\nเดี๋ยวพาไปดูว่าทีมขายเจออะไร\n\n# Body\nเล่าเคสจาก company/\n\n↻ Rehook:\nแต่ที่หายจริงคืออะไร\n\n# Payoff\nราคาไม่ใช่ตัวไล่ลูกค้า ความไม่ชัดต่างหาก\n\n# CTA\nพิมพ์ AI มาได้เลย\n\n# 🔤 Hook Text\nบอกราคา | ผิดไหม\n\n# 📝 Caption\n📍 บอกราคาแล้วลูกค้าหาย? ไม่ใช่ที่ราคา\n📍 ความชัดต่างหากที่ปิดการขาย\n📍 พิมพ์ AI มา\n\n# 🧬 โครงที่ยืมมา\n- เปิดด้วยคำถามเจ็บจุด แล้วค่อยเฉลย\n- หักมุมกลางคลิปหนึ่งครั้ง`;
    await store.patch('intel_scripts', rewritten.id, { script_md: writtenScript });
    const handoff = await handoffScript({ rootDir: workDir, scriptId: rewritten.id });
    const handedOff = (await store.read('content_variants')).items.find((item) => item.variant_id === handoff.variant_id);
    const handoffJob = (await store.read('wr_jobs')).items.find((job) => job.id === 'JOB-GOLDEN-RW');
    const handoffIdea = (await store.read('content_items')).items.find((item) => item.content_id === handoff.content_id);
    steps.push({ name:'16. บทที่เกลาแล้วส่งเข้า Content Center เองเป็นไอเดีย + variant RL ที่มีบทอยู่ในช่อง AI และบันทึก content_id ลงงาน', ok: handedOff?.ai_result === writtenScript && handedOff.script_draft === '' && handoffIdea?.idea_status === 'active' && handoffIdea.source_ref.startsWith('intel:NR-GOLDEN-CLIP') && (await store.read('intel_scripts')).items[0].content_id === handoff.content_id && handoffJob?.result?.content_id === handoff.content_id });

    const dispatch = createRequestDispatcher({ rootDir: workDir });
    const voiceBefore = await readFile(path.join(workDir,'company/voice.md'),'utf8');
    const voiceResponse = await dispatch({ method:'POST', url:'/api/company/voice.md', headers:{'content-type':'text/markdown'}, body:'# Voice\n\n- Pronoun: เรา\n- Tones: ตรง, อบอุ่น, ใช้หลักฐาน' });
    const voiceAfter = await readFile(path.join(workDir,'company/voice.md'),'utf8');
    steps.push({ name:'17. Settings บันทึกเสียงแบรนด์กลับไฟล์', ok:voiceResponse.status===200 && voiceAfter!==voiceBefore && voiceAfter.includes('Pronoun: เรา') });
    const routes = await Promise.all(['/content','/news-desk','/intel','/jobs','/settings','/api/meta'].map((url) => dispatch({ method:'GET', url, headers:{} })));
    steps.push({ name: '18. Dispatcher เปิดทุกหน้าหลักและ meta', ok: routes.every((result) => result.status === 200) });

    const parity = await checkParity({ root: rootDir });
    const readable = await Promise.all((await textFiles(rootDir)).map((file) => readFile(file, 'utf8')));
    const ready = [
      { name:'1. เปิดจาก Shortcut ได้', ok: await exists(path.join(rootDir,'Open Workspace.command')) && await exists(path.join(rootDir,'Open Workspace.bat')) },
      { name:'2. อ่าน Company context ถูกชุด', ok: JSON.parse((await dispatch({method:'GET',url:'/api/meta',headers:{}})).body).companyName === JSON.parse(await readFile(path.join(rootDir,'company/config.json'),'utf8')).company_name },
      { name:'3. Golden path ผ่านครบสามห้อง', ok: steps.every((item)=>item.ok) },
      { name:'4. Output บันทึกกลับ Workspace', ok: await exists(path.join(workDir,variant.markdown_path)) && await exists(path.join(workDir,dossier)) },
      { name:'5. ผู้ใช้แก้ Company rule ได้โดยไม่แตะโค้ด', ok: (await dispatch({method:'PUT',url:'/api/company/business.md',headers:{'content-type':'text/markdown'},body:'# Updated'})).status === 200 },
      { name:'6. มี Dummy data และ Reset', ok: await exists(path.join(rootDir,'examples/seed/three-rooms.json')) && await exists(path.join(rootDir,'tools/reset.mjs')) },
      { name:'7. ไม่มี Credential หรือข้อมูลระบบจริง', ok: !readable.some(hasForbiddenCredential) },
      { name:'8. Parity manifest ผ่านครบ', ok: parity.ok && parity.count > 0 }
    ];
    return { steps, ready };
  } finally { await rm(workDir,{recursive:true,force:true}); }
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) { const result=await evaluateGolden(); process.stdout.write('Golden path\n'); for(const item of result.steps) process.stdout.write(`${item.ok?'✅':'❌'} ${item.name}\n`); process.stdout.write('Definition of ready\n'); for(const item of result.ready) process.stdout.write(`${item.ok?'✅':'❌'} ${item.name}\n`); process.exitCode=[...result.steps,...result.ready].every((x)=>x.ok)?0:1; }
