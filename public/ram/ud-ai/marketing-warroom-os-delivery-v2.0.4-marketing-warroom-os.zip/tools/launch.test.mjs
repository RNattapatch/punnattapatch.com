import assert from 'node:assert/strict';
import test from 'node:test';
import { browserCommand, launch, launchDetached } from './launch.mjs';
import { getWorkspaceIdentity } from './delivery-state.mjs';

function detachHarness({ rootDir = '/safe/workspace', answersAfter = 1, spawnResult = { pid: 4242, unref() {} } } = {}) {
  const calls = [];
  let probes = 0;
  return {
    calls,
    options: {
      rootDir,
      spawnProcess: (command, args, options) => { calls.push({ command, args, options }); return spawnResult; },
      portProbe: async () => {
        probes += 1;
        return probes > answersAfter
          ? { state: 'occupied', workspaceIdentity: getWorkspaceIdentity(rootDir) }
          : { state: 'available' };
      },
      sleep: async () => {},
      now: (() => { let clock = 0; return () => (clock += 100); })(),
      waitMs: 2000
    }
  };
}

test('browser command selection uses argument-safe platform commands', () => {
  const url = 'http://127.0.0.1:4173/content';
  assert.deepEqual(browserCommand('darwin', url), { command: 'open', args: [url] });
  assert.deepEqual(browserCommand('win32', url), { command: 'cmd', args: ['/c', 'start', '', url] });
  assert.deepEqual(browserCommand('linux', url), { command: 'xdg-open', args: [url] });
});

test('launcher reuses the same workspace instance and refuses a foreign occupied port', async () => {
  const rootDir = '/safe/workspace';
  const opened = [];
  const same = await launch({
    rootDir,
    portProbe: async () => ({ state: 'occupied', workspaceIdentity: getWorkspaceIdentity(rootDir) }),
    openBrowser: async (url) => opened.push(url)
  });
  assert.equal(same.reused, true);
  assert.deepEqual(opened, ['http://127.0.0.1:4173/content']);

  await assert.rejects(launch({
    rootDir,
    portProbe: async () => ({ state: 'occupied', workspaceIdentity: 'foreign' }),
    openBrowser: async () => {}
  }), /another process|occupied/i);
});

test('launcher binds loopback and close terminates the owned server', async () => {
  const calls = [];
  const fakeServer = {
    listen(port, host, callback) { calls.push(['listen', port, host]); callback(); },
    close(callback) { calls.push(['close']); callback(); }
  };
  const result = await launch({
    rootDir: '/safe/workspace',
    portProbe: async () => ({ state: 'available' }),
    runPreflight: async () => ({ ok: true, checks: [] }),
    serverFactory: () => fakeServer,
    openBrowser: async (url) => calls.push(['open', url])
  });
  await result.close();

  assert.deepEqual(calls, [
    ['listen', 4173, '127.0.0.1'],
    ['open', 'http://127.0.0.1:4173/content'],
    ['close']
  ]);
});

test('detached launch hands the server to a background process and returns once the port answers', async () => {
  const harness = detachHarness({ answersAfter: 1 });
  const result = await launchDetached({ ...harness.options, scriptPath: '/safe/workspace/tools/launch.mjs' });

  assert.equal(result.reused, false);
  assert.equal(result.url, 'http://127.0.0.1:4173/content');
  assert.equal(result.pid, 4242);
  assert.equal(harness.calls.length, 1);
  assert.deepEqual(harness.calls[0].args, ['/safe/workspace/tools/launch.mjs']);
  assert.equal(harness.calls[0].options.detached, true);
  assert.equal(harness.calls[0].options.stdio, 'ignore');
  assert.ok(!harness.calls[0].args.includes('--detach'), 'the background process must not detach again');
});

test('detached launch reuses a running workspace and refuses a foreign occupied port', async () => {
  const rootDir = '/safe/workspace';
  const spawned = [];
  const reused = await launchDetached({
    rootDir,
    spawnProcess: (...args) => { spawned.push(args); return { pid: 1, unref() {} }; },
    portProbe: async () => ({ state: 'occupied', workspaceIdentity: getWorkspaceIdentity(rootDir) })
  });
  assert.equal(reused.reused, true);
  assert.equal(spawned.length, 0);

  await assert.rejects(launchDetached({
    rootDir,
    spawnProcess: () => { throw new Error('must not spawn'); },
    portProbe: async () => ({ state: 'occupied', workspaceIdentity: 'foreign' })
  }), /another process|occupied/i);
});

test('detached launch reports a server that never answers instead of claiming success', async () => {
  const harness = detachHarness({ answersAfter: Number.MAX_SAFE_INTEGER });
  await assert.rejects(
    launchDetached({ ...harness.options, scriptPath: '/safe/workspace/tools/launch.mjs' }),
    /did not answer|doctor/i
  );
});
