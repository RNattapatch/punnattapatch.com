import assert from 'node:assert/strict';
import test from 'node:test';

import { makeTestWorkspace } from './delivery-test-helpers.mjs';
import { createStore } from '../app/store.mjs';
import { workerStatus } from './worker-status.mjs';

test('worker status separates queued writing work from queued scouting work', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  const store = createStore({ rootDir: workspace.rootDir });
  await store.create('wr_jobs', { id: 'JOB-WR-1', job_type: 'ai_improve', payload: {}, status: 'queued', result: {}, error: null, created_at: '2026-09-13T00:00:00.000Z', started_at: null, finished_at: null });
  await store.create('newsroom_jobs', { id: 'JOB-SCOUT-1', kind: 'web', target: 'TGT-DEMO', note: '', status: 'queued', created_at: '2026-09-13T00:00:00.000Z', updated_at: '2026-09-13T00:00:00.000Z', target_id: 'TGT-DEMO', lane: 'web', result: {}, attempts: 0 });

  const result = await workerStatus({ rootDir: workspace.rootDir });

  assert.deepEqual(result, {
    writing: { count: 1, ids: ['JOB-WR-1'] },
    scouting: { count: 1, ids: ['JOB-SCOUT-1'] },
    total: 2
  });
});
