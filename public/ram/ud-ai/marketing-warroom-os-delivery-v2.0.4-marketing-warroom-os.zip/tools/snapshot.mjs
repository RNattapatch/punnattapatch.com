import { createHash } from 'node:crypto';
import { lstat, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

export const MANAGED_ROOTS = Object.freeze(['company', 'data', 'output', 'wiki']);

function safeLabel(value) {
  return String(value).toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-|-$/g, '') || 'manual';
}

export function assertSnapshotName(name) {
  if (typeof name !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9-]*$/.test(name) || path.basename(name) !== name) {
    throw new Error('Invalid snapshot name');
  }
  return name;
}

async function filesBelow(rootDir, relativeDir) {
  const directory = path.join(rootDir, relativeDir);
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries.sort((left, right) => left.name.localeCompare(right.name, 'en'))) {
    const relativePath = path.join(relativeDir, entry.name);
    const info = await lstat(path.join(rootDir, relativePath));
    if (info.isSymbolicLink()) throw new Error(`Snapshot refuses symlink: ${relativePath}`);
    if (info.isDirectory()) files.push(...await filesBelow(rootDir, relativePath));
    else if (info.isFile()) files.push(relativePath);
  }
  return files;
}

function portable(relativePath) {
  return relativePath.split(path.sep).join('/');
}

export async function createSnapshot({
  rootDir = path.resolve(import.meta.dirname, '..'),
  label = 'manual',
  now = new Date(),
  immutable = false
} = {}) {
  const safe = safeLabel(label);
  const name = immutable ? safe : `${safe}-${now.toISOString().replaceAll(/[:.]/g, '-')}`;
  assertSnapshotName(name);
  const directory = path.join(rootDir, 'snapshots', name);
  await mkdir(path.join(rootDir, 'snapshots'), { recursive: true });
  try {
    await mkdir(directory, { recursive: false });
  } catch (error) {
    if (error.code === 'EEXIST') throw new Error(`${immutable ? 'Immutable snapshot' : 'Snapshot'} already exists: ${name}`);
    throw error;
  }

  const manifestFiles = [];
  for (const managedRoot of MANAGED_ROOTS) {
    const sourceRoot = path.join(rootDir, managedRoot);
    await mkdir(path.join(directory, managedRoot), { recursive: true });
    let relativeFiles = [];
    try { relativeFiles = await filesBelow(rootDir, managedRoot); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
    for (const relativePath of relativeFiles) {
      const bytes = await readFile(path.join(rootDir, relativePath));
      const destination = path.join(directory, relativePath);
      await mkdir(path.dirname(destination), { recursive: true });
      await writeFile(destination, bytes, { mode: 0o600 });
      manifestFiles.push({
        path: portable(relativePath),
        size: bytes.length,
        sha256: createHash('sha256').update(bytes).digest('hex')
      });
    }
  }
  manifestFiles.sort((left, right) => left.path.localeCompare(right.path, 'en'));
  const workspaceVersion = (await readFile(path.join(rootDir, 'VERSION'), 'utf8')).trim();
  const manifest = {
    label: safe,
    created_at: now.toISOString(),
    workspace_version: workspaceVersion,
    immutable: Boolean(immutable),
    files: manifestFiles
  };
  const manifestPath = path.join(directory, 'manifest.json');
  await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, { mode: 0o600 });
  return { name, directory, manifestPath };
}

export async function verifySnapshot({ rootDir = path.resolve(import.meta.dirname, '..'), name } = {}) {
  assertSnapshotName(name);
  const directory = path.join(rootDir, 'snapshots', name);
  const manifest = JSON.parse(await readFile(path.join(directory, 'manifest.json'), 'utf8'));
  if (!Array.isArray(manifest.files) || manifest.files.length === 0) throw new Error('Snapshot manifest has no files');
  const errors = [];
  const seen = new Set();
  for (const file of manifest.files) {
    const relativePath = String(file.path || '').split('/').join(path.sep);
    const first = String(file.path || '').split('/')[0];
    const resolved = path.resolve(directory, relativePath);
    if (!MANAGED_ROOTS.includes(first) || !resolved.startsWith(`${path.resolve(directory)}${path.sep}`) || seen.has(file.path)) {
      errors.push(`unsafe path: ${file.path}`);
      continue;
    }
    seen.add(file.path);
    try {
      const info = await lstat(resolved);
      if (!info.isFile() || info.isSymbolicLink()) throw new Error('not a regular file');
      const bytes = await readFile(resolved);
      const digest = createHash('sha256').update(bytes).digest('hex');
      if (bytes.length !== file.size || digest !== file.sha256) errors.push(`checksum mismatch: ${file.path}`);
    } catch (error) {
      errors.push(`missing or unreadable: ${file.path} (${error.message})`);
    }
  }
  const actualFiles = [];
  for (const managedRoot of MANAGED_ROOTS) actualFiles.push(...await filesBelow(directory, managedRoot));
  for (const relativePath of actualFiles.map(portable)) {
    if (!seen.has(relativePath)) errors.push(`unlisted file outside manifest: ${relativePath}`);
  }
  if (errors.length) throw new Error(`Snapshot checksum verification failed\n${errors.join('\n')}`);
  return { ok: true, name, directory, manifest };
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  try {
    const immutable = process.argv.includes('--immutable');
    const label = process.argv.find((argument) => !argument.startsWith('--') && argument !== process.argv[0] && argument !== process.argv[1]) || 'manual';
    const snapshot = await createSnapshot({ label, immutable });
    process.stdout.write(`SNAPSHOT_CREATED\n${snapshot.directory}\n`);
  } catch (error) {
    process.stderr.write(`SNAPSHOT_FAILED\n${error.message}\n`);
    process.exitCode = 1;
  }
}
