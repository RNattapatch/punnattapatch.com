import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { createRequestDispatcher } from '../app/server.mjs';
import { TABLES } from '../app/store.mjs';

async function fixture() {
  const rootDir = await mkdtemp(path.join(os.tmpdir(), 'warroom-origin-'));
  for (const directory of ['data', 'data/files', 'app/views', 'app/assets', 'company']) await mkdir(path.join(rootDir, directory), { recursive: true });
  for (const table of TABLES) await writeFile(path.join(rootDir, 'data', `${table}.json`), '{"version":1,"items":[]}\n');
  await writeFile(path.join(rootDir, 'app/brand.json'), '{"productName":"Warroom","productTagline":"Local"}');
  await writeFile(path.join(rootDir, 'company/config.json'), '{"company_name":"Example Co","kie_api_key":""}');
  await writeFile(path.join(rootDir, 'company/business.md'), '# Original\n');
  return { rootDir, dispatch: createRequestDispatcher({ rootDir }) };
}

const source = { id: 'SRC-SEC', url: 'https://example.com/feed.xml', topic: 'AI', tags: [], type: 'rss', active: true, added_at: '2026-09-12T00:00:00.000Z' };

test('external Host is rejected before reads or writes', async (t) => {
  const { rootDir, dispatch } = await fixture();
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  assert.equal((await dispatch({ method: 'GET', url: '/api/meta', headers: { host: 'attacker.example' } })).status, 403);
  assert.equal((await dispatch({ method: 'POST', url: '/api/ca_sources', headers: { host: 'attacker.example', 'content-type': 'application/json' }, body: JSON.stringify(source) })).status, 403);
});

test('state-changing browser requests require a matching local Origin while origin-less local tools continue to work', async (t) => {
  const { rootDir, dispatch } = await fixture();
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  const external = await dispatch({ method: 'POST', url: '/api/ca_sources', headers: { host: '127.0.0.1:4173', origin: 'https://attacker.example', 'content-type': 'application/json' }, body: JSON.stringify(source) });
  const mismatch = await dispatch({ method: 'POST', url: '/api/ca_sources', headers: { host: '127.0.0.1:4173', origin: 'http://localhost:4173', 'content-type': 'application/json' }, body: JSON.stringify(source) });
  const sameOrigin = await dispatch({ method: 'POST', url: '/api/ca_sources', headers: { host: '127.0.0.1:4173', origin: 'http://127.0.0.1:4173', 'content-type': 'application/json' }, body: JSON.stringify(source) });
  const localTool = await dispatch({ method: 'DELETE', url: '/api/ca_sources/SRC-SEC', headers: { host: '127.0.0.1:4173' } });

  assert.equal(external.status, 403);
  assert.equal(mismatch.status, 403);
  assert.equal(sameOrigin.status, 201);
  assert.equal(localTool.status, 204);
});

test('company writes enforce a narrow content-type allowlist and preserve bytes on rejection', async (t) => {
  const { rootDir, dispatch } = await fixture();
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  const target = path.join(rootDir, 'company/business.md');
  const before = await readFile(target, 'utf8');
  const bad = await dispatch({ method: 'PUT', url: '/api/company/business.md', headers: { host: '127.0.0.1:4173', origin: 'http://127.0.0.1:4173', 'content-type': 'text/html' }, body: '<script>alert(1)</script>' });
  const good = await dispatch({ method: 'PUT', url: '/api/company/business.md', headers: { host: '127.0.0.1:4173', origin: 'http://127.0.0.1:4173', 'content-type': 'text/markdown; charset=utf-8' }, body: '# Updated' });

  assert.equal(bad.status, 415);
  assert.equal(before, '# Original\n');
  assert.equal(good.status, 200);
  assert.equal(await readFile(target, 'utf8'), '# Updated\n');
});

test('writing config tightens its filesystem permission to owner-only', async (t) => {
  const { rootDir, dispatch } = await fixture();
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  const target = path.join(rootDir, 'company/config.json');
  const response = await dispatch({
    method: 'POST',
    url: '/api/company/config.json',
    headers: { host: '127.0.0.1:4173', origin: 'http://127.0.0.1:4173', 'content-type': 'application/json' },
    body: JSON.stringify({ company_name: 'Example Co', kie_api_key: 'local-only-key' })
  });

  assert.equal(response.status, 200);
  assert.equal((await stat(target)).mode & 0o777, 0o600);
});
