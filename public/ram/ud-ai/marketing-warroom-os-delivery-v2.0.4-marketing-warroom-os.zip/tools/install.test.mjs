import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import test from 'node:test';
import { clientize } from './clientize.mjs';
import { hashTree, makeTemplateWorkspace, makeTestWorkspace } from './delivery-test-helpers.mjs';
import { install } from './install.mjs';

const availablePort = async () => ({ state: 'available' });
const healthySource = async () => ({ ok: true, items: 1 });

test('install stops at COMPANY_CONTEXT_REQUIRED without changing Company files', async (t) => {
  const workspace = await makeTemplateWorkspace();
  t.after(workspace.cleanup);
  const companyBefore = await hashTree(path.join(workspace.rootDir, 'company'));

  const status = await install({ rootDir: workspace.rootDir, portProbe: availablePort });

  assert.equal(status.state, 'COMPANY_CONTEXT_REQUIRED');
  assert.equal(status.ok, false);
  assert.equal(await hashTree(path.join(workspace.rootDir, 'company')), companyBefore);
  assert.equal(JSON.parse(await readFile(path.join(workspace.rootDir, 'DELIVERY-STATUS.json'), 'utf8')).state, 'COMPANY_CONTEXT_REQUIRED');
});

test('successful install builds agent skills, runs Golden path, and creates immutable starter-v1 once', async (t) => {
  const workspace = await makeTestWorkspace();
  t.after(workspace.cleanup);
  await clientize({ rootDir: workspace.rootDir, contextPath: path.join(workspace.rootDir, 'examples/client-context.example.json'), now: new Date('2026-09-12T00:00:00.000Z') });

  const first = await install({ rootDir: workspace.rootDir, portProbe: availablePort, sourceProbe: healthySource, now: new Date('2026-09-12T07:00:00.000Z') });
  const manifestPath = path.join(workspace.rootDir, 'snapshots/starter-v1/manifest.json');
  const firstManifestHash = createHash('sha256').update(await readFile(manifestPath)).digest('hex');
  const second = await install({ rootDir: workspace.rootDir, portProbe: availablePort, sourceProbe: healthySource, now: new Date('2026-09-12T08:00:00.000Z') });
  const secondManifestHash = createHash('sha256').update(await readFile(manifestPath)).digest('hex');
  const statusText = await readFile(path.join(workspace.rootDir, 'DELIVERY-STATUS.json'), 'utf8');
  const deliveryStatus = JSON.parse(statusText);

  assert.equal(first.state, 'READY');
  assert.equal(first.ok, true);
  assert.equal(first.golden.passed, 26);
  assert.equal(second.state, 'READY');
  assert.equal(firstManifestHash, secondManifestHash);
  assert.equal(deliveryStatus.version, (await readFile(path.join(workspace.rootDir, 'VERSION'), 'utf8')).trim());
  assert.equal(deliveryStatus.snapshot, 'snapshots/starter-v1', 'delivery status must be portable and must not expose the workstation path');
  assert.equal(await hashTree(path.join(workspace.rootDir, '.claude/skills')), await hashTree(path.join(workspace.rootDir, '.agents/skills')));
  assert.match(statusText, /"snapshot"/);
  assert.doesNotMatch(statusText, /sk-[A-Za-z0-9_-]{8,}/);
});
