import assert from 'node:assert/strict';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import test from 'node:test';

const rootDir = path.resolve(import.meta.dirname, '..');
const read = (name) => readFile(path.join(rootDir, name), 'utf8');

// A learner double-clicks these. Every failure must reach the screen and keep the window open,
// otherwise the launcher just flashes and the workspace looks broken for no stated reason.
test('macOS launcher runs a login shell so a Homebrew, nvm or Volta Node is on PATH', async () => {
  const script = await read('Open Workspace.command');
  assert.match(script.split('\n')[0], /^#!\/bin\/zsh -l$/, 'a non-login shell loses /opt/homebrew/bin');
  assert.match(script, /\/opt\/homebrew\/bin\/node/);
  assert.match(script, /\.nvm\/versions\/node/);
  assert.match(script, /\$HOME\/\.volta\/bin\/node/);
});

test('macOS launcher explains a missing or outdated Node and waits before closing', async () => {
  const script = await read('Open Workspace.command');
  assert.match(script, /หา Node\.js ไม่เจอ/);
  assert.match(script, /nodejs\.org/);
  assert.match(script, /NODE_MAJOR.*-lt 20|-lt 20/s, 'Node 20 is the floor for this workspace');
  assert.equal(script.match(/^\s*read "\?/gm)?.length >= 3, true, 'every exit path must pause on a visible message');
  assert.ok(!/^exec node/m.test(script), 'exec replaces the shell, so no message or pause can follow');
});

test('macOS launcher documents the Gatekeeper first-open step and the open-window rule', async () => {
  const script = await read('Open Workspace.command');
  assert.match(script, /unidentified developer/i);
  assert.match(script, /คลิกขวา/);
  assert.match(script, /ห้ามปิดหน้าต่างนี้ระหว่างใช้งาน/);
});

test('macOS launcher stays executable so double-click works straight out of the archive', async () => {
  const info = await stat(path.join(rootDir, 'Open Workspace.command'));
  assert.equal(Boolean(info.mode & 0o111), true, `expected an executable bit, got ${(info.mode & 0o777).toString(8)}`);
});

test('Windows launcher checks for Node, reports failures and pauses instead of flashing closed', async () => {
  const script = await read('Open Workspace.bat');
  assert.match(script, /where node/);
  assert.match(script, /goto no_node/);
  assert.match(script, /chcp 65001/, 'Thai output needs UTF-8 in the console');
  assert.equal(script.match(/^pause\r?$/gm)?.length >= 3, true, 'success, failure and no-Node paths all need a pause');
  assert.match(script, /nodejs\.org/);
  assert.match(script, /\r\n/, 'cmd.exe seeks by byte offset, so goto needs CRLF line endings');
});
