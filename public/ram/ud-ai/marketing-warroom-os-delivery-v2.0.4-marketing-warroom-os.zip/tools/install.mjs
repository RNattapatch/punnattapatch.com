import { access, readFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { buildKit } from './build-kit.mjs';
import { writeJsonAtomic } from './delivery-state.mjs';
import { runDoctor } from './doctor.mjs';
import { evaluateGolden } from './golden-check.mjs';
import { createSnapshot, verifySnapshot } from './snapshot.mjs';

async function exists(filePath) {
  try { await access(filePath); return true; } catch { return false; }
}

async function writeStatus(rootDir, status) {
  await writeJsonAtomic(path.join(rootDir, 'DELIVERY-STATUS.json'), status);
  return status;
}

export async function install({
  rootDir = path.resolve(import.meta.dirname, '..'),
  now = new Date(),
  portProbe,
  sourceProbe,
  runDoctorFn = runDoctor,
  evaluateGoldenFn = evaluateGolden
} = {}) {
  await buildKit({ rootDir });
  const doctorOptions = { ...(portProbe ? { portProbe } : {}), ...(sourceProbe ? { sourceProbe } : {}) };
  const preflight = await runDoctorFn({ rootDir, mode: 'preflight', ...doctorOptions });
  if (!preflight.ok) {
    return writeStatus(rootDir, {
      ok: false,
      state: 'PREFLIGHT_FAILED',
      checked_at: now.toISOString(),
      checks: preflight.checks,
      next_action: 'แก้รายการ FAIL แล้วรัน /install อีกครั้ง'
    });
  }

  const company = await runDoctorFn({ rootDir, mode: 'company', requireStarter: false, ...doctorOptions });
  if (!company.ok) {
    return writeStatus(rootDir, {
      ok: false,
      state: 'COMPANY_CONTEXT_REQUIRED',
      checked_at: now.toISOString(),
      checks: company.checks.filter((item) => item.status === 'FAIL'),
      next_action: 'กรอก context.json แล้วรัน node tools/clientize.mjs <context.json> จากนั้นรัน /install อีกครั้ง'
    });
  }

  const goldenResult = await evaluateGoldenFn({ rootDir });
  const goldenItems = [...goldenResult.steps, ...goldenResult.ready];
  const golden = { passed: goldenItems.filter((item) => item.ok).length, total: goldenItems.length };
  if (golden.passed !== golden.total) {
    return writeStatus(rootDir, {
      ok: false,
      state: 'GOLDEN_FAILED',
      checked_at: now.toISOString(),
      golden,
      failed: goldenItems.filter((item) => !item.ok).map((item) => item.name),
      next_action: 'หยุดส่งมอบและตรวจ Golden path ที่ล้ม'
    });
  }

  const starterManifest = path.join(rootDir, 'snapshots/starter-v1/manifest.json');
  let snapshot;
  if (await exists(starterManifest)) {
    const verified = await verifySnapshot({ rootDir, name: 'starter-v1' });
    snapshot = { name: verified.name, directory: verified.directory, manifestPath: starterManifest, reused: true };
  } else {
    snapshot = { ...await createSnapshot({ rootDir, label: 'starter-v1', immutable: true, now }), reused: false };
  }

  const finalDoctor = await runDoctorFn({ rootDir, mode: 'company', requireStarter: true, ...doctorOptions });
  return writeStatus(rootDir, {
    ok: finalDoctor.ok,
    state: finalDoctor.ok ? 'READY' : 'COMPANY_DOCTOR_FAILED',
    checked_at: now.toISOString(),
    version: (await readFile(path.join(rootDir, 'VERSION'), 'utf8')).trim(),
    golden,
    snapshot: path.relative(rootDir, snapshot.directory).split(path.sep).join('/'),
    snapshot_reused: snapshot.reused,
    checks: finalDoctor.checks,
    next_action: finalDoctor.ok ? 'เปิดระบบด้วย node tools/launch.mjs --detach (ใน agent session ต้องใส่ --detach เสมอ)' : 'แก้รายการ Company Doctor ที่ล้ม แล้วรัน /install อีกครั้ง'
  });
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  try {
    const status = await install();
    process.stdout.write(`${status.state}\nGolden: ${status.golden ? `${status.golden.passed}/${status.golden.total}` : 'not run'}\n${status.snapshot ? `Snapshot: ${status.snapshot}\n` : ''}Next: ${status.next_action}\n`);
    process.exitCode = status.ok ? 0 : 1;
  } catch (error) {
    process.stderr.write(`INSTALL_FAILED\n${error.message}\n`);
    process.exitCode = 1;
  }
}
