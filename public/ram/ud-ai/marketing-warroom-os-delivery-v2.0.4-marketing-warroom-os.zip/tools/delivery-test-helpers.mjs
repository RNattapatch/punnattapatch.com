import { createHash } from 'node:crypto';
import { cp, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

async function listFiles(rootDir, relativeDir = '') {
  const directory = path.join(rootDir, relativeDir);
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name, 'en'))) {
    const relativePath = path.join(relativeDir, entry.name);
    if (entry.isDirectory()) files.push(...await listFiles(rootDir, relativePath));
    else if (entry.isFile()) files.push(relativePath);
  }
  return files;
}

export async function hashTree(rootDir) {
  const hash = createHash('sha256');
  for (const relativePath of await listFiles(rootDir)) {
    hash.update(relativePath.split(path.sep).join('/'));
    hash.update('\0');
    hash.update(await readFile(path.join(rootDir, relativePath)));
    hash.update('\0');
  }
  return hash.digest('hex');
}

export async function makeTestWorkspace(sourceRoot = path.resolve(import.meta.dirname, '..')) {
  const temporaryRoot = await mkdtemp(path.join(os.tmpdir(), 'warroom-delivery-v2-'));
  const rootDir = path.join(temporaryRoot, 'workspace');
  await cp(sourceRoot, rootDir, {
    recursive: true,
    filter(source) {
      const relativePath = path.relative(sourceRoot, source);
      const parts = relativePath.split(path.sep);
      return !parts.some((part) => part.startsWith('.doctor-'))
        && !relativePath.startsWith(`dist${path.sep}`) && relativePath !== 'dist'
        && !relativePath.startsWith(`snapshots${path.sep}`) && relativePath !== 'snapshots';
    }
  });
  return {
    rootDir,
    async cleanup() {
      await rm(temporaryRoot, { recursive: true, force: true });
    }
  };
}

export async function makeTemplateWorkspace(sourceRoot = path.resolve(import.meta.dirname, '..')) {
  const workspace = await makeTestWorkspace(sourceRoot);
  const templates = {
    'business.md': '# Business\n\nอธิบายธุรกิจ ลูกค้า และข้อได้เปรียบที่ตรวจสอบได้ของบริษัทคุณในไฟล์นี้\n',
    'offer.md': '# Offer\n\nระบุข้อเสนอ ผลลัพธ์ ขอบเขต และหลักฐานที่ใช้สื่อสารได้\n',
    'persona.md': '# Persona\n\nระบุกลุ่มลูกค้าหลัก ปัญหาที่ต้องแก้ และบริบทการตัดสินใจซื้อ\n',
    'voice.md': '# Voice\n\n- ชัด ตรง และมีหลักฐาน\n',
    'niche-criteria.md': '# Niche Criteria\n\nเลือกข่าวที่กระทบปัญหา โอกาส หรือการตัดสินใจของลูกค้าเป้าหมายโดยตรง\n',
    'RULES.md': '# Company Rules\n\n- ใช้ข้อมูลจริงเท่านั้น\n',
    'pre-work.md': '# Pre-work\n\nก่อนเริ่ม ให้กรอกไฟล์ Company ทั้งหมด แล้วรัน `node tools/doctor.mjs`\n'
  };
  await Promise.all(Object.entries(templates).map(([name, content]) => writeFile(path.join(workspace.rootDir, 'company', name), content)));
  await writeFile(path.join(workspace.rootDir, 'company/config.json'), `${JSON.stringify({
    company_name: 'บริษัทตัวอย่าง จำกัด',
    max_news_per_day: 3,
    kie_api_key: '',
    local_usage_log: false,
    owners: { owner: 'Owner', reviewer: 'Reviewer', operator: 'Operator' }
  }, null, 2)}\n`);
  for (const table of ['ca_sources', 'intel_targets']) await writeFile(path.join(workspace.rootDir, 'data', `${table}.json`), '{"version":1,"items":[]}\n');
  return workspace;
}
