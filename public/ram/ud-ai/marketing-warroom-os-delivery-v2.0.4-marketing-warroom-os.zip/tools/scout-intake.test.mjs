import assert from 'node:assert/strict';
import test from 'node:test';

import { buildScoutJob, classifyScoutInput, scoutJobPresentation } from '../app/assets/scout-intake.mjs';
import { validateRecord } from '../app/store.mjs';

test('classification routes supported single-source inputs without network access', () => {
  const cases = [
    ['https://youtu.be/dQw4w9WgXcQ', 'clip', 'web'],
    ['https://www.tiktok.com/@brand/video/7300000000000000001', 'clip', 'web'],
    ['https://www.youtube.com/@brand', 'page', 'page'],
    ['https://www.facebook.com/ads/library/?id=123', 'ads', 'ads'],
    ['https://www.facebook.com/ExampleBrand', 'ads', 'ads'],
    ['https://example.com/pricing?utm_source=class', 'web', 'web'],
    ['evidence/ad-shot.png', 'shot', 'web'],
    ['evidence/ad-video.mp4', 'clip', 'web'],
    ['Example Brand', 'ads', 'ads'],
    ['ข้อความหลักฐานที่ยาวพอสำหรับให้ agent แกะโครง copy โดยไม่ต้องเปิดเว็บ'.repeat(2), 'paste', 'web']
  ];
  for (const [raw, kind, lane] of cases) {
    const result = classifyScoutInput(raw);
    assert.equal(result.ok, true, raw);
    assert.deepEqual([result.kind, result.lane], [kind, lane], raw);
  }
  assert.equal(classifyScoutInput(cases[5][0]).normalized, 'https://example.com/pricing');
});

test('classification rejects unsafe, private, unsupported, and oversized input', () => {
  const rejected = [
    '', '   ', 'file:///etc/passwd', '/etc/passwd', 'C:\\Users\\owner\\secret.png',
    '../evidence/ad.png', 'evidence/../../secret.png', 'ftp://example.com/file',
    'http://localhost:8080', 'http://127.0.0.1', 'http://10.0.0.1',
    'http://169.254.169.254/latest/meta-data', 'http://172.16.0.1', 'http://192.168.1.2',
    'http://[::1]/', 'http://[fc00::1]/', 'http://[fe80::1]/',
    'x'.repeat(4_097)
  ];
  for (const raw of rejected) {
    const result = classifyScoutInput(raw);
    assert.equal(result.ok, false, raw.slice(0, 80));
    assert.ok(result.error, raw.slice(0, 80));
  }
});

test('job builder creates a deterministic schema-valid pending job', () => {
  const job = buildScoutJob({
    raw: 'https://example.com/page?utm_campaign=demo',
    note: 'ดูข้อเสนอ',
    targetId: 'TGT-1',
    now: '2026-09-13T08:00:00.000Z',
    id: 'NJ-1',
    batchId: 'BATCH-1'
  });
  assert.deepEqual(job, {
    id: 'NJ-1', kind: 'web', target: 'https://example.com/page', note: 'ดูข้อเสนอ', status: 'queued',
    scout_job_id: null, item_id: null, error: null,
    created_at: '2026-09-13T08:00:00.000Z', updated_at: '2026-09-13T08:00:00.000Z',
    target_id: 'TGT-1', batch_id: 'BATCH-1', lane: 'web',
    result: { capability_mode: 'pending', source_type: 'public-web', requested_media: ['page-html'] }, attempts: 0
  });
  assert.throws(() => buildScoutJob({ raw: 'https://example.com', note: 'x'.repeat(2_001) }), /2,000/);
  assert.throws(() => buildScoutJob({ raw: '../secret.png' }), /workspace|ปลอดภัย/);
});

test('presentation maps lifecycle states to operator actions', () => {
  assert.deepEqual(scoutJobPresentation({ status: 'submitted' }), { tone: 'neutral', title: 'ตรวจแหล่งแล้ว', detail: 'คำขอผ่านการตรวจรูปแบบและพร้อมเข้าคิว', action: null });
  assert.deepEqual(scoutJobPresentation({ status: 'queued' }), { tone: 'warning', title: 'รอ Agent', detail: 'Claude Code ใช้ /worker · Codex ใช้ $worker', action: 'worker' });
  assert.deepEqual(scoutJobPresentation({ status: 'running' }), { tone: 'working', title: 'กำลังสืบ', detail: 'Agent รับงานแล้วและกำลังเก็บหลักฐาน', action: null });
  assert.deepEqual(scoutJobPresentation({ status: 'done', result: { item_id: 'NR-1' } }), { tone: 'success', title: 'อยู่ในคลัง', detail: 'หลักฐานและรายงานพร้อมเปิดดู', action: 'NR-1' });
  assert.deepEqual(scoutJobPresentation({ status: 'preflight_failed', result: { reason: 'provider ไม่มีรูป', next_action: 'วาง screenshot ใน evidence/' } }), { tone: 'warning', title: 'ต้องส่งหลักฐานเพิ่ม', detail: 'provider ไม่มีรูป', action: 'วาง screenshot ใน evidence/' });
  assert.equal(scoutJobPresentation({ status: 'failed', error: 'อ่านหน้าไม่ได้' }).title, 'สืบไม่สำเร็จ');
});

test('stored Scout jobs enforce target, note, and structured result bounds', () => {
  const base = buildScoutJob({ raw: 'https://example.com', id: 'NJ-VALID', batchId: 'BATCH-1' });
  assert.equal(validateRecord('newsroom_jobs', base), base);
  assert.throws(() => validateRecord('newsroom_jobs', { ...base, target: 'x'.repeat(4_097) }), /target/);
  assert.throws(() => validateRecord('newsroom_jobs', { ...base, note: 'x'.repeat(2_001) }), /note/);
  assert.throws(() => validateRecord('newsroom_jobs', { ...base, result: [] }), /result/);
  assert.throws(() => validateRecord('newsroom_jobs', { ...base, result: { requested_media: ['ok', 42] } }), /requested_media/);
  assert.throws(() => validateRecord('newsroom_jobs', { ...base, result: { next_action: 'x'.repeat(2_001) } }), /next_action/);
});
