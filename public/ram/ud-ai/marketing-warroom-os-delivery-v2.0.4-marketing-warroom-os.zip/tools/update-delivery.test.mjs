import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { cp, mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import test from 'node:test';
import { hashTree, makeTestWorkspace } from './delivery-test-helpers.mjs';
import { updateWorkspace } from './update.mjs';

const SYSTEM_DIRECTORIES = [
  'app', 'brain', 'tools', '.claude', '.agents', '.interface-design',
  'skills-src', 'spec', 'examples'
];
const SYSTEM_FILES = [
  'VERSION', 'DELIVERY-STATUS.json', 'AGENTS.md', 'CLAUDE.md', 'เริ่มตรงนี้.md',
  'DELIVERY-GUIDE.md', 'CLASSROOM-RUNBOOK.md', 'LOCAL-FEATURE-MATRIX.md',
  'SECURITY-REVIEW.md', 'TESTED-WITH.md', 'CHANGELOG.md',
  'Open Workspace.command', 'Open Workspace.bat'
];
const MANAGED_ROOTS = ['company', 'data', 'output', 'wiki'];

function sha(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}

async function systemHash(rootDir) {
  const values = [];
  for (const folder of SYSTEM_DIRECTORIES) values.push(`${folder}:${await hashTree(path.join(rootDir, folder))}`);
  for (const file of SYSTEM_FILES) values.push(`${file}:${sha(await readFile(path.join(rootDir, file)))}`);
  return values.join('|');
}

async function managedHash(rootDir) {
  const values = [];
  for (const folder of MANAGED_ROOTS) values.push(`${folder}:${await hashTree(path.join(rootDir, folder))}`);
  return values.join('|');
}

async function makeUpgradePair(t) {
  const target = await makeTestWorkspace();
  const source = await makeTestWorkspace();
  t.after(target.cleanup);
  t.after(source.cleanup);
  await writeFile(path.join(target.rootDir, 'VERSION'), '2.0.3\n');
  await writeFile(path.join(target.rootDir, 'app/old-engine-marker.txt'), 'v2.0.3 engine\n');
  await writeFile(path.join(source.rootDir, 'app/new-engine-marker.txt'), 'v2.0.4 engine\n');
  await writeFile(path.join(source.rootDir, 'CHANGELOG.md'), '# V2.0.4 source marker\n');
  for (const folder of MANAGED_ROOTS) {
    await writeFile(path.join(target.rootDir, folder, `customer-${folder}.txt`), `keep ${folder} exactly\n`);
  }
  return { target, source };
}

test('V2.0.3 to V2.0.4 update replaces every system path and preserves all customer roots byte-for-byte', async (t) => {
  const { target, source } = await makeUpgradePair(t);
  const managedBefore = await managedHash(target.rootDir);
  const sourceSystem = await systemHash(source.rootDir);
  const gates = [];

  const result = await updateWorkspace({
    rootDir: target.rootDir,
    sourceDir: source.rootDir,
    gateRunner({ gate }) { gates.push(gate); }
  });

  assert.equal(result.ok, true);
  assert.equal(result.fromVersion, '2.0.3');
  assert.equal(result.toVersion, '2.0.4');
  assert.deepEqual(gates, ['Golden', 'Doctor']);
  assert.equal(await systemHash(target.rootDir), sourceSystem);
  assert.equal(await managedHash(target.rootDir), managedBefore);
  assert.match(result.snapshot, /snapshots[/\\]before-update-/);
  assert.match(await readFile(path.join(result.snapshot, 'manifest.json'), 'utf8'), /"workspace_version": "2\.0\.3"/);
});

test('a failed post-copy gate restores every system path and preserves all customer roots', async (t) => {
  const { target, source } = await makeUpgradePair(t);
  const systemBefore = await systemHash(target.rootDir);
  const managedBefore = await managedHash(target.rootDir);

  await assert.rejects(updateWorkspace({
    rootDir: target.rootDir,
    sourceDir: source.rootDir,
    gateRunner({ gate }) {
      if (gate === 'Doctor') throw new Error('injected Doctor failure');
    }
  }), /rolled back/i);

  assert.equal(await systemHash(target.rootDir), systemBefore);
  assert.equal(await managedHash(target.rootDir), managedBefore);
});

test('updater refuses a same-version source, downgrade source, or unsupported target', async (t) => {
  const { target, source } = await makeUpgradePair(t);
  await writeFile(path.join(source.rootDir, 'VERSION'), '2.0.3\n');
  await assert.rejects(updateWorkspace({ rootDir: target.rootDir, sourceDir: source.rootDir }), /source.*2\.0\.4/i);

  await writeFile(path.join(source.rootDir, 'VERSION'), '2.0.2\n');
  await assert.rejects(updateWorkspace({ rootDir: target.rootDir, sourceDir: source.rootDir }), /source.*2\.0\.4/i);

  await writeFile(path.join(source.rootDir, 'VERSION'), '2.0.4\n');
  await writeFile(path.join(target.rootDir, 'VERSION'), '2.0.2\n');
  await assert.rejects(updateWorkspace({ rootDir: target.rootDir, sourceDir: source.rootDir }), /target.*2\.0\.3/i);
});

test('update CLI executes when macOS resolves the temporary path through /private/var', async (t) => {
  const { target, source } = await makeUpgradePair(t);
  const payload = path.join(target.rootDir, 'marketing-warroom-os-update-v2.0.4/payload');
  await mkdir(path.dirname(payload), { recursive: true });
  await cp(source.rootDir, payload, { recursive: true });

  const result = spawnSync(process.execPath, [
    path.join(payload, 'tools/update.mjs'),
    '--target', target.rootDir,
    '--source', payload
  ], { cwd: target.rootDir, encoding: 'utf8' });

  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /UPDATE_FAILED/);
  assert.match(result.stderr, /rolled back/i);
});
