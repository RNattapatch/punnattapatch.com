import { cp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

async function buildCss(rootDir) {
  const brand = JSON.parse(await readFile(path.join(rootDir, 'app/brand.json'), 'utf8'));
  let css = await readFile(path.join(rootDir, 'app/assets/fallback.css'), 'utf8');
  for (const [name, value] of Object.entries(brand.colors)) {
    css = css.replaceAll(`{{${name}}}`, value);
  }
  if (/{{[^}]+}}/.test(css)) throw new Error('Unresolved CSS brand token');
  await writeFile(path.join(rootDir, 'app/assets/app.css'), css, 'utf8');
}

async function buildSkills(rootDir) {
  const source = path.join(rootDir, 'skills-src');
  for (const destination of [path.join(rootDir, '.claude/skills'), path.join(rootDir, '.agents/skills')]) {
    await rm(destination, { recursive: true, force: true });
    await mkdir(destination, { recursive: true });
    await cp(source, destination, { recursive: true });
  }
}

export async function buildKit({ rootDir = path.resolve(import.meta.dirname, '..'), cssOnly = false } = {}) {
  await buildCss(rootDir);
  if (!cssOnly) await buildSkills(rootDir);
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  await buildKit({ cssOnly: process.argv.includes('--css-only') });
  process.stdout.write(`✅ Built local CSS${process.argv.includes('--css-only') ? '' : ' and agent skills'}\n`);
}
