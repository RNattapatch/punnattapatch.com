import { createHash } from 'node:crypto';
import { realpathSync } from 'node:fs';
import { access, lstat, mkdtemp, readFile, readdir, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { assertInside, copyReplace, run } from './lib.mjs';
import { createSnapshot, MANAGED_ROOTS } from './snapshot.mjs';

export const UPDATE_FROM_VERSION = '2.0.3';
export const UPDATE_TO_VERSION = '2.0.4';
export const SYSTEM_DIRECTORIES = Object.freeze([
  'app', 'brain', 'tools', '.claude', '.agents', '.interface-design',
  'skills-src', 'spec', 'examples'
]);
export const SYSTEM_FILES = Object.freeze([
  'VERSION', 'DELIVERY-STATUS.json', 'AGENTS.md', 'CLAUDE.md', 'เริ่มตรงนี้.md',
  'DELIVERY-GUIDE.md', 'CLASSROOM-RUNBOOK.md', 'LOCAL-FEATURE-MATRIX.md',
  'SECURITY-REVIEW.md', 'TESTED-WITH.md', 'CHANGELOG.md',
  'Open Workspace.command', 'Open Workspace.bat'
]);
export const SYSTEM_PATHS = Object.freeze([...SYSTEM_DIRECTORIES, ...SYSTEM_FILES]);

async function pathExists(candidate) {
  try { await access(candidate); return true; } catch { return false; }
}

async function digestTree(rootDir) {
  const hash = createHash('sha256');
  async function visit(directory, relativeDir = '') {
    const entries = await readdir(directory, { withFileTypes: true });
    for (const entry of entries.sort((left, right) => left.name.localeCompare(right.name, 'en'))) {
      const relativePath = path.join(relativeDir, entry.name);
      const absolutePath = path.join(directory, entry.name);
      const info = await lstat(absolutePath);
      if (info.isSymbolicLink()) throw new Error(`Update refuses symlink in customer data: ${relativePath}`);
      if (info.isDirectory()) await visit(absolutePath, relativePath);
      else if (info.isFile()) {
        hash.update(relativePath.split(path.sep).join('/'));
        hash.update('\0');
        hash.update(await readFile(absolutePath));
        hash.update('\0');
      }
    }
  }
  await visit(rootDir);
  return hash.digest('hex');
}

async function managedState(rootDir) {
  const state = {};
  for (const managedRoot of MANAGED_ROOTS) {
    const root = path.join(rootDir, managedRoot);
    state[managedRoot] = await pathExists(root) ? await digestTree(root) : null;
  }
  return state;
}

function assertManagedState(before, after) {
  for (const managedRoot of MANAGED_ROOTS) {
    if (before[managedRoot] !== after[managedRoot]) {
      throw new Error(`Customer-owned root changed during update: ${managedRoot}`);
    }
  }
}

function defaultGateRunner({ gate, rootDir }) {
  const args = gate === 'Golden'
    ? ['tools/golden-check.mjs']
    : ['tools/doctor.mjs', '--company'];
  const result = run(process.execPath, args, { cwd: rootDir, allowFailure: true });
  if (result.status !== 0 || result.error) {
    throw new Error(`${gate} failed: ${(result.stderr || result.stdout || result.error?.message || '').trim()}`);
  }
}

async function restoreSystem({ rootDir, backup, existing }) {
  for (const relativePath of SYSTEM_PATHS) {
    const target = path.join(rootDir, relativePath);
    await rm(target, { recursive: true, force: true });
    if (existing.has(relativePath)) await copyReplace(path.join(backup, relativePath), target);
  }
}

async function restoreManaged({ rootDir, snapshotDirectory }) {
  for (const managedRoot of MANAGED_ROOTS) {
    await copyReplace(path.join(snapshotDirectory, managedRoot), path.join(rootDir, managedRoot));
  }
}

export async function updateWorkspace({
  rootDir = path.resolve(import.meta.dirname, '..'),
  sourceDir,
  gateRunner = defaultGateRunner
} = {}) {
  if (!sourceDir) throw new Error('ระบุโฟลเดอร์ payload สำหรับอัปเดต');
  const target = path.resolve(rootDir);
  const source = path.resolve(sourceDir);
  if (source === target) throw new Error('Update source must be a different folder');

  const fromVersion = (await readFile(path.join(target, 'VERSION'), 'utf8')).trim();
  const toVersion = (await readFile(path.join(source, 'VERSION'), 'utf8')).trim();
  if (fromVersion !== UPDATE_FROM_VERSION) {
    throw new Error(`Update refused: target must be V${UPDATE_FROM_VERSION}; found V${fromVersion || 'unknown'}`);
  }
  if (toVersion !== UPDATE_TO_VERSION) {
    throw new Error(`Update refused: source must be V${UPDATE_TO_VERSION}; found V${toVersion || 'unknown'}`);
  }
  for (const relativePath of SYSTEM_PATHS) await access(path.join(source, relativePath));

  const managedBefore = await managedState(target);
  const snapshot = await createSnapshot({ rootDir: target, label: 'before-update' });
  const backup = await mkdtemp(path.join(os.tmpdir(), 'workspace-system-backup-'));
  const existing = new Set();
  let copied = false;
  try {
    for (const relativePath of SYSTEM_PATHS) {
      const current = path.join(target, relativePath);
      if (await pathExists(current)) {
        existing.add(relativePath);
        await copyReplace(current, path.join(backup, relativePath));
      }
    }
    for (const relativePath of SYSTEM_PATHS) {
      await copyReplace(path.join(source, relativePath), path.join(target, relativePath));
    }
    copied = true;
    await gateRunner({ gate: 'Golden', rootDir: target });
    await gateRunner({ gate: 'Doctor', rootDir: target });
    assertManagedState(managedBefore, await managedState(target));
    return {
      ok: true,
      fromVersion,
      toVersion,
      snapshot: snapshot.directory,
      updated: [...SYSTEM_PATHS]
    };
  } catch (error) {
    if (copied) await restoreSystem({ rootDir: target, backup, existing });
    await restoreManaged({ rootDir: target, snapshotDirectory: snapshot.directory });
    throw new Error(`Update failed and rolled back to V${fromVersion}. ${error.message}`, { cause: error });
  } finally {
    await rm(backup, { recursive: true, force: true });
  }
}

function argumentAfter(argv, flag) {
  const index = argv.indexOf(flag);
  if (index < 0) return null;
  const value = argv[index + 1];
  if (!value || value.startsWith('--')) throw new Error(`${flag} needs a path`);
  return value;
}

export function parseUpdateCli(argv = process.argv, baseDir = process.cwd()) {
  const targetArgument = argumentAfter(argv, '--target');
  const sourceArgument = argumentAfter(argv, '--source');
  const positionals = argv.slice(2).filter((value, index, values) => {
    if (value.startsWith('--')) return false;
    return index === 0 || !values[index - 1].startsWith('--');
  });
  const target = path.resolve(baseDir, targetArgument || '.');
  const sourceValue = sourceArgument || positionals[0];
  if (!sourceValue) throw new Error('Usage: node tools/update.mjs --target <V2.0.3-workspace> --source <V2.0.4-payload>');
  const source = assertInside(target, path.resolve(baseDir, sourceValue), 'Update source');
  return { rootDir: target, sourceDir: source };
}

const isMain = (() => {
  if (!process.argv[1]) return false;
  try { return realpathSync(path.resolve(process.argv[1])) === realpathSync(fileURLToPath(import.meta.url)); }
  catch { return false; }
})();
if (isMain) {
  try {
    const result = await updateWorkspace(parseUpdateCli());
    process.stdout.write([
      `✅ อัปเดต V${result.fromVersion} → V${result.toVersion} สำเร็จ`,
      '✅ Golden และ Company Doctor ผ่าน',
      '✅ company/, data/, wiki/, output/ คงเดิมทุก byte',
      `Snapshot: ${result.snapshot}`,
      ''
    ].join('\n'));
  } catch (error) {
    process.stderr.write(`UPDATE_FAILED\n${error.message}\n`);
    process.exitCode = 1;
  }
}
