import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { mkdtemp, mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { Readable } from 'node:stream';
import test from 'node:test';

import * as newsDaily from './news-daily.mjs';
import { TABLES } from '../app/store.mjs';

async function workspace(sources, maxNews = 3) {
  const rootDir = await mkdtemp(path.join(os.tmpdir(), 'warroom-news-'));
  await mkdir(path.join(rootDir, 'data'), { recursive: true });
  await mkdir(path.join(rootDir, 'company'), { recursive: true });
  await mkdir(path.join(rootDir, 'fixtures'), { recursive: true });
  for (const table of TABLES) await writeFile(path.join(rootDir, 'data', `${table}.json`), '{"version":1,"items":[]}\n');
  await writeFile(path.join(rootDir, 'company/config.json'), JSON.stringify({ max_news_per_day: maxNews }));
  await writeFile(path.join(rootDir, 'data/ca_sources.json'), JSON.stringify({ version: 1, items: sources }));
  return rootDir;
}

const source = (id, url) => ({ id, url, topic: `topic-${id}`, tags: [id.toLowerCase()], type: 'rss', active: true, added_at: '2026-09-05T00:00:00.000Z' });
const item = ({ title, link, body, description = 'คำย่อที่ต้องไม่ชนะ content encoded' }) => `<item><title>${title}</title><link>${link}</link><pubDate>Sat, 05 Sep 2026 00:00:00 GMT</pubDate><description>${description}</description><content:encoded><![CDATA[<p>${body}</p>]]></content:encoded></item>`;
const rss = (...items) => `<rss><channel>${items.join('')}</channel></rss>`;

test('explicit fixture mode ingests every active source, deduplicates content, writes briefs, and never authors copy', async (t) => {
  const rootDir = await workspace([source('SRC-A', 'feed-a.xml'), source('SRC-B', 'feed-b.xml')]);
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  const fixturesDir = path.join(rootDir, 'fixtures');
  const briefOutDir = path.join(rootDir, 'briefs');
  await writeFile(path.join(fixturesDir, 'feed-a.xml'), rss(
    item({ title: 'ข่าวหนึ่ง', link: 'https://example.invalid/one', body: 'เนื้อฉบับเต็มข่าวหนึ่ง' }),
    item({ title: 'ข่าวสอง', link: 'https://example.invalid/two', body: 'เนื้อฉบับเต็มข่าวสอง' })
  ));
  await writeFile(path.join(fixturesDir, 'feed-b.xml'), rss(
    item({ title: 'ข่าวหนึ่ง', link: 'https://example.invalid/duplicate', body: 'เนื้อฉบับเต็มข่าวหนึ่ง' }),
    item({ title: 'ข่าวสาม', link: 'https://example.invalid/three', body: 'เนื้อฉบับเต็มข่าวสาม' })
  ));

  const now = new Date('2026-09-05T10:00:00.000Z');
  const first = await newsDaily.runNewsDaily({ rootDir, fixturesDir, briefOutDir, now });
  const second = await newsDaily.runNewsDaily({ rootDir, fixturesDir, briefOutDir, now });

  assert.equal(first.sources, 2);
  assert.equal(first.fetched, 4);
  assert.equal(first.inserted, 3);
  assert.equal(first.briefs, 3);
  assert.equal(first.errors.length, 0);
  assert.equal(first.brief_files.length, 3);
  assert.ok(first.brief_files.every((name) => name.startsWith('briefs/NEWS-') && name.endsWith('.brief.json')));
  assert.deepEqual(second, { sources: 2, fetched: 4, inserted: 0, briefs: 0, brief_files: [], errors: [] });
  const news = JSON.parse(await readFile(path.join(rootDir, 'data/ca_news_items.json'), 'utf8')).items;
  assert.equal(news.length, 3);
  assert.deepEqual(new Set(news.map((entry) => entry.source_id)), new Set(['SRC-A', 'SRC-B']));
  assert.equal(JSON.parse(await readFile(path.join(rootDir, 'data/ca_candidates.json'), 'utf8')).items.length, 0);
  assert.equal(JSON.parse(await readFile(path.join(rootDir, 'data/notifications.json'), 'utf8')).items.length, 0);
  const briefs = await Promise.all((await readdir(briefOutDir)).filter((name) => name.endsWith('.json')).map(async (name) => JSON.parse(await readFile(path.join(briefOutDir, name), 'utf8'))));
  assert.equal(briefs.length, 3);
  assert.ok(briefs.some((brief) => brief.body === 'เนื้อฉบับเต็มข่าวหนึ่ง'));
  assert.ok(briefs.every((brief) => brief.news_item_id && brief.body_source === 'rss' && brief.source_host === 'example.invalid'));
});

test('network mode attempts every active source and reports one source failure without aborting the run', async (t) => {
  const sources = [source('SRC-A', 'https://feeds.invalid/a'), source('SRC-B', 'https://feeds.invalid/b'), source('SRC-C', 'https://feeds.invalid/c')];
  const rootDir = await workspace(sources, 1);
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  const requested = [];
  const fetchText = async (url) => {
    requested.push(url);
    if (url.endsWith('/b')) throw new Error('socket timeout');
    const suffix = url.endsWith('/a') ? 'a' : 'c';
    return rss(item({ title: `ข่าว ${suffix}`, link: `https://example.invalid/${suffix}`, body: `รายละเอียดข่าว ${suffix}` }));
  };

  const result = await newsDaily.runNewsDaily({ rootDir, briefOutDir: path.join(rootDir, 'briefs'), now: new Date('2026-09-05T10:00:00.000Z'), fetchText });

  assert.deepEqual(requested, sources.map((entry) => entry.url));
  assert.equal(result.sources, 3);
  assert.equal(result.fetched, 2);
  assert.equal(result.inserted, 2);
  assert.equal(result.briefs, 2);
  assert.deepEqual(result.errors, [{ source_id: 'SRC-B', url: 'https://feeds.invalid/b', error: 'socket timeout' }]);
});

function fakeHttps(responses, observations) {
  return (url, options, onResponse) => {
    const request = new EventEmitter();
    request.setTimeout = (milliseconds, callback) => { observations.timeouts.push(milliseconds); request.timeoutCallback = callback; return request; };
    request.destroy = (error) => queueMicrotask(() => request.emit('error', error));
    observations.requests.push({ url: String(url), options });
    queueMicrotask(() => {
      const reply = responses[String(url)];
      if (reply instanceof Error) return request.emit('error', reply);
      const response = Readable.from([reply.body || '']);
      response.statusCode = reply.status;
      response.headers = reply.headers || {};
      onResponse(response);
    });
    return request;
  };
}

test('HTTPS transport sends a Mozilla user agent, uses a 15 second timeout, and follows at most three redirects', async () => {
  assert.equal(typeof newsDaily.fetchHttpsText, 'function');
  const lookup = async () => [{ address: '93.184.216.34', family: 4 }];
  const observations = { requests: [], timeouts: [] };
  const responses = {
    'https://feeds.invalid/start': { status: 302, headers: { location: '/one' } },
    'https://feeds.invalid/one': { status: 301, headers: { location: '/two' } },
    'https://feeds.invalid/two': { status: 307, headers: { location: '/three' } },
    'https://feeds.invalid/three': { status: 200, body: '<rss>ok</rss>' }
  };
  const body = await newsDaily.fetchHttpsText('https://feeds.invalid/start', { request: fakeHttps(responses, observations), lookup });
  assert.equal(body, '<rss>ok</rss>');
  assert.deepEqual(observations.timeouts, [15_000, 15_000, 15_000, 15_000]);
  assert.ok(observations.requests.every(({ options }) => options.headers['User-Agent'].startsWith('Mozilla/5.0')));

  const tooMany = {
    'https://feeds.invalid/start': { status: 302, headers: { location: '/one' } },
    'https://feeds.invalid/one': { status: 302, headers: { location: '/two' } },
    'https://feeds.invalid/two': { status: 302, headers: { location: '/three' } },
    'https://feeds.invalid/three': { status: 302, headers: { location: '/four' } }
  };
  await assert.rejects(newsDaily.fetchHttpsText('https://feeds.invalid/start', { request: fakeHttps(tooMany, { requests: [], timeouts: [] }), lookup }), /redirect limit/i);
});
