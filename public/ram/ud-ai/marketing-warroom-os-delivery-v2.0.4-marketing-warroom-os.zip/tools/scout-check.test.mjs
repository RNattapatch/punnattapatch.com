import assert from 'node:assert/strict';
import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

import { guessKind, historyFor, historyMessage, normUrl, targetKey, videoIdOf } from '../app/lib/target-key.mjs';
import { TABLES } from '../app/store.mjs';
import { checkTarget } from './scout-check.mjs';

test('links that point at the same thing collapse to one key', () => {
  assert.equal(targetKey('clip', 'https://www.tiktok.com/@brand/video/7300000000000000001?_t=abc&_r=1'), 'clip:7300000000000000001');
  assert.equal(targetKey('clip', 'https://tiktok.com/@brand/video/7300000000000000001'), 'clip:7300000000000000001');
  assert.equal(targetKey('clip', 'https://youtu.be/dQw4w9WgXcQ?si=x'), targetKey('clip', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'));
  assert.equal(targetKey('page', '@Brand'), targetKey('page', 'https://www.tiktok.com/@brand'));
  assert.equal(targetKey('page', 'https://www.instagram.com/brand/'), 'page:instagram:brand');
  assert.equal(targetKey('web', 'https://www.example.com/lp/?utm_source=fb&fbclid=1'), 'web:example.com/lp');
  assert.equal(targetKey('web', 'example.com/lp'), 'web:example.com/lp');
  assert.equal(targetKey('ads', 'Example Brand'), 'ads:example brand');
  assert.equal(targetKey('shot', '/tmp/a.png'), null, 'ภาพที่โยนมาเทียบไม่ได้');
  assert.equal(targetKey('paste', 'ข้อความยาว'.repeat(10)), null);
  assert.equal(videoIdOf('https://www.youtube.com/shorts/abcdefghijk'), 'abcdefghijk');
  assert.equal(normUrl('HTTPS://WWW.Example.com/A/?b=1&utm_term=x'), 'example.com/A?b=1');
});

test('auto kind follows the same guess as the queue form', () => {
  assert.equal(guessKind('https://www.tiktok.com/@a/video/7300000000000000001'), 'clip');
  assert.equal(guessKind('@brand'), 'page');
  assert.equal(guessKind('https://www.youtube.com/@brand'), 'page');
  assert.equal(guessKind('https://www.facebook.com/somepage'), 'ads');
  assert.equal(guessKind('https://example.com/pricing'), 'web');
  assert.equal(guessKind('Example Brand'), 'ads');
});

test('a clip that was already scouted is blocked unless the note forces it; other lanes continue with a delta note', () => {
  const items = [{ id: 'NR-1', kind: 'clip', source_url: 'https://www.tiktok.com/@a/video/7300000000000000001', title: 'คลิปเดิม', scraped_at: '2026-09-08T00:00:00.000Z', report_path: 'wiki/intel/scout/a.md' },
    { id: 'NR-2', kind: 'page', source_url: 'https://www.tiktok.com/@a', title: 'เพจ a', created_at: '2026-09-01T00:00:00.000Z' }];
  const jobs = [{ id: 'NJ-9', kind: 'web', target: 'https://example.com/lp?utm_source=x', status: 'done', item_id: null, updated_at: '2026-09-07T00:00:00.000Z' },
    { id: 'NJ-8', kind: 'web', target: 'https://example.com/lp', status: 'failed', updated_at: '2026-09-09T00:00:00.000Z' }];
  const clip = historyFor({ kind: 'auto', target: 'https://tiktok.com/@a/video/7300000000000000001?_t=1', items, jobs });
  assert.equal(clip.hits.length, 1);
  const blocked = historyMessage({ kind: 'auto', target: 'https://tiktok.com/@a/video/7300000000000000001', hits: clip.hits });
  assert.equal(blocked.blocked, true);
  assert.match(blocked.text, /♻️.*2026-09-08.*--force/s);
  assert.equal(historyMessage({ kind: 'clip', target: 'x', hits: clip.hits, note: 'intel:TGT-1 สืบตอนนี้' }).blocked, false, 'งานจากแฟ้ม (intel:) ไม่ถูกบล็อก');
  assert.equal(historyMessage({ kind: 'clip', target: 'x', hits: clip.hits, force: true }).blocked, false);
  const page = historyFor({ kind: 'page', target: '@a', items, jobs });
  assert.equal(page.hits[0].id, 'NR-2');
  assert.equal(historyMessage({ kind: 'page', target: '@a', hits: page.hits }).blocked, false);
  const web = historyFor({ kind: 'web', target: 'example.com/lp/', items, jobs });
  assert.deepEqual(web.hits.map((hit) => hit.id), ['NJ-9'], 'งานที่ล้มไม่นับว่าเคยสืบ');
  assert.deepEqual(historyFor({ kind: 'auto', target: '', items, jobs }), { key: null, hits: [] });
});

test('scout-check reads the workspace tables and reports history without touching the queue', async (t) => {
  const rootDir = await mkdtemp(path.join(os.tmpdir(), 'warroom-scout-check-'));
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  await mkdir(path.join(rootDir, 'data'), { recursive: true });
  for (const table of TABLES) await writeFile(path.join(rootDir, 'data', `${table}.json`), '{"version":1,"items":[]}\n');
  const item = { id: 'NR-1', job_id: 'NJ-1', kind: 'clip', platform: 'tiktok', source_url: 'https://www.tiktok.com/@a/video/7300000000000000001', title: 'คลิปเดิม', channel: 'a', summary: 'สรุป', verdict: 'watch', score: 70, views: 10, duration_s: 30, cover_path: null, media: [], report_md: '# รายงาน', report_path: 'wiki/intel/scout/a.md', tags: [], scraped_at: '2026-09-08T00:00:00.000Z', created_at: '2026-09-08T00:00:00.000Z', target_id: 'TGT-1' };
  await writeFile(path.join(rootDir, 'data/newsroom_items.json'), `${JSON.stringify({ version: 1, items: [item] })}\n`);
  const again = await checkTarget({ rootDir, kind: 'auto', target: 'https://tiktok.com/@a/video/7300000000000000001' });
  assert.equal(again.blocked, true);
  assert.equal(again.hits[0].report, 'wiki/intel/scout/a.md');
  const fresh = await checkTarget({ rootDir, kind: 'web', target: 'https://example.com' });
  assert.deepEqual(fresh, { key: 'web:example.com/', hits: [], blocked: false, text: '' });
});
