import assert from 'node:assert/strict';
import test from 'node:test';
import { acceptsDrag, DRAG_MIME, dropDecision, frontmatter, ideaCard, ideaRecord, JOB_LABEL, jobSubject, nextContentId, queueHealth, SCRIPT_TEMPLATE, staleVariants, variantCard, variantRecord } from '../app/assets/content.mjs';

test('board cards expose native keyboard controls for opening details', () => {
  const idea = ideaCard({ content_id: 'CNT-1', acid_test: 'pending', title: 'หัวข้อ', canonical_angle: 'มุม' });
  const variant = variantCard({ variant_id: 'CNT-1-RL', format: 'reel', working_title: 'หัวข้อ', status_changed_at: new Date().toISOString(), target_platforms: ['facebook'] });

  assert.match(idea, /<button[^>]+data-action="open-card"[^>]+aria-label="เปิดรายละเอียด หัวข้อ"/);
  assert.match(variant, /<button[^>]+data-action="open-card"[^>]+aria-label="เปิดรายละเอียด หัวข้อ"/);
});

test('variant markdown keeps every content-truth field and the approved studio structure', () => {
  const idea={content_id:'CNT-2026-09-05-001',topic_cluster:'AI',funnel_stage:'top',pillar_bucket:'intersection',angle_type:'how_to'};
  const variant={variant_id:'CNT-2026-09-05-001-RL',format:'reel',target_platforms:['tiktok','instagram'],variant_status:'ready_to_record',cta_keyword:'SYSTEM'};
  const output=frontmatter(idea,variant,'# Hook\nBody');
  for(const field of ['content_id','variant_id','format','target_platforms','status','topic_cluster','funnel_stage','pillar_bucket','angle_type','cta_keyword','source_refs','published_urls','analytics_status','draft']) assert.match(output,new RegExp(`${field}:`));
  for(const heading of ['# Hook (0-2 วิ — front-load payload)','# Setup (2-10 วิ','# Body','↻ Rehook:','# Payoff','# CTA','# 🔤 Hook Text','# 🔢 Chapter Counter','# 📝 Caption','# 💬 First Comment']) assert.ok(SCRIPT_TEMPLATE.includes(heading));
});

test('stale banner shows only the oldest production-blocked variant', () => {
  const now=new Date('2026-09-10T00:00:00.000Z').getTime();
  const variants=[
    {variant_id:'READY',variant_status:'ready_to_record',status_changed_at:'2026-09-01T00:00:00.000Z'},
    {variant_id:'POSTED',variant_status:'posted',status_changed_at:'2026-09-01T00:00:00.000Z'},
    {variant_id:'RECENT',variant_status:'editing',status_changed_at:'2026-09-09T00:00:00.000Z'},
    {variant_id:'OLD',variant_status:'recorded',status_changed_at:'2026-09-04T00:00:00.000Z'},
    {variant_id:'OLDER',variant_status:'scheduled',status_changed_at:'2026-09-03T00:00:00.000Z'}
  ];
  assert.deepEqual(staleVariants(variants,now).map((item)=>item.variant_id),['OLDER']);
});

test('board only accepts drags that started from a card in it', () => {
  // ลากข้อความ/ไฟล์จาก Finder ทับช่อง เดิมช่องรับหมดแล้วยิง PATCH ด้วย id มั่ว → พังเงียบ
  assert.equal(acceptsDrag(['text/plain'], 'recorded'), false);
  assert.equal(acceptsDrag(['Files'], 'recorded'), false);
  assert.equal(acceptsDrag([DRAG_MIME, 'text/plain'], 'recorded'), true);
  assert.equal(acceptsDrag([DRAG_MIME], ''), false, 'ช่อง Ideas ไม่มี primary = ไม่รับ drop');
});

test('drop moves the dragged card only, and only when the status really changes', () => {
  const variants = [
    { variant_id: 'CNT-2026-09-08-001-RL', variant_status: 'ready_to_record' },
    { variant_id: 'CNT-2026-09-08-001-AR', variant_status: 'recorded' }
  ];
  const drag = (over) => ({ types: [DRAG_MIME, 'text/plain'], ...over });
  assert.deepEqual(
    dropDecision(drag({ id: 'CNT-2026-09-08-001-RL', primary: 'recorded' }), variants),
    { id: 'CNT-2026-09-08-001-RL', status: 'recorded' }
  );
  assert.equal(dropDecision(drag({ id: 'CNT-2026-09-08-001-AR', primary: 'recorded' }), variants), null, 'อยู่สถานะนั้นแล้ว = ไม่ต้องยิง');
  assert.equal(dropDecision(drag({ id: 'ข้อความที่ลากมา', primary: 'recorded' }), variants), null, 'id ที่ไม่รู้จัก = ไม่ยิง');
  assert.equal(dropDecision({ types: ['text/plain'], id: 'CNT-2026-09-08-001-RL', primary: 'recorded' }, variants), null, 'ลากที่ไม่ได้เริ่มจากการ์ด = ไม่ยิง');
});

test('queue banner tells the operator what to do next, not just that work is pending', () => {
  const now = new Date('2026-09-08T12:00:00.000Z').getTime();
  const at = (minutesAgo) => new Date(now - minutesAgo * 60000).toISOString();

  const idle = queueHealth([{ id: 'J0', job_type: 'ai_improve', status: 'done', created_at: at(90), started_at: at(89), finished_at: at(88) }], now);
  assert.equal(idle.pending, 0);
  assert.match(idle.text, /คิวว่าง/);

  const waiting = queueHealth([{ id: 'J1', job_type: 'rewrite_reel', status: 'queued', created_at: at(2) }], now);
  assert.deepEqual([waiting.tone, waiting.pending], ['ok', 1]);
  assert.match(waiting.text, /\/jobs/, 'งานรอคิวต้องบอกให้ไปรัน /jobs');

  const forgotten = queueHealth([{ id: 'J2', job_type: 'rewrite_reel', status: 'queued', created_at: at(45) }], now);
  assert.equal(forgotten.tone, 'error', 'รอเกินครึ่งชั่วโมง = ลืมรัน /jobs');

  const stalled = queueHealth([{ id: 'J3', job_type: 'ai_improve', status: 'running', created_at: at(40), started_at: at(35) }], now);
  assert.deepEqual([stalled.tone, stalled.stalled], ['error', 1]);
  assert.match(stalled.text, /ลองใหม่/);

  const running = queueHealth([{ id: 'J4', job_type: 'ai_improve', status: 'running', created_at: at(3), started_at: at(2) }], now);
  assert.deepEqual([running.tone, running.running], ['ok', 1]);
  assert.match(running.text, /2:00 นาที/);
});

test('queue rows name the card an operator recognises instead of a raw id', () => {
  const context = {
    ideas: [{ content_id: 'CNT-2026-09-08-001', title: 'ระบบตอบแชทของทีมขาย' }],
    variants: [{ variant_id: 'CNT-2026-09-08-001-RL', content_id: 'CNT-2026-09-08-001', working_title: 'ระบบตอบแชทของทีมขาย' }],
    items: [{ id: 'NR-77', title: 'คลิปคู่แข่งเรื่องราคา' }]
  };
  const improve = jobSubject({ job_type: 'ai_improve', payload: { variant_id: 'CNT-2026-09-08-001-RL' } }, context);
  assert.deepEqual([improve.text, improve.variantId], ['ระบบตอบแชทของทีมขาย', 'CNT-2026-09-08-001-RL']);

  const rewrite = jobSubject({ job_type: 'rewrite_reel', payload: { item_id: 'NR-77', theme: 'บอกราคาในคอนเทนต์ ผิดไหม' } }, context);
  assert.deepEqual([rewrite.text, rewrite.sub], ['บอกราคาในคอนเทนต์ ผิดไหม', 'จากการ์ด: คลิปคู่แข่งเรื่องราคา']);

  const unknown = jobSubject({ job_type: 'rewrite_reel', payload: { item_id: 'NR-404', theme: 'ธงที่ยังไม่มีการ์ด' } }, context);
  assert.match(unknown.sub, /^การ์ด NR-404/, 'ไม่รู้จักการ์ด ก็ยังต้องบอก id ให้ตามต่อได้');

  assert.equal(JOB_LABEL.rewrite_reel.includes('Intel Warroom'), true);
});

test('content ids keep counting up within the same day and reset on a new one', () => {
  const ideas = [{ content_id: 'CNT-2026-09-08-001' }, { content_id: 'CNT-2026-09-08-004' }, { content_id: 'CNT-2026-09-07-009' }];
  assert.equal(nextContentId(ideas, '2026-09-08'), 'CNT-2026-09-08-005');
  assert.equal(nextContentId(ideas, '2026-09-09'), 'CNT-2026-09-09-001');
  assert.equal(nextContentId([], '2026-09-09'), 'CNT-2026-09-09-001');
});

test('a script handed over from Intel Warroom lands in the AI slot, never on top of the draft', () => {
  const idea = ideaRecord('CNT-2026-09-08-006', 'บอกราคาในคอนเทนต์ ผิดไหม', { canonical_angle: 'ธง', pillar_bucket: 'sales_team', source_type: 'transcript', source_ref: 'intel:NR-77' });
  assert.deepEqual([idea.source_type, idea.source_ref, idea.acid_test], ['transcript', 'intel:NR-77', 'pending'], 'ยังต้องผ่าน Triage Gate เอง');
  const variant = variantRecord(idea, 'RL', { ai_result: '# Hook\nบท', variant_status: 'ai_improved', cta_keyword: 'AI' });
  assert.deepEqual([variant.variant_id, variant.script_draft, variant.ai_result, variant.variant_status], ['CNT-2026-09-08-006-RL', '', '# Hook\nบท', 'ai_improved']);
  assert.equal(typeof variant.ai_result_at, 'string');
});
