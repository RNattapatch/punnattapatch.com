import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import test from 'node:test';

const root = path.resolve(import.meta.dirname, '..');
const read = (relativePath) => readFile(path.join(root, relativePath), 'utf8');

test('Content Center exposes production work modes without the removed phrase', async () => {
  const source = await read('app/assets/content.mjs');
  for (const label of ['Content Center', 'Board', 'List', 'Queue']) assert.ok(source.includes(label));
  assert.ok(source.includes('content-status-strip'));
  assert.ok(source.includes('content-quick-capture'));
  assert.doesNotMatch(source, /ไอเดีย → ผลิต → วิเคราะห์/);
});

test('News Desk keeps four production work modes and a focused editorial column', async () => {
  const source = await read('app/assets/news.mjs');
  for (const label of ['รอเลือก', 'คิวงาน', 'แหล่งข่าว', 'ประวัติโพสต์']) assert.ok(source.includes(label));
  assert.ok(source.includes('news-desk-column'));
});

test('parity contract cannot reintroduce the removed phrase', async () => {
  const manifest = await read('spec/parity-manifest.json');
  assert.doesNotMatch(manifest, /ไอเดีย → ผลิต → วิเคราะห์/);
});

test('room dialogs and Intel target selection expose accessible names', async () => {
  for (const relativePath of ['app/assets/content.mjs', 'app/assets/news.mjs', 'app/assets/intel.mjs']) {
    const source = await read(relativePath);
    const dialogs = [...source.matchAll(/<dialog\b[^>]*>/g)].map((match) => match[0]);
    assert.ok(dialogs.length > 0, relativePath);
    for (const dialog of dialogs) assert.match(dialog, /aria-(?:label|labelledby)=/, `${relativePath}: ${dialog}`);
  }
  assert.match(await read('app/assets/intel.mjs'), /data-select-target[^>]+aria-label=/);
});
