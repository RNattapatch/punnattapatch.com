import { access, readFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { writeJsonAtomic } from './delivery-state.mjs';
import { loadDemoSeed } from './reset.mjs';
import { restoreSnapshot } from './restore.mjs';
import { createSnapshot, verifySnapshot } from './snapshot.mjs';

async function exists(filePath) {
  try { await access(filePath); return true; } catch { return false; }
}

function markerPath(rootDir) {
  return path.join(rootDir, 'snapshots/.demo-session.json');
}

export async function startDemo({ rootDir = path.resolve(import.meta.dirname, '..'), now = new Date() } = {}) {
  const marker = markerPath(rootDir);
  if (await exists(marker)) throw new Error('Demo session is already active');
  const snapshot = await createSnapshot({ rootDir, label: 'before-demo', now });
  const session = {
    status: 'starting',
    started_at: now.toISOString(),
    snapshot_name: snapshot.name,
    snapshot_directory: snapshot.directory
  };
  await writeJsonAtomic(marker, session);
  try {
    await loadDemoSeed(rootDir, { now });
    session.status = 'active';
    await writeJsonAtomic(marker, session);
    return session;
  } catch (error) {
    await restoreSnapshot({ rootDir, name: snapshot.name, runPostCheck: async () => ({ ok: true }) });
    await rm(marker, { force: true });
    throw error;
  }
}

export async function stopDemo({ rootDir = path.resolve(import.meta.dirname, '..'), now = new Date() } = {}) {
  const marker = markerPath(rootDir);
  if (!await exists(marker)) throw new Error('No active demo session');
  const session = JSON.parse(await readFile(marker, 'utf8'));
  if (!session.snapshot_name) throw new Error('Demo session marker is invalid');
  await verifySnapshot({ rootDir, name: session.snapshot_name });
  const afterDemo = await createSnapshot({ rootDir, label: 'after-demo', now });
  await restoreSnapshot({ rootDir, name: session.snapshot_name, now });
  await rm(marker, { force: true });
  return {
    started_at: session.started_at,
    stopped_at: now.toISOString(),
    restored_snapshot: session.snapshot_name,
    after_demo_snapshot: afterDemo.name
  };
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  try {
    const action = process.argv[2];
    if (action === 'start') {
      const result = await startDemo();
      process.stdout.write(`DEMO_ACTIVE\nSafety snapshot: ${result.snapshot_directory}\n`);
    } else if (action === 'stop') {
      const result = await stopDemo();
      process.stdout.write(`DEMO_STOPPED\nRestored: ${result.restored_snapshot}\nDemo work: ${result.after_demo_snapshot}\n`);
    } else {
      throw new Error('Choose demo action: start or stop');
    }
  } catch (error) {
    process.stderr.write(`DEMO_FAILED\n${error.message}\n`);
    process.exitCode = 1;
  }
}
