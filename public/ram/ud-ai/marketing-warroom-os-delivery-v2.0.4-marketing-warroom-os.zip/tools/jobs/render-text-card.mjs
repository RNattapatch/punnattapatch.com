import path from 'node:path';
import { processQueuedJobs } from './run.mjs';

const rootDir = path.resolve(import.meta.dirname, '../..');
const summary = await processQueuedJobs({ rootDir, jobId: process.argv[2] || null });
process.stdout.write(`${JSON.stringify(summary)}\n`);
process.exitCode = summary.errors ? 1 : 0;
