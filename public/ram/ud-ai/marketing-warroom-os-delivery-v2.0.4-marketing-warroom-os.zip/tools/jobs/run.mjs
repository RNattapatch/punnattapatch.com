import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

import { hasTranscript, scriptScaffold, validateBrief } from '../../app/assets/rewrite.mjs';
import { createStore } from '../../app/store.mjs';

function htmlEscape(value) { return String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;'); }
function cardMarkup(value) { return htmlEscape(value).replace(/\[\[([^\]]+)\]\]/g,'<span class="urgent-note">$1</span>').replaceAll('|','<br>'); }

async function renderTextCard(rootDir, job) {
  const slug = String(job.payload.slug || job.payload.candidate_id).toLowerCase();
  if (!/^[a-z0-9][a-z0-9-]{0,79}$/.test(slug)) throw new Error('Invalid card slug');
  const glance = String(job.payload.glance_line || '');
  if (!glance || glance.length > 120) throw new Error('glance_line must be 1-120 characters');
  const relative = `content-images/${slug}/card-${job.id}.html`;
  const target = path.join(rootDir, 'data/files', relative);
  await mkdir(path.dirname(target), { recursive: true });
  await writeFile(target, `<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Text card</title><link rel="stylesheet" href="../../../app/assets/app.css"></head><body><main class="page"><article class="today-strip"><h1>${cardMarkup(glance)}</h1><p>Marketing Warroom OS</p></article><a class="btn btn-accent" href="/card?text=${encodeURIComponent(glance)}">บันทึกเป็นภาพ</a></main></body></html>\n`, { mode: 0o600 });
  return { path: relative };
}

async function improve(store, job) {
  const { variant_id: id, script = '' } = job.payload;
  const result = `${script.trim()}\n\n# QC\n- ตรวจ Hook, Setup, Rehook, Payoff และ CTA แล้ว\n- ตรวจ claim กับแหล่งข้อมูลก่อนใช้จริง`;
  await store.patch('content_variants', id, { ai_result: result, ai_result_at: new Date().toISOString() });
  return { variant_id: id };
}

// เกลาคลิปที่สืบมาเป็นบทของเรา — tool เปิดแฟ้มเวอร์ชันให้พร้อมโครงเปล่า
// agent ที่รัน /jobs เป็นคนเขียนทับ script_md ด้วยบทจริง (brain/41-reel-rewrite.md) เหมือน ai_improve
async function rewriteReel(store, job) {
  const item = (await store.read('newsroom_items')).items.find((entry) => entry.id === job.payload.item_id);
  if (!item) throw new Error('ไม่พบการ์ดต้นทางในคลัง');
  if (item.kind !== 'clip') throw new Error('เกลาได้เฉพาะการ์ดชนิด clip');
  if (!hasTranscript(item.report_md)) throw new Error('การ์ดนี้ยังไม่มีบทพูดถอดเสียง ([m:ss] …) — แกะใหม่ก่อนแล้วค่อยเกลา');
  const checked = validateBrief(job.payload);
  if (!checked.ok) throw new Error(checked.error);
  const id = `IS-${job.id}`;
  await store.create('intel_scripts', {
    id, item_id: item.id, job_id: job.id, title: checked.brief.theme.slice(0, 200),
    brief: checked.brief, script_md: scriptScaffold({ item, brief: checked.brief }),
    content_id: null, created_at: new Date().toISOString()
  });
  return { script_id: id, item_id: item.id, content_id: null, handoff_error: null,
    instruction: `Agent must write script_md from brain/41-reel-rewrite.md and company/voice.md, then run: node tools/jobs/handoff-script.mjs ${id}` };
}

async function rewrite(store, job) {
  const candidates = await store.read('ca_candidates');
  const candidate = candidates.items.find((item) => item.id === job.payload.candidate_id);
  if (!candidate) throw new Error('Candidate not found');
  await store.patch('ca_candidates', candidate.id, { selected_hook: null, selected_image: null, edited_article_md: null, images: [] });
  return { candidate_id: candidate.id, instruction: 'Agent must rewrite from brain/11-copy-write.md before review' };
}

async function runOne(rootDir, store, job) {
  if (job.job_type === 'render_text_card') {
    const candidate = (await store.read('ca_candidates')).items.find((item)=>item.id===job.payload.candidate_id);
    if (!candidate) throw new Error('Candidate not found');
    const result = await renderTextCard(rootDir, job);
    const images = [...(candidate.images || []), { style:'text-card', url:`/files/${result.path}` }];
    await store.patch('ca_candidates', candidate.id, { images, selected_image: images.length - 1 });
    return result;
  }
  if (job.job_type === 'ai_improve') return improve(store, job);
  if (job.job_type === 'rewrite_reel') return rewriteReel(store, job);
  if (job.job_type === 'rewrite_copy') return rewrite(store, job);
  if (job.job_type === 'render_card') {
    const config = JSON.parse(await readFile(path.join(rootDir, 'company/config.json'), 'utf8'));
    if (!config.kie_api_key) throw new Error('ต้องใส่ kie.ai key ใน company/config.json');
    throw new Error('ใช้ node tools/jobs/render-card.mjs <job-id> เพื่อส่งงานการ์ดซีน');
  }
  throw new Error(`Unsupported job type: ${job.job_type}`);
}

export async function processQueuedJobs({ rootDir = path.resolve(import.meta.dirname, '../..'), jobId = null } = {}) {
  const store = createStore({ rootDir });
  const jobs = (await store.read('wr_jobs')).items.filter((job) => job.status === 'queued' && (!jobId || job.id === jobId));
  let done = 0; let errors = 0;
  for (const job of jobs) {
    const started_at = new Date().toISOString();
    await store.patch('wr_jobs', job.id, { status: 'running', started_at, error: null });
    try {
      const result = await runOne(rootDir, store, job);
      await store.patch('wr_jobs', job.id, { status: 'done', result, finished_at: new Date().toISOString() }); done += 1;
    } catch (error) {
      await store.patch('wr_jobs', job.id, { status: 'error', error: String(error.message).slice(0, 800), finished_at: new Date().toISOString() }); errors += 1;
    }
  }
  return { processed: jobs.length, done, errors };
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  const summary = await processQueuedJobs({ jobId: process.argv[2] || null });
  process.stdout.write(`${JSON.stringify(summary)}\n`);
  process.exitCode = summary.errors ? 1 : 0;
}
