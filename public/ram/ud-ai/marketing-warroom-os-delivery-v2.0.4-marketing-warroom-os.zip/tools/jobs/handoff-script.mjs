// ส่งบทที่เกลาเสร็จเข้า Content Center อัตโนมัติ (ระบบต้นทาง 2026-09-08: worker ทำให้เองหลังเขียนบทเสร็จ)
// ใช้: node tools/jobs/handoff-script.mjs <script-id>
// agent ที่รัน /jobs เรียกหลังเขียน script_md เสร็จ (brain/41-reel-rewrite.md) — ส่งไม่ผ่านบทยังอยู่บนการ์ด
// ผู้ใช้กด ⬆️ ส่งเข้า Content Center เองได้ · ไม่แตะเครือข่าย
import path from 'node:path';
import { pathToFileURL } from 'node:url';

import { ideaRecord, nextContentId, variantRecord } from '../../app/assets/content.mjs';
import { createStore } from '../../app/store.mjs';

export const SCAFFOLD_MARK = 'ยังเป็นโครงเปล่า';

/** บทถูกเขียนจริงแล้วหรือยังเป็นโครงเปล่าที่ tool วางไว้ */
export function isWritten(scriptMd) {
  const text = String(scriptMd ?? '');
  return text.length >= 200 && !text.includes(SCAFFOLD_MARK) && /# 📝 Caption\s*\n\s*\S/.test(text);
}

async function recordJobResult(store, script, patch) {
  if (!script.job_id) return;
  const job = (await store.read('wr_jobs')).items.find((entry) => entry.id === script.job_id);
  if (!job) return;
  await store.patch('wr_jobs', job.id, { result: { ...(job.result || {}), ...patch } });
}

export async function handoffScript({ rootDir = path.resolve(import.meta.dirname, '../..'), scriptId } = {}) {
  const store = createStore({ rootDir });
  const script = (await store.read('intel_scripts')).items.find((entry) => entry.id === scriptId);
  if (!script) throw new Error(`ไม่พบเวอร์ชันบท ${scriptId}`);
  if (script.content_id) return { content_id: script.content_id, variant_id: `${script.content_id}-RL`, already: true };
  if (!isWritten(script.script_md)) {
    const error = 'บทยังเป็นโครงเปล่า — เขียน script_md ให้ครบสามชั้นก่อนแล้วค่อยส่ง';
    await recordJobResult(store, script, { handoff_error: error });
    throw new Error(error);
  }
  try {
    const item = (await store.read('newsroom_items')).items.find((entry) => entry.id === script.item_id);
    const ideas = (await store.read('content_items')).items;
    const idea = ideaRecord(nextContentId(ideas), String(script.title || script.brief?.theme || 'บทจาก Intel Warroom').slice(0, 200), {
      canonical_angle: script.brief?.theme || '', pillar_bucket: script.brief?.pillar || 'ai_in_business',
      source_type: 'transcript', source_ref: `intel:${script.item_id}${item?.source_url ? ` ${item.source_url}` : ''}`
    });
    idea.idea_status = 'active';
    await store.create('content_items', idea);
    const variant = variantRecord(idea, 'RL', { ai_result: script.script_md, variant_status: 'ai_improved', cta_keyword: script.brief?.cta_keyword || '' });
    await store.create('content_variants', variant);
    await store.patch('intel_scripts', script.id, { content_id: idea.content_id });
    await recordJobResult(store, script, { content_id: idea.content_id, handoff_error: null });
    return { content_id: idea.content_id, variant_id: variant.variant_id, already: false };
  } catch (error) {
    await recordJobResult(store, script, { handoff_error: String(error.message).slice(0, 300) });
    throw error;
  }
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  const scriptId = process.argv[2];
  if (!scriptId) { process.stderr.write('ใช้: node tools/jobs/handoff-script.mjs <script-id>\n'); process.exit(2); }
  try {
    const result = await handoffScript({ scriptId });
    process.stdout.write(`${result.already ? 'อยู่ใน Content Center อยู่แล้ว' : 'ส่งเข้า Content Center แล้ว'} — ${result.variant_id}\n`);
  } catch (error) {
    process.stderr.write(`ส่งเข้า Content Center ไม่ผ่าน: ${error.message} — บทยังอยู่บนการ์ด ผู้ใช้กด ⬆️ ส่งเองได้\n`);
    process.exitCode = 1;
  }
}
