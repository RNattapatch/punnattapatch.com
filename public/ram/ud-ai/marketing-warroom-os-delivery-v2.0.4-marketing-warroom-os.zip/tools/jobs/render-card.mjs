import { readFile } from 'node:fs/promises';
import https from 'node:https';
import path from 'node:path';

const rootDir = path.resolve(import.meta.dirname, '../..');
const config = JSON.parse(await readFile(path.join(rootDir, 'company/config.json'), 'utf8'));
if (!config.kie_api_key) throw new Error('ต้องใส่ kie.ai key ใน company/config.json');
const jobId = process.argv[2];
if (!jobId) throw new Error('Usage: node tools/jobs/render-card.mjs <job-id>');

const payload = JSON.stringify({ job_id: jobId });
const request = https.request({ hostname: 'api.kie.ai', path: '/api/v1/jobs', method: 'POST', headers: { authorization: `Bearer ${config.kie_api_key}`, 'content-type': 'application/json', 'content-length': Buffer.byteLength(payload) } }, (response) => {
  const chunks = []; response.on('data', (chunk) => chunks.push(chunk)); response.on('end', () => { process.stdout.write(Buffer.concat(chunks)); if ((response.statusCode || 500) >= 400) process.exitCode = 1; });
});
request.on('error', (error) => { process.stderr.write(`${error.message}\n`); process.exitCode = 1; });
request.end(payload);
