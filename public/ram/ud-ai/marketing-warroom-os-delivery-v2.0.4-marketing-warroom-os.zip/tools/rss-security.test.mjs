import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { Readable } from 'node:stream';
import test from 'node:test';
import { assertPublicHttpsUrl, fetchHttpsText } from './news-daily.mjs';

const publicLookup = async () => [{ address: '93.184.216.34', family: 4 }];

test('RSS security rejects non-HTTPS, localhost, loopback, private, link-local, and private IPv6 targets', async () => {
  const blocked = [
    'http://example.com/feed',
    'https://localhost/feed',
    'https://service.localhost/feed',
    'https://127.0.0.1/feed',
    'https://10.0.0.1/feed',
    'https://172.16.0.1/feed',
    'https://192.168.1.1/feed',
    'https://169.254.1.1/feed',
    'https://[::1]/feed',
    'https://[fc00::1]/feed',
    'https://[fe80::1]/feed',
    'https://[::ffff:127.0.0.1]/feed'
  ];
  for (const url of blocked) await assert.rejects(assertPublicHttpsUrl(url, { lookup: publicLookup }), /HTTPS|private|local|public/i, url);
  await assert.doesNotReject(assertPublicHttpsUrl('https://example.com/feed', { lookup: publicLookup }));
});

function fakeHttps(responses) {
  return (url, options, onResponse) => {
    const request = new EventEmitter();
    request.setTimeout = () => request;
    request.destroy = (error) => queueMicrotask(() => request.emit('error', error));
    queueMicrotask(() => {
      const reply = responses[String(url)];
      const response = Readable.from([reply.body || '']);
      response.statusCode = reply.status;
      response.headers = reply.headers || {};
      onResponse(response);
    });
    return request;
  };
}

test('RSS redirects are revalidated and cannot pivot from public to private targets', async () => {
  const responses = {
    'https://feeds.example/start': { status: 302, headers: { location: 'https://internal.example/feed' } },
    'https://internal.example/feed': { status: 200, body: '<rss />' }
  };
  const lookup = async (hostname) => hostname === 'feeds.example'
    ? [{ address: '93.184.216.34', family: 4 }]
    : [{ address: '10.0.0.8', family: 4 }];

  await assert.rejects(fetchHttpsText('https://feeds.example/start', { request: fakeHttps(responses), lookup }), /private|public/i);
});

test('RSS transport pins the public DNS result so rebinding cannot change the connection target', async () => {
  let resolverCalls = 0;
  const lookup = async () => {
    resolverCalls += 1;
    return resolverCalls === 1
      ? [{ address: '93.184.216.34', family: 4 }]
      : [{ address: '127.0.0.1', family: 4 }];
  };
  const request = (url, options, onResponse) => {
    const outgoing = new EventEmitter();
    outgoing.setTimeout = () => outgoing;
    outgoing.destroy = (error) => queueMicrotask(() => outgoing.emit('error', error));
    options.lookup(url.hostname, { all: true }, (error, addresses) => {
      assert.ifError(error);
      assert.deepEqual(addresses, [{ address: '93.184.216.34', family: 4 }]);
      const response = Readable.from(['<rss />']);
      response.statusCode = 200;
      response.headers = {};
      queueMicrotask(() => onResponse(response));
    });
    return outgoing;
  };

  assert.equal(await fetchHttpsText('https://flip.example/feed', { request, lookup }), '<rss />');
  assert.equal(resolverCalls, 1);
});

test('RSS transport rejects a response body above the configured byte limit', async () => {
  const responses = {
    'https://feeds.example/huge': { status: 200, body: 'x'.repeat(65) }
  };
  await assert.rejects(
    fetchHttpsText('https://feeds.example/huge', { request: fakeHttps(responses), lookup: publicLookup, maxBytes: 64 }),
    /64 bytes/i
  );
});
