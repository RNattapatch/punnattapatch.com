# Jobs

คำสั่ง `/jobs` อ่าน `data/wr_jobs.json` และหยิบงาน `queued` ทีละรายการ

- `render_text_card`: รัน `node tools/jobs/render-text-card.mjs <job-id>` เขียน HTML ลง `data/files/content-images/<slug>/`
- `render_card`: รัน `node tools/jobs/render-card.mjs <job-id>` เมื่อ config มี key เท่านั้น
- `rewrite_copy`: อ่าน candidate และ `brain/11-copy-write.md` แล้วเขียน hooks/article/comments/glance/scene ใหม่โดยไม่สร้างภาพ
- `ai_improve`: อ่าน variant, `brain/40-content-improve.md` และเสียงบริษัท แล้วเขียนผลลง `ai_result`; ห้ามทับ `script_draft`
- `rewrite_reel`: tool เปิดแฟ้มใน `intel_scripts` พร้อมโครงเปล่าให้แล้ว อ่าน `brain/41-reel-rewrite.md` แล้วเขียนทับ `script_md` ด้วยบทจริง จากนั้นรัน `node tools/jobs/handoff-script.mjs <script-id>` เพื่อส่งเข้า Content Center ให้เอง (idea + variant RL ที่มีบทอยู่ในช่อง AI); ห้ามเขียน `content_id` ด้วยมือ — tool เป็นคนใส่ · ส่งไม่ผ่านบทยังอยู่บนการ์ด ผู้ใช้กด ⬆️ ส่งเองได้

ก่อนเริ่มเปลี่ยน status เป็น `running` เมื่อจบใช้ `done`; เมื่อผิดพลาดใช้ `error` และตัดข้อความ error ไม่เกิน 800 ตัวอักษร
