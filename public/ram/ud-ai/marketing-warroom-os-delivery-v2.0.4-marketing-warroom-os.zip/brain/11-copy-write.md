# Copy write

ใช้กับ candidate ทีละข่าว อ่าน `company/voice.md`, `company/persona.md`, `brain/12-writing-rules.md`, `brain/hook-templates.json` และ `brain/image-styles.json` ก่อนเขียน

## Output contract

- `hooks`: 12 มุม มุมละ 1–2 ประโยค รูปประโยคอย่างน้อย 5 แบบ และไม่เปิดซ้ำกัน
- `article_md`: 1,500–2,000 ตัวอักษรไทย, 📍 3–4 จุด, บรรทัดสั้น อ่านออกเสียงได้
- `comment_thread`: 5 รายการ เรียง role นี้เท่านั้น: `cta`, `article`, `source`, `angle2`, `cases`
- `glance_line`: 5–10 คำ ไม่ซ้ำ hook และไม่เกิน 120 ตัวอักษร
- `scene_prompt`: ซีนทำงานที่เห็นร่องรอยของคน ไม่ใช้ภาพเทคโนโลยีสำเร็จรูป และไม่เกิน 1,200 ตัวอักษร
- `scene_field`: เลือกจาก image styles และไม่ซ้ำสองข่าวก่อนหน้า

ชื่อองค์กร ตัวเลข วันที่ และคำกล่าวต้องมาจาก brief เท่านั้น ถ้า brief ไม่มี ให้ตัด ไม่เดา

## Comment roles

1. `cta`: ชวน save หรือส่งต่อให้ persona ที่เกี่ยวกับข่าว
2. `article`: เนื้อหาต้องตรงกับ `article_md` คำต่อคำ
3. `source`: `แหล่งที่มา: <url จาก brief>`
4. `angle2`: มุมต่อยอดที่ลึกกว่าบทความและปิดด้วยคำถาม
5. `cases`: เคสจาก brief หรือรายการ 3 อย่างที่ทำได้พรุ่งนี้เมื่อ brief ไม่มีเคส
