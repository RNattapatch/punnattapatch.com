# Content improve

เกลาร่างโดยรักษาความหมายและ claim เดิม วางโครง:

1. Hook 0–2 วินาที ส่ง payload ทันที
2. Setup บอกว่าจะพาไปเห็นอะไร
3. Body เลือกวิธีนำเสนอหนึ่งแบบ
4. Rehook ทุก 15–20 วินาทีเมื่อมีจุดเปลี่ยน
5. Payoff ตอบคำถามที่เปิดไว้
6. CTA ระบุการกระทำเดียว
7. Hook Text, Chapter Counter, Caption และ First Comment

เขียนผลลง `ai_result` และ `ai_result_at` เท่านั้น ร่างเดิมต้องอยู่ครบ
