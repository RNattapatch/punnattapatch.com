# News daily

คำสั่ง: `/news-daily`

1. อ่านแหล่งข่าว active จาก `data/ca_sources.json`
2. รัน `node tools/news-daily.mjs --brief-out output/content/news-briefs` เสมอ ใน Company mode เครื่องมือดึง RSS/Atom จริงทุก source ผ่าน HTTPS ส่วน Demo mode จะตรวจพบ source ใต้ `output/demo/rss/` และอ่าน fixture ที่เพิ่งสร้างตอน `/demo start` โดยอัตโนมัติ
3. ใช้ `--fixtures examples/rss/` เฉพาะงานทดสอบที่ผู้ใช้พิมพ์ flag นี้ตรงๆ ห้ามสลับ Company source ไป fixture เองเมื่อ network ล่ม
4. เครื่องมือตัด URL ซ้ำ, content hash ซ้ำ และข่าวเกิน 7 วัน แล้วบันทึกเฉพาะ `ca_news_items` พร้อม brief JSON ตาม `brief_files` ในผลลัพธ์ เครื่องมือห้ามสร้าง copy หรือ candidate
5. อ่าน `company/niche-criteria.md` แล้วเลือกไม่เกิน `max_news_per_day` จาก config
6. ต่อ brief หนึ่งไฟล์: เขียน hooks 12 มุม, บทความ, comment thread 5 role, glance line, scene prompt และ scene field ตาม `brain/11-copy-write.md` ลง candidate JSON
7. รัน `node tools/lint-copy.mjs <candidate-a.json> <candidate-b.json> ...` กับข่าวทั้งหมดในรอบเดียวกัน ถ้า RED ให้แก้ได้ไม่เกิน 2 รอบ
8. ตรวจ Acid, Self-Centric, เสียงบริษัท, จังหวะ, claim, card และ story
9. เมื่อ lint ไม่มี RED เท่านั้น จึงบันทึก candidate เป็น `pending_review`, `images: []` และเปลี่ยน news item เป็น `generated`
10. เพิ่ม notification `☀️ มี N ข่าวรอเลือกวันนี้` แล้วรายงาน source ที่ล้มเหลวจาก field `errors`

ผลรอบล่าสุดถูกบันทึกใน `data/.news-daily-run.json` และแสดงบน News Desk เพื่อไม่ให้หน้าเว็บรายงานว่าไม่เคยรันทั้งที่เครื่องมือทำงานแล้ว

ห้ามสร้างภาพในรอบเช้า ห้ามโพสต์ และห้ามแต่ง claim ที่ไม่มีในข่าวต้นทาง
