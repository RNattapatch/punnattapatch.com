# Reel rewrite

งาน `rewrite_reel` จาก Intel Warroom ปุ่ม "เกลาเป็นเวอร์ชันของเรา"

tool เปิดแฟ้มใน `intel_scripts` ให้แล้วพร้อมโครงเปล่า หน้าที่ของคุณคือเขียนทับ `script_md` ด้วยบทจริง

## อ่านก่อนเขียน

1. `company/voice.md` และ `company/business.md` — เสียงและข้อเท็จจริงของบริษัท
2. การ์ดต้นทางใน `newsroom_items` ที่ id ตรงกับ `item_id` — ใช้เฉพาะบรรทัดบทพูด `[m:ss] …`
3. `brain/12-writing-rules.md` และโครงใน `brain/40-content-improve.md`

## brief

`brief.theme` คือธงที่ผู้ใช้ตั้ง ห้ามเปลี่ยนประเด็น
`brief.hook_style` กำหนดวิธีเปิด `brief.length` กำหนดความยาว `brief.cta_keyword` คือคำที่ให้คนพิมพ์เข้ามา
`brief.pillar` คือหมวด Content Mix ถ้าเป็น null ให้เลือกเองแล้วบอกเหตุผลใน `# QC`

## ขอบเขต

ยืมได้เฉพาะ **โครงและจังหวะ** ของคลิปต้นทาง เช่น ลำดับการเปิด จุดที่หักมุม ตำแหน่งที่ทวนคำถาม
ห้ามคัดคำ ห้ามยกประโยค ห้ามใช้ตัวเลขหรือเคสของเป้าหมายเป็นของบริษัท
ตัวอย่างและตัวเลขทุกตัวต้องมาจาก `company/` ถ้าไม่มีให้เว้นเป็นช่องว่างพร้อมโน้ตว่าต้องเติมอะไร

## ผลลัพธ์

เขียนลง `intel_scripts.script_md` ให้ครบสามชั้น คือบทพูด (Hook, Setup, Body, Rehook, Payoff, CTA) `# 🔤 Hook Text` และ `# 📝 Caption`
`title` ให้สั้นและตรงธง

ปิดท้าย `script_md` ด้วยหัวข้อ `# 🧬 โครงที่ยืมมา` 3-5 บรรทัด บอกว่ายืมลำดับ/จังหวะอะไรจากคลิปต้นทาง เพื่อให้ผู้ใช้ตรวจได้ว่าไม่ได้ลอกคำ

## หลังเขียนเสร็จ

รัน `node tools/jobs/handoff-script.mjs <script-id>` ทันที — tool สร้างไอเดียใน Content Center (ชื่อ = ธง) พร้อม variant RL ที่มีบทอยู่ในช่อง AI แล้วใส่ `content_id` ให้เอง และบันทึกผลลง `wr_jobs.result` (`content_id` หรือ `handoff_error`)
ห้ามเขียน `content_id` ด้วยมือ · ส่งไม่ผ่าน = บทยังอยู่บนการ์ด บอกผู้ใช้ว่ากด `⬆️ ส่งเข้า Content Center` เองได้
