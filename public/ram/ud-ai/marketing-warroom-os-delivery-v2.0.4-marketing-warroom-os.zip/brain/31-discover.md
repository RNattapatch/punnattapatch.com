# Discover

คำสั่ง `/discover <ชื่อหรือ URL>`

ค้นหาตัวตนจากเว็บสาธารณะ แยกผลที่เป็นคนหรือแบรนด์เดียวกันออกจากชื่อซ้ำ ระบุ confidence และเหตุผล เก็บช่องทางที่ตรวจได้ใน `handle_suggestions` แล้วให้ผู้ใช้กดรับหรือปัดใน Intel Warroom

เมื่อผู้ใช้เลือก “เพิ่มเข้า watchlist + สืบรอบแรก” ให้สร้าง target และ queued job lane web
