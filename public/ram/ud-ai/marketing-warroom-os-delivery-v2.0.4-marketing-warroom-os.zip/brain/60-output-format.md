# Output format

ทุกคำสั่งต้องตอบด้วย:

1. งานที่ทำและ record/file IDs
2. validation ที่รันพร้อมผล PASS/FAIL
3. รายการที่รอผู้ใช้ตรวจหรือตัดสินใจ
4. next command ที่ใช้ต่อได้

ลิงก์เปิด News Desk บนเครื่องนี้คือ `http://127.0.0.1:4173/news-desk` เท่านั้น

ถ้าทำไม่ได้ ให้บอก record, lane, error และไฟล์ที่เกี่ยว เพื่อให้ปุ่ม Agent Fix สร้างคำสั่งต่อได้ทันที
