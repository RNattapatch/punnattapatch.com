@echo off
chcp 65001 > nul
setlocal
cd /d "%~dp0"

set "NODE_EXE="
where node > nul 2>&1
if not errorlevel 1 set "NODE_EXE=node"
if not defined NODE_EXE if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if not defined NODE_EXE if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "NODE_EXE=%LOCALAPPDATA%\Programs\nodejs\node.exe"
if not defined NODE_EXE if exist "%APPDATA%\nvm\node.exe" set "NODE_EXE=%APPDATA%\nvm\node.exe"
if not defined NODE_EXE goto no_node

echo กำลังเปิด Marketing Warroom OS ...
echo [!] ห้ามปิดหน้าต่างนี้ระหว่างใช้งาน ปิดเมื่อไหร่ระบบหยุดทันที
echo     Do not close this window while you are using the system.
echo.
"%NODE_EXE%" tools\launch.mjs
set "STATUS=%errorlevel%"
echo.
if not "%STATUS%"=="0" goto failed
echo ระบบปิดแล้ว ปิดหน้าต่างนี้ได้เลย
echo The workspace has stopped. You can close this window.
pause
exit /b 0

:failed
echo ระบบเปิดไม่สำเร็จ (exit %STATUS%)
echo The workspace failed to start.
echo เปิดโฟลเดอร์นี้ใน Claude Code หรือ Codex แล้วส่ง /doctor เพื่อดูว่าติดตรงไหน
echo ถ้าเห็น error เกี่ยวกับ import.meta แปลว่า Node.js เก่าเกินไป ให้อัปเดตเป็นเวอร์ชัน 20 ขึ้นไป
pause
exit /b %STATUS%

:no_node
echo.
echo เปิดระบบไม่ได้ เพราะเครื่องนี้ยังหา Node.js ไม่เจอ
echo Cannot start: Node.js was not found on this computer.
echo.
echo วิธีแก้ (ทำครั้งเดียวต่อเครื่อง):
echo   1. ติดตั้ง Node.js เวอร์ชัน 20 ขึ้นไปจาก https://nodejs.org  (เลือกตัว LTS แบบ .msi)
echo   2. ปิดหน้าต่างนี้ แล้วดับเบิลคลิก "Open Workspace.bat" อีกครั้ง
echo.
echo ถ้าติดตั้งแล้วยังขึ้นข้อความเดิม ให้เปิดโฟลเดอร์นี้ใน Claude Code หรือ Codex แล้วส่ง /doctor
echo.
pause
exit /b 1
