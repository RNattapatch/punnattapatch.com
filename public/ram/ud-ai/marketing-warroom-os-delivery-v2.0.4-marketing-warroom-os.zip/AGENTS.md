# Workspace instructions

Read `เริ่มตรงนี้.md`, `brain/00-role.md`, and `DELIVERY-GUIDE.md` before operating this workspace.

Always answer the learner in Thai. This workspace already contains the product code; compile, configure, diagnose, and operate it without asking the learner to write code.

For installation, run the bundled `/install` skill exactly. Do not create, redesign, or modify product features during installation. Stop on any Doctor or Golden-path failure and report the failing gate.

Read every file under `company/` before producing Company work. Use `/demo start` before classroom examples and `/demo stop` before Company work. Never publish externally or store social credentials in this workspace.

When the learner invokes the bundled worker skill (`/worker` in Claude Code, `$worker` in Codex, or a plain-language request to process the queue), process one pass of queued work. Confirm this extracted folder is the current workspace first. Do not start a background daemon or invoke another Claude/Codex CLI inside the current agent.
