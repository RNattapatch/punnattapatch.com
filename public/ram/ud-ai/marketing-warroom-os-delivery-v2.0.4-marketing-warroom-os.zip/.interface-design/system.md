# Marketing Warroom OS Interface System

## Intent

- Human: a business operator or classroom learner who opened this local workspace in Claude Code or Codex minutes ago.
- Primary task: capture evidence, select one source, research it, review the result, rewrite useful structure, and hand work onward.
- Feel: a compact, calm editorial operations desk where evidence visibly moves from queue to result.

## Domain and signature

- Domain vocabulary: target dossier, evidence tray, Scout lane, editorial queue, contact sheet, signal trigger, production board, handover ledger.
- Signature: notebook-tab navigation joined to an evidence tray. The active room sits forward like the open tab of one operating notebook; Intel requests move through explicit evidence states.
- Rejected defaults: no generic dark sidebar, no floating metric-card dashboard, and no decorative gradients or glass cards.

## Visual direction

- Direction: Soft Minimal operations desk, shaped by the production Warroom information hierarchy.
- Palette: canvas `#ffffff`, tray `#f5f6f7`, inset `#eef1f3`, navy `#072b4e`, deep navy `#00162f`, coral `#dd4155`, success `#1d6b47`, warning `#9a5b00`.
- Depth: borders-only for pages and cards. Only dialogs and sticky navigation may use one subtle shadow.
- Surfaces: canvas, tray, raised, and inset. Inputs are inset; cards are raised white; grouped work areas use the tray.
- Typography: bundled Prompt 600/700 for headings and Sarabun 400/600 for body. No network dependency and no system-font primary face.
- Spacing: 4px base. Component gaps and padding use multiples of 4px.
- Shape: compact controls, medium cards, larger dialogs. Radius communicates grouping, not decoration.

## Interaction patterns

- Notebook tabs scroll horizontally on narrow screens. Product identity and utility actions remain readable.
- Primary action is coral. Navy carries product identity and selected operating state. Semantic colors only communicate state.
- Evidence-tray dialogs expose human inputs, detected source, inline validation, and one submit action.
- Interaction transitions stay at or below 200ms and respect `prefers-reduced-motion`.
- Focus is always visible. Dialogs restore focus to their trigger, close on Escape, and label every field and action.
- Empty states include one concrete next action.

## Responsive behavior

- Desktop-first workbench with complete reflow at 375px.
- Intentional tab and kanban scrolling may remain horizontal; the page itself must not overflow.
- Sticky chrome respects safe-area insets.

## Prohibited patterns

- Dark mode or a theme toggle.
- Gradient, glow, glassmorphism, entrance choreography, decorative grid backgrounds, or dramatic card shadows.
- Fake company identity or tagline in application chrome.
- User-selectable technical Scout lanes.

