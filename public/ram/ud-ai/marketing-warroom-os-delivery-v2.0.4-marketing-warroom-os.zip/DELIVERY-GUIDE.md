# Delivery guide

## สิ่งที่ลูกค้าได้รับ

- ระบบ local-first 3 ห้อง พร้อม agent skills สำหรับ Claude Code และ Codex
- Company Context, RSS sources และ Intel targets ของบริษัท
- `snapshots/starter-v1` สำหรับกู้ระบบกลับจุดส่งมอบ
- `DELIVERY-STATUS.json`, หน้า HTML สำหรับแจก ZIP + prompt และไฟล์ SHA-256

## เตรียมเครื่อง

ใช้ macOS หรือ Windows, Node.js 20 ขึ้นไป และ Claude Code หรือ Codex ที่ login ด้วยบัญชีบริษัท ไม่ต้องรัน `npm install` และไม่ต้อง Clone repository

เช็ค Node.js:

```bash
node --version
```

## เตรียม Client Edition

ทีมผู้สอนคัดลอก `examples/client-context.example.json` ออกไปเป็นไฟล์ Context ของลูกค้า แล้วกรอกทุก field ด้วยข้อมูลที่ลูกค้าอนุมัติ จากนั้นรัน:

```bash
node tools/clientize.mjs /absolute/path/to/context.json
node tools/install.mjs
```

ถ้าเห็น `READY`, `Golden: 26/26` และ path ของ `starter-v1` จึงแพ็กส่งลูกค้าได้ ถ้าเห็น `COMPANY_CONTEXT_REQUIRED` ให้แก้ Context ก่อน ห้ามแก้ Doctor ให้ผ่าน

## เปิดระบบ

```bash
node tools/launch.mjs --detach
```

ใน Claude Code หรือ Codex ต้องใส่ `--detach` เสมอ ตัวที่ไม่ใส่จะค้างจนกด Ctrl+C ซึ่ง agent จะถูก timeout ตัดแล้วพา server ตายไปด้วย ส่วนผู้ใช้ทั่วไปให้ดับเบิลคลิก `Open Workspace.command` หรือ `Open Workspace.bat` แล้วเปิดหน้าต่างนั้นค้างไว้

## อัปเดตจาก V2.0.3 โดยเก็บข้อมูลงานเดิม

ใช้ไฟล์ `marketing-warroom-os-update-v2.0.4-from-v2.0.3.zip` ห้ามใช้ ZIP ติดตั้งใหม่ทับ workspace เดิม

1. วาง ZIP อัปเดตในโฟลเดอร์ V2.0.3 เดิม โฟลเดอร์เดียวกับ `VERSION`, `company/` และ `data/`
2. แตก ZIP ตรงนั้น
3. macOS เปิด `marketing-warroom-os-update-v2.0.4/Apply Update.command`
4. Windows เปิด `marketing-warroom-os-update-v2.0.4/Apply Update.bat`
5. เปิดระบบจาก launcher เดิมหลังเห็นข้อความว่า Golden และ Company Doctor ผ่าน

ตัวอัปเดตสร้าง snapshot ก่อนแตะไฟล์ เปลี่ยนเฉพาะ system payload และตรวจ hash ของ `company/`, `data/`, `wiki/` และ `output/` ก่อนจบ หากด่านใดพัง ระบบคืน V2.0.3 ให้อัตโนมัติ

## ใช้ AI agent เป็น worker

ผู้เรียนกดสร้างงานจากหน้าเว็บ แล้วเปิดแท็บ Queue เพื่อกด `คัดลอกคำสั่งประมวลทั้งคิว` ไปวางใน agent ที่เปิด extracted workspace เดียวกัน หรือเรียกตรงด้วย `/worker` ใน Claude Code และ `$worker` ใน Codex คำสั่งที่คัดลอกจะมี path ของ workspace จริงเพื่อกันวางผิด Project Agent จะอ่านทั้งคิว Intel และ Content ประมวลหนึ่งรอบ เขียนผลกลับไฟล์ local และหยุดเอง ผู้เรียนไม่ต้องเขียนโค้ด รุ่นนี้เป็น on-demand worker ไม่ใช่ daemon 24 ชั่วโมง และไม่เรียก AI CLI ซ้อนกัน

Scout รับงานด้วย `claim` งานละหนึ่งครั้ง แล้วจบด้วยผลใดผลหนึ่ง: `done`, `failed` หรือ `preflight_failed` ถ้าขาดไฟล์หรือ transcript หน้า Queue จะแสดง `ต้องส่งหลักฐานเพิ่ม` พร้อมเหตุผลและปุ่มคัดลอกทางต่อ

## ขอบเขต Scout

- Public web/media ใช้ได้เมื่อเว็บอนุญาตและ agent มี web/media tool ที่บัญชีบริษัทเปิดให้
- Workspace image/video ต้องเป็น relative path ที่ dialog อนุมัติ; media ที่เก็บถาวรอยู่ใต้ `data/files/newsroom/`
- Meta Ads discovery ต้องมี connector ที่เปิด `ads_library_search` แบบ read-only ห้าม browser automation และห้ามเปิด ad snapshot
- ถ้า connector ไม่ส่ง creative image/video ให้ผู้ใช้แนบ screenshot, video หรือ transcript ตามทางต่อใน Queue
- Local server เก็บ job เท่านั้นและไม่ fetch URL ที่ผู้ใช้กรอก

## ใช้ Demo โดยไม่ปนกับงานบริษัท

```bash
node tools/demo.mjs start
node tools/demo.mjs stop
```

เริ่ม Demo ซ้อนไม่ได้ และ stop โดยไม่มี session ไม่ได้ เมื่อ stop สำเร็จจะมี `after-demo-*` เก็บงานที่ทำในคลาส และ Company state จะกลับจาก `before-demo-*`

ตอน start ระบบจะเลื่อนวันที่ตัวอย่างให้สด สร้าง RSS local ที่ `output/demo/rss/`, สร้างไฟล์บทตัวอย่าง และเปลี่ยน Intel targets เป็นหน้า local ใต้ `http://127.0.0.1:4173/demo/` ดังนั้นเส้นทางสาธิตสามห้องไม่ต้องพึ่งเว็บภายนอก

## Snapshot และ restore

สร้าง snapshot ก่อนเปลี่ยนงานชุดใหญ่:

```bash
node tools/snapshot.mjs handover
```

ดูชื่อ snapshot จากโฟลเดอร์ `snapshots/` แล้ว restore ด้วยชื่อเท่านั้น:

```bash
node tools/restore.mjs handover-2026-09-12T09-00-00-000Z
```

Restore จะตรวจ checksum ก่อนแตะไฟล์ สร้าง `before-restore-*` แล้วค่อยสลับข้อมูล ถ้า Doctor หลัง restore ไม่ผ่าน ระบบ rollback ให้อัตโนมัติ

คืนจุดส่งมอบ:

```bash
node tools/reset.mjs --starter
```

โหลดข้อมูลสมมติแบบตรงๆ ใช้เฉพาะตอนที่ไม่มี Demo session:

```bash
node tools/reset.mjs --demo
```

## ข้อมูลและ privacy

ข้อมูล Company และงานทั้งหมดอยู่ใน `company/`, `data/`, `output/` และ `wiki/` บนเครื่องนี้ Server bind ที่ `127.0.0.1` และไม่มี remote telemetry รุ่นนี้ใช้คำว่า `Local usage log` ซึ่งปิดไว้เป็นค่าเริ่มต้น

ข้อความที่ส่งให้ Claude Code หรือ Codex ถูกประมวลผลตามบัญชีและนโยบายของผู้ให้บริการ AI ที่บริษัทใช้ ตัด PII ที่ไม่จำเป็นออกก่อนส่ง และห้ามเก็บ Password, Recovery code, Social token หรือ Private key ใน workspace

ดูตารางแยกชัดเจนว่าอะไร local, อะไรต้องใช้อินเทอร์เน็ต และอะไรอยู่นอกขอบเขตที่ `LOCAL-FEATURE-MATRIX.md`

## Support boundary

Included: เปิดระบบ, Doctor, Golden path, Demo, snapshot/restore และ workflow 3 ห้องตามคู่มือ

Outside this kit: shared database, multi-user sync, scheduled automation, auto-post, social-login integration, managed hosting และฟีเจอร์ใหม่ที่ไม่ได้อยู่ใน Client Edition

## แพ็กและแจก

Producer สร้างไฟล์ชื่อฐานเดียวกันสามไฟล์ไว้ข้างกัน: `.zip`, `.html` และ `.sha256.txt` ให้อัปโหลดทั้งสามไฟล์ไป static hosting โฟลเดอร์เดียวกัน หน้า HTML มีสามขั้น: ดาวน์โหลด ZIP, เปิดใน agent และตรวจ `READY`/Golden 26/26 พร้อม prompt กับ checksum
