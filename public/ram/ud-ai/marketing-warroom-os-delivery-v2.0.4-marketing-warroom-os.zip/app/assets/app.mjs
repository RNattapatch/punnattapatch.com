import { api, escapeHtml } from './api.mjs';

const app = document.querySelector('#app');
const PRODUCT_LABEL = 'Marketing Warroom OS';
void PRODUCT_LABEL;
const toastNode = document.querySelector('#app-toast');
const dialog = document.querySelector('#app-dialog');
let dialogTrigger = null;

export function toast(message, error = false) {
  toastNode.textContent = message;
  toastNode.className = error ? 'error-box' : 'success-box';
  toastNode.hidden = false;
  toastNode.style.position = 'fixed';
  toastNode.style.right = '1rem';
  toastNode.style.bottom = '1rem';
  toastNode.style.zIndex = '80';
  window.setTimeout(() => { toastNode.hidden = true; }, 3500);
}

export function showDialog(html) {
  dialogTrigger = document.activeElement;
  document.querySelector('#app-dialog-body').innerHTML = html;
  dialog.showModal();
  dialog.querySelector('button, a, input, select, textarea, [tabindex]:not([tabindex="-1"])')?.focus();
}

dialog.addEventListener('click', (event) => { if (event.target.matches('[data-close-dialog]')) dialog.close(); });
dialog.addEventListener('close', () => { dialogTrigger?.focus?.(); dialogTrigger = null; });

document.querySelector('#app-notifications').addEventListener('click', async () => {
  const { items } = await api('/api/notifications');
  showDialog(`<h2>🔔 การแจ้งเตือน</h2>${items.length ? `<ul class="list">${items.map((item) => `<li class="list-item"><strong>${escapeHtml(item.title)}</strong><p>${escapeHtml(item.body)}</p></li>`).join('')}</ul>` : '<p>ยังไม่มีการแจ้งเตือน</p>'}`);
});

async function updateNotifications() {
  const { items } = await api('/api/notifications').catch(() => ({ items: [] }));
  document.querySelector('#app-notifications span').textContent = items.filter((item) => !item.read).length;
}

const routes = [
  { test: (path) => path === '/' || path === '/content', nav: 'content', module: './content.mjs' },
  { test: (path) => path === '/news-desk', nav: 'news', module: './news.mjs' },
  { test: (path) => path === '/intel', nav: 'intel', module: './intel.mjs' },
  { test: (path) => path === '/jobs', nav: null, utility: 'jobs', module: './jobs.mjs' },
  { test: (path) => path === '/settings', nav: null, utility: 'settings', module: './settings.mjs' },
  { test: (path) => path === '/card', nav: null, module: './card.mjs' }
];

const route = routes.find((item) => item.test(location.pathname)) || routes[0];
if (route.nav) document.querySelector(`[data-nav="${route.nav}"]`)?.setAttribute('aria-current', 'page');
if (route.utility) document.querySelector(`[data-utility="${route.utility}"]`)?.setAttribute('aria-current', 'page');
try {
  const module = await import(route.module);
  await module.render(app, { api, toast, showDialog });
  app.focus({ preventScroll: true });
  await updateNotifications();
} catch (error) {
  app.innerHTML = `<section class="error-box"><h1>เปิดห้องไม่สำเร็จ</h1><p>${escapeHtml(error.message)}</p></section>`;
}
