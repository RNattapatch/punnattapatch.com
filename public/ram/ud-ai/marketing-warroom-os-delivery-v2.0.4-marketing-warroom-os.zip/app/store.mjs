import { copyFile, mkdir, readFile, readdir, rename, rm, stat, writeFile } from 'node:fs/promises';
import path from 'node:path';

export const TABLES = Object.freeze([
  'ca_sources', 'ca_news_items', 'ca_candidates', 'ca_post_log',
  'content_items', 'content_variants', 'publications', 'analytics_snapshots',
  'intel_targets', 'intel_snapshots', 'newsroom_items', 'newsroom_jobs', 'intel_scripts',
  'wr_jobs', 'notifications', 'agent_requests'
]);

const IDS = Object.freeze({
  content_items: 'content_id', content_variants: 'variant_id', publications: 'publication_id',
  analytics_snapshots: 'snapshot_id'
});

const REQUIRED = Object.freeze({
  ca_sources: ['id', 'url', 'topic', 'tags', 'type', 'active', 'added_at'],
  ca_news_items: ['id', 'source_id', 'url', 'title', 'summary', 'published_at', 'fetched_at', 'status', 'content_hash'],
  ca_candidates: ['id', 'news_item_id', 'article_md', 'hooks', 'images', 'status', 'post_to_ig', 'created_at', 'comment_thread', 'glance_line', 'scene_prompt', 'scene_field'],
  ca_post_log: ['id', 'candidate_id', 'platform', 'posted_at'],
  content_items: ['content_id', 'title', 'funnel_stage', 'pillar_bucket', 'angle_type', 'acid_test', 'source_type', 'idea_status', 'created_at'],
  content_variants: ['variant_id', 'content_id', 'format', 'target_platforms', 'working_title', 'markdown_path', 'variant_status', 'created_at', 'status_changed_at'],
  publications: ['publication_id', 'variant_id', 'platform', 'published_at', 'status', 'created_at'],
  analytics_snapshots: ['snapshot_id', 'publication_id', 'captured_at', 'source'],
  intel_targets: ['id', 'slug', 'name', 'aliases', 'role', 'threat', 'section', 'handles', 'reach', 'sells', 'icp', 'why_watch', 'triggers', 'cadence_days', 'created_at', 'updated_at'],
  intel_snapshots: ['id', 'target_id', 'item_id', 'lane', 'metrics', 'created_at'],
  newsroom_items: ['id', 'job_id', 'kind', 'platform', 'source_url', 'title', 'summary', 'score', 'media', 'tags', 'created_at', 'target_id'],
  newsroom_jobs: ['id', 'kind', 'target', 'status', 'created_at', 'updated_at', 'target_id', 'lane', 'result', 'attempts'],
  intel_scripts: ['id', 'item_id', 'title', 'brief', 'script_md', 'created_at'],
  wr_jobs: ['id', 'job_type', 'payload', 'status', 'result', 'created_at'],
  notifications: ['id', 'title', 'body', 'read', 'created_at'],
  agent_requests: ['id', 'newsroom_job_id', 'title', 'prompt', 'status', 'created_at']
});

const ENUMS = Object.freeze({
  ca_sources: { type: ['scrape', 'rss'] },
  ca_candidates: { status: ['pending_review', 'scheduled', 'approved', 'posted', 'rejected'] },
  content_items: {
    funnel_stage: ['top', 'middle', 'bottom', 'retain'],
    pillar_bucket: ['ai_in_business', 'sales_team', 'intersection', 'persona'],
    angle_type: ['problem_first', 'insider_demo', 'how_to', 'proof', 'wedge'],
    acid_test: ['pending', 'passed', 'failed'],
    source_type: ['telegram', 'webapp', 'file_import', 'transcript', 'field_note', 'analytics'],
    idea_status: ['captured', 'triaged', 'selected', 'active', 'published', 'repurpose_candidate', 'archived']
  },
  content_variants: {
    format: ['reel', 'carousel', 'article', 'line_broadcast', 'website_article', 'ad', 'email'],
    variant_status: ['draft', 'ai_improved', 'ready_to_record', 'recorded', 'editing', 'edited', 'scheduled', 'posted', 'analyzed', 'repurposed']
  },
  publications: {
    platform: ['tiktok', 'instagram', 'facebook', 'line_oa', 'linkedin', 'website', 'youtube'],
    status: ['scheduled', 'posted', 'failed', 'deleted'],
    decision_label: ['kill', 'iterate', 'repurpose', 'boost', 'pillar', 'sales_asset']
  },
  intel_targets: {
    threat: ['red', 'orange', 'yellow', 'green', 'na'],
    section: ['competitor', 'benchmark', 'mentor'],
    role: ['competitor', 'benchmark', 'mentor', 'context']
  },
  newsroom_items: {
    kind: ['clip', 'page', 'ads', 'web', 'shot', 'paste'],
    platform: ['tiktok', 'youtube', 'instagram', 'facebook', 'meta-ads', 'web', 'upload']
  },
  newsroom_jobs: {
    status: ['queued', 'submitted', 'running', 'done', 'failed', 'preflight_failed'],
    lane: ['page', 'ads', 'web']
  },
  wr_jobs: {
    // rewrite_reel (2.1.0): Intel Warroom → "เกลาเป็นเวอร์ชันของเรา" · payload {item_id, theme, pillar, hook_style, length, cta_keyword, notes}
    job_type: ['render_card', 'ai_improve', 'rewrite_copy', 'render_text_card', 'rewrite_reel'],
    status: ['queued', 'running', 'done', 'error']
  },
  agent_requests: { status: ['open', 'resolved', 'dismissed'] }
});

function present(value) {
  return value !== undefined && value !== '';
}

function validateScoutJobShape(item) {
  if (typeof item.target !== 'string' || !item.target.trim() || item.target.length > 4_096) {
    throw new Error('Schema validation failed for newsroom_jobs: target');
  }
  if (item.note !== undefined && (typeof item.note !== 'string' || item.note.length > 2_000)) {
    throw new Error('Schema validation failed for newsroom_jobs: note');
  }
  if (!item.result || typeof item.result !== 'object' || Array.isArray(item.result)) {
    throw new Error('Schema validation failed for newsroom_jobs: result');
  }
  const resultBounds = { capability_mode: 80, source_type: 80, next_action: 2_000, reason: 2_000, source_url: 4_096, snapshot_url: 4_096, item_id: 200 };
  for (const [field, max] of Object.entries(resultBounds)) {
    if (item.result[field] !== undefined && (typeof item.result[field] !== 'string' || item.result[field].length > max)) {
      throw new Error(`Schema validation failed for newsroom_jobs result: ${field}`);
    }
  }
  if (item.result.requested_media !== undefined && (!Array.isArray(item.result.requested_media)
    || item.result.requested_media.length > 12
    || item.result.requested_media.some((value) => typeof value !== 'string' || !value || value.length > 100))) {
    throw new Error('Schema validation failed for newsroom_jobs result: requested_media');
  }
  if (JSON.stringify(item.result).length > 65_536) throw new Error('Schema validation failed for newsroom_jobs: result exceeds 64 KB');
}

function validate(table, item) {
  if (!TABLES.includes(table) || !item || typeof item !== 'object' || Array.isArray(item)) {
    throw new Error(`Schema validation failed for ${table}`);
  }
  for (const field of REQUIRED[table]) {
    if (!present(item[field])) throw new Error(`Schema validation failed for ${table}: ${field}`);
  }
  for (const [field, allowed] of Object.entries(ENUMS[table] || {})) {
    const values = Array.isArray(item[field]) ? item[field] : [item[field]];
    if (values.some((value) => value != null && !allowed.includes(value))) {
      throw new Error(`Schema validation failed for ${table}: ${field}`);
    }
  }
  if (table === 'newsroom_jobs') validateScoutJobShape(item);
  if (!present(item[IDS[table] || 'id'])) throw new Error(`Schema validation failed for ${table}: id`);
  return item;
}

function safeRelative(rootDir, relativePath, allowedRoots) {
  if (typeof relativePath !== 'string' || path.isAbsolute(relativePath)) throw new Error('Path is outside allowed root');
  const resolved = path.resolve(rootDir, relativePath);
  const allowed = allowedRoots.some((root) => {
    const base = path.resolve(rootDir, root);
    return resolved === base || resolved.startsWith(`${base}${path.sep}`);
  });
  if (!allowed) throw new Error('Path is outside allowed root');
  return resolved;
}

async function atomicWrite(target, data, backupDir) {
  await mkdir(path.dirname(target), { recursive: true });
  await mkdir(backupDir, { recursive: true });
  try {
    await stat(target);
    const stamp = `${Date.now()}-${process.hrtime.bigint()}`;
    await copyFile(target, path.join(backupDir, `${path.basename(target, '.json')}-${stamp}.json`));
    const prefix = `${path.basename(target, '.json')}-`;
    const old = (await readdir(backupDir)).filter((name) => name.startsWith(prefix)).sort().reverse().slice(20);
    await Promise.all(old.map((name) => rm(path.join(backupDir, name), { force: true })));
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  const temporary = `${target}.write-${process.pid}-${process.hrtime.bigint()}`;
  try {
    await writeFile(temporary, `${JSON.stringify(data, null, 2)}\n`, { mode: 0o600 });
    await rename(temporary, target);
  } catch (error) {
    await rm(temporary, { force: true });
    throw error;
  }
}

export function createStore({ rootDir = path.resolve(import.meta.dirname, '..') } = {}) {
  const backupDir = path.join(rootDir, 'data/.bak');
  const idField = (table) => IDS[table] || 'id';
  const fileFor = (table) => {
    if (!TABLES.includes(table)) throw new Error(`Unknown table: ${table}`);
    return path.join(rootDir, 'data', `${table}.json`);
  };

  async function read(table) {
    const data = JSON.parse(await readFile(fileFor(table), 'utf8'));
    if (data?.version !== 1 || !Array.isArray(data.items)) throw new Error(`Schema validation failed for ${table}`);
    data.items.forEach((item) => validate(table, item));
    return data;
  }

  async function write(table, data) {
    if (data?.version !== 1 || !Array.isArray(data.items)) throw new Error(`Schema validation failed for ${table}`);
    data.items.forEach((item) => validate(table, item));
    await atomicWrite(fileFor(table), data, backupDir);
    return data;
  }

  async function create(table, item) {
    validate(table, item);
    const data = await read(table);
    const key = idField(table);
    if (data.items.some((current) => current[key] === item[key])) throw new Error(`Duplicate ${key}`);
    data.items.push(item);
    return write(table, data);
  }

  async function update(table, id, item) {
    validate(table, item);
    const data = await read(table);
    const key = idField(table);
    const index = data.items.findIndex((current) => current[key] === id);
    if (index < 0) throw new Error(`${table} record not found`);
    if (item[key] !== id) throw new Error(`${key} cannot change`);
    data.items[index] = item;
    await write(table, data);
    return item;
  }

  async function patch(table, id, changes) {
    const data = await read(table);
    const key = idField(table);
    const item = data.items.find((current) => current[key] === id);
    if (!item) throw new Error(`${table} record not found`);
    return update(table, id, { ...item, ...changes, [key]: id });
  }

  async function remove(table, id) {
    const data = await read(table);
    const key = idField(table);
    const next = data.items.filter((item) => item[key] !== id);
    if (next.length === data.items.length) return false;
    await write(table, { version: 1, items: next });
    return true;
  }

  async function query(table, filters = {}) {
    const data = await read(table);
    const { order, limit, ...where } = filters;
    let items = data.items.filter((item) => Object.entries(where).every(([key, rawWanted]) => {
      const value = item[key];
      const wanted = String(rawWanted).startsWith('eq.') ? String(rawWanted).slice(3) : rawWanted;
      const inValues = String(rawWanted).match(/^in\.\((.*)\)$/)?.[1].split(',');
      if (inValues) return inValues.includes(String(value ?? ''));
      if (Array.isArray(value)) return value.map(String).includes(String(wanted));
      if (typeof value === 'boolean') return value === (wanted === true || wanted === 'true');
      return String(value ?? '') === String(wanted);
    }));
    if (order) {
      const [field, direction = 'asc'] = String(order).split('.');
      items = [...items].sort((left, right) => String(left[field] ?? '').localeCompare(String(right[field] ?? '')) * (direction === 'desc' ? -1 : 1));
    }
    if (limit !== undefined) items = items.slice(0, Math.max(0, Number(limit) || 0));
    return { version: 1, items };
  }

  async function writeMarkdown(relativePath, content) {
    const target = safeRelative(rootDir, relativePath, ['output/content']);
    await mkdir(path.dirname(target), { recursive: true });
    await writeFile(target, `${String(content).replace(/\n$/, '')}\n`, { mode: 0o600 });
    return relativePath;
  }

  return { idField, read, write, create, update, patch, remove, query, writeMarkdown };
}

export { validate as validateRecord };
