# Offline examples

- `rss/*.xml`: ข่าวสมมติสาม source สำหรับ `/news-daily --fixtures examples/rss/`
- `web/example-brand.html`: หน้าเว็บสมมติสำหรับ scout lane web
- `seed/three-rooms.json`: state เริ่มต้นของ News, Content และ Intel
- `expected/content-improve.json`: ผล AI improve แบบคงที่สำหรับ golden path
- `expected/scout-web.json`: ผล Scout web สมมติ พร้อม snapshot และ trigger keyword
- `expected/candidates/*.json`: ผลเขียนจาก agent แบบคงที่สำหรับ golden path เครื่องมือ `news-daily` ไม่ได้สร้าง copy ชุดนี้

ข้อมูลทั้งหมดเป็นเรื่องสมมติ ใช้รัน `node tools/golden-check.mjs` ได้โดยไม่ต่อ network
