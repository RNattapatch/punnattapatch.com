---
name: reset
description: Use when explicitly returning Marketing Warroom OS to its delivery baseline or loading the checked-in three-room Demo seed outside a Demo session.
---

# Reset with an explicit target

Ask which state the user named, then run exactly one command:

| Requested state | Command |
|---|---|
| Original Client Edition | `node tools/reset.mjs --starter` |
| Fictitious three-room data | `node tools/reset.mjs --demo` |

Never run reset without a flag. Before `--demo`, confirm `snapshots/.demo-session.json` does not exist; use `/demo stop` when a Demo session is active. Report the automatic safety snapshot and run the matching Doctor mode after reset.
