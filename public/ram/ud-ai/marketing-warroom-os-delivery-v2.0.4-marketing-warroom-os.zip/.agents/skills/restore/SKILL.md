---
name: restore
description: Use when Company or operating data is damaged, a user requests recovery, or a verified snapshot must replace the current local state.
---

# Restore a verified snapshot

1. Read the requested snapshot name from `snapshots/`. Accept a name only, never a path.
2. Run `node tools/restore.mjs <snapshot-name>`.
3. If checksum verification fails, stop without changing files and report the corrupt snapshot.
4. If restore succeeds, report the requested snapshot and the generated `before-restore-*` safety backup.
5. Run `node tools/doctor.mjs --company`. Do not continue Company work until it passes.

For the original delivery state, use `node tools/reset.mjs --starter`. Never delete snapshots or bypass checksum/post-restore checks.
