---
name: discover
description: ค้นหาตัวตนและช่องทางใหม่เพื่อเสนอให้ผู้ใช้ตรวจ
---

# Discover

อ่าน `brain/31-discover.md` เขียนช่องทางลง suggestions เท่านั้น ผู้ใช้เป็นคนรับเข้าแฟ้ม
