---
name: update
description: อัปเดตเฉพาะส่วนระบบโดยรักษา company, data, wiki และ output
---

# Update

ใช้ตัวอัปเดตที่ตรงกับเวอร์ชันเดิมเท่านั้น ก่อนอัปเดตต้องสร้าง snapshot จากนั้นเปลี่ยนเฉพาะ system payload และรัน Golden กับ Company Doctor

ห้ามแตะ `company/`, `data/`, `wiki/` และ `output/` หากด่านใดไม่ผ่านต้อง rollback system payload และคืน customer-owned roots จาก snapshot
