---
name: improve
description: เกลาสคริปต์โดยรักษาร่างเดิมและข้อเท็จจริง
---

# Improve

อ่าน `brain/40-content-improve.md`, company voice และ writing rules บันทึกผลที่ `ai_result` ห้ามทับ `script_draft`
