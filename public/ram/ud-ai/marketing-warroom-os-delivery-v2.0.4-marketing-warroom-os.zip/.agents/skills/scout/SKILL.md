---
name: scout
description: สืบ target ตาม lane โดยเคารพข้อจำกัดเว็บและข้อมูล
---

# Scout

อ่าน `brain/30-scout.md` และ `brain/50-guardrails.md` ก่อนทำงาน

1. รับ queued job เดียวด้วย `node tools/scout-job.mjs claim [job-id]`
2. ทำเฉพาะ job ที่รับได้และบันทึก capability ที่ใช้จริง
3. จบด้วย `complete` หรือ `needs-evidence` ผ่าน JSON ใต้ `output/scout-staging/`
4. ตรวจ `node tools/worker-status.mjs` ซ้ำและรายงาน ID กับสถานะสุดท้าย

ห้าม automation บนโดเมน Meta ห้ามเปิด ad snapshot ห้ามให้ local server fetch URL และห้ามเปิด agent subprocess ซ้อน
