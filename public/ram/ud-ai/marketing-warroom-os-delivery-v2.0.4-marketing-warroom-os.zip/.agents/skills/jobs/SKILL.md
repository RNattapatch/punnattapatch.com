---
name: jobs
description: ประมวลผลงาน queued จากคิวภายในเครื่อง
---

# Jobs

อ่าน `brain/20-jobs.md` หยิบงานทีละรายการ อัปเดต status และเก็บ error ที่นำไปแก้ต่อได้

งาน `ai_improve` ทำตาม `brain/40-content-improve.md` งาน `rewrite_reel` ทำตาม `brain/41-reel-rewrite.md` โดยเขียนทับ `script_md` ในแฟ้มที่ tool เปิดไว้ แล้วรัน `node tools/jobs/handoff-script.mjs <script-id>` ให้บทเข้า Content Center เอง
