---
name: install
description: Use when opening Marketing Warroom OS for the first time, receiving a Client Edition, or retrying setup after COMPANY_CONTEXT_REQUIRED.
---

# Install Marketing Warroom OS

Install the bundled system. Do not create, redesign, or modify a feature during setup.

1. Read `brain/00-role.md` and `DELIVERY-GUIDE.md`.
2. Run `node tools/install.mjs` from the workspace root.
3. If the result is `COMPANY_CONTEXT_REQUIRED`, stop. Ask for the approved Context JSON path, run `node tools/clientize.mjs <absolute-context-path>`, then rerun step 2.
4. If any Doctor or Golden gate fails, report the exact FAIL and stop. Do not weaken the gate.
5. When the result is `READY` and Golden is `26/26`, run `node tools/launch.mjs --detach`. It starts the workspace in a background process and returns as soon as the port answers. Never run `node tools/launch.mjs` without `--detach` from an agent session: that form holds the terminal until Ctrl+C, so the tool-call timeout kills the server you just started.
6. Report the state, Golden count, `starter-v1` path, app URL, and the exact next action. Tell the user that the double-click launchers (`Open Workspace.command`, `Open Workspace.bat`) keep the workspace running only while their window stays open.

Never run a package installer, add a dependency, replace Company Context, or overwrite `snapshots/starter-v1`.
