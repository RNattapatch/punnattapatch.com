---
name: snapshot
description: Use before a major Company-data change, at handover, or when the user asks to save a recoverable Marketing Warroom OS state.
---

# Save a recoverable state

Choose a short label that describes the checkpoint, such as `handover`, `before-campaign`, or `week-01`. Run:

```bash
node tools/snapshot.mjs <label>
```

Report the complete snapshot directory. Open its `manifest.json` and confirm it lists Company, data, output and wiki files with SHA-256 values.

Do not use `starter-v1` as a manual label. That immutable baseline belongs to `/install`. Do not move, rename, edit or delete a snapshot after creation.
