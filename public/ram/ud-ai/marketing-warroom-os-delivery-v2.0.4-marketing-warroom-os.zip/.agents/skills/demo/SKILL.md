---
name: demo
description: Use when teaching, practicing, or exploring Marketing Warroom OS with fictitious data instead of Company operating data.
---

# Run an isolated Demo session

For `/demo start`:

1. Run `node tools/demo.mjs start`.
2. Confirm `DEMO_ACTIVE` and report the `before-demo-*` safety snapshot. Demo start refreshes time-sensitive dates, writes local RSS fixtures under `output/demo/rss/`, and materializes the bundled example script.
3. Run `node tools/doctor.mjs --demo`. Stop if any item fails.

For `/demo stop`:

1. Run `node tools/demo.mjs stop`.
2. Confirm `DEMO_STOPPED`, the restored snapshot, and the `after-demo-*` archive.
3. Run `node tools/doctor.mjs --company` before Company work.

Never start a second Demo session, delete the session marker, or edit Company Context to make Demo data fit.
