---
name: doctor
description: Use when Marketing Warroom OS will not install, launch, restore, or pass a delivery gate, and before reporting that a Client Edition is ready.
---

# Diagnose the workspace

Choose the mode that matches the job:

| Job | Command |
|---|---|
| Check machine and files | `node tools/doctor.mjs --preflight` |
| Approve Company delivery | `node tools/doctor.mjs --company` |
| Approve classroom seed | `node tools/doctor.mjs --demo` |

Read every result. `FAIL` blocks the next step. `WARN` names an optional capability and does not block the three-room workflow.

Fix only the reported environment, Context, file, source, target, or port issue. Do not change product features or weaken a check. Rerun the same mode and report each remaining FAIL with one exact action.
