---
name: news-daily
description: ดึงและคัดข่าวรายวัน สร้าง candidate ให้ผู้ใช้ตรวจ
---

# News daily

อ่าน `brain/10-news-daily.md` และทำตามครบ รัน `node tools/news-daily.mjs --brief-out output/content/news-briefs` โดยไม่เพิ่ม flag: Company mode จะดึง RSS จริง ส่วน Demo mode ใช้ local fixture ที่ `/demo start` สร้างให้อัตโนมัติ ใช้ `--fixtures` เฉพาะเมื่อผู้ใช้สั่ง flag นี้ตรงๆ ห้ามโพสต์หรือสร้างภาพเอง
