#!/bin/zsh -l
#
# Marketing Warroom OS — ตัวเปิดระบบสำหรับ macOS
#
# ใช้ login shell (-l) เพื่อให้เห็น PATH ชุดเดียวกับตอนเปิด Terminal เอง
# (Node.js ที่ติดตั้งผ่าน Homebrew, nvm หรือ Volta จะไม่อยู่ใน PATH ของ non-login shell)
#
# ครั้งแรกหลังแตก ZIP: ถ้า macOS เตือน "unidentified developer" หรือ "cannot be opened"
# ให้คลิกขวาที่ไฟล์นี้ → Open → กด Open ซ้ำอีกครั้ง (ทำครั้งเดียวต่อเครื่อง)

setopt null_glob
cd "${0:A:h}" || exit 1

NODE_BIN=""
if command -v node > /dev/null 2>&1; then
  NODE_BIN="$(command -v node)"
else
  for candidate in \
    /opt/homebrew/bin/node \
    /usr/local/bin/node \
    "$HOME/.volta/bin/node" \
    "$HOME/.local/bin/node" \
    "$HOME"/.nvm/versions/node/*/bin/node(On) \
    /opt/homebrew/opt/node@*/bin/node(On)
  do
    if [[ -x "$candidate" ]]; then
      NODE_BIN="$candidate"
      break
    fi
  done
fi

if [[ -z "$NODE_BIN" ]]; then
  print ""
  print "❌ เปิดระบบไม่ได้ เพราะเครื่องนี้ยังหา Node.js ไม่เจอ"
  print ""
  print "วิธีแก้ (ทำครั้งเดียวต่อเครื่อง):"
  print "  1. ติดตั้ง Node.js เวอร์ชัน 20 ขึ้นไปจาก https://nodejs.org"
  print "     เลือกตัว LTS แบบไฟล์ .pkg แล้วกด Next จนจบ"
  print "  2. ปิดหน้าต่างนี้ แล้วดับเบิลคลิก \"Open Workspace.command\" อีกครั้ง"
  print ""
  print "ถ้าติดตั้งแล้วยังขึ้นข้อความเดิม ให้เปิดโฟลเดอร์นี้ใน Claude Code หรือ Codex แล้วส่ง /doctor"
  print ""
  read "?กด Enter เพื่อปิดหน้าต่างนี้ "
  exit 1
fi

NODE_MAJOR="$("$NODE_BIN" -p 'process.versions.node.split(".")[0]' 2> /dev/null)"
if [[ -z "$NODE_MAJOR" || "$NODE_MAJOR" -lt 20 ]]; then
  print ""
  print "❌ Node.js ในเครื่องเก่าเกินไป ระบบนี้ต้องการเวอร์ชัน 20 ขึ้นไป"
  print "   ตัวที่เจอ: $NODE_BIN ($("$NODE_BIN" --version 2> /dev/null))"
  print "   ติดตั้งตัว LTS จาก https://nodejs.org แล้วเปิดไฟล์นี้อีกครั้ง"
  print ""
  read "?กด Enter เพื่อปิดหน้าต่างนี้ "
  exit 1
fi

print "กำลังเปิด Marketing Warroom OS ..."
print "⚠️  ห้ามปิดหน้าต่างนี้ระหว่างใช้งาน ปิดเมื่อไหร่ระบบหยุดทันที"
print ""
"$NODE_BIN" tools/launch.mjs
STATUS=$?
print ""
if [[ $STATUS -ne 0 ]]; then
  print "❌ ระบบเปิดไม่สำเร็จ (exit $STATUS)"
  print "   เปิดโฟลเดอร์นี้ใน Claude Code หรือ Codex แล้วส่ง /doctor เพื่อดูว่าติดตรงไหน"
else
  print "ระบบปิดแล้ว ปิดหน้าต่างนี้ได้เลย"
fi
read "?กด Enter เพื่อปิดหน้าต่างนี้ "
exit $STATUS
