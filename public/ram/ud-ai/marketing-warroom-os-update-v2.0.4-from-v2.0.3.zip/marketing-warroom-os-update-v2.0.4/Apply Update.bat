@echo off
chcp 65001 > nul
setlocal
set "UPDATE_DIR=%~dp0"
for %%I in ("%UPDATE_DIR%..") do set "TARGET_DIR=%%~fI"
set "NODE_EXE="
where node > nul 2>&1
if not errorlevel 1 set "NODE_EXE=node"
if not defined NODE_EXE if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if not defined NODE_EXE if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "NODE_EXE=%LOCALAPPDATA%\Programs\nodejs\node.exe"
if not defined NODE_EXE goto no_node
echo กำลังอัปเดต Marketing Warroom OS V2.0.3 ^> V2.0.4 ...
"%NODE_EXE%" "%UPDATE_DIR%payload\tools\update.mjs" --target "%TARGET_DIR%" --source "%UPDATE_DIR%payload"
set "STATUS=%errorlevel%"
echo.
if "%STATUS%"=="0" echo อัปเดตเสร็จแล้ว ดับเบิลคลิก Open Workspace.bat เพื่อเปิดระบบ
if not "%STATUS%"=="0" echo อัปเดตไม่สำเร็จ ระบบคืนไฟล์ V2.0.3 ให้แล้ว
pause
exit /b %STATUS%
:no_node
echo ไม่พบ Node.js 20+ — ติดตั้งจาก https://nodejs.org แล้วเปิดไฟล์นี้อีกครั้ง
pause
exit /b 1
