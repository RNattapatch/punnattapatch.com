#!/bin/zsh -l
setopt null_glob
UPDATE_DIR="${0:A:h}"
TARGET_DIR="${UPDATE_DIR:h}"

NODE_BIN=""
if command -v node > /dev/null 2>&1; then
  NODE_BIN="$(command -v node)"
else
  for candidate in /opt/homebrew/bin/node /usr/local/bin/node "$HOME/.volta/bin/node" "$HOME/.local/bin/node" "$HOME"/.nvm/versions/node/*/bin/node(On); do
    if [[ -x "$candidate" ]]; then NODE_BIN="$candidate"; break; fi
  done
fi

if [[ -z "$NODE_BIN" ]]; then
  print "❌ ไม่พบ Node.js 20+ — ติดตั้งจาก https://nodejs.org แล้วเปิดไฟล์นี้อีกครั้ง"
  read "?กด Enter เพื่อปิดหน้าต่างนี้ "
  exit 1
fi

print "กำลังอัปเดต Marketing Warroom OS V2.0.3 → V2.0.4 ..."
"$NODE_BIN" "$UPDATE_DIR/payload/tools/update.mjs" --target "$TARGET_DIR" --source "$UPDATE_DIR/payload"
STATUS=$?
print ""
if [[ $STATUS -eq 0 ]]; then
  print "อัปเดตเสร็จแล้ว ดับเบิลคลิก Open Workspace.command เพื่อเปิดระบบ"
else
  print "อัปเดตไม่สำเร็จ ระบบคืนไฟล์ V2.0.3 ให้แล้ว"
fi
read "?กด Enter เพื่อปิดหน้าต่างนี้ "
exit $STATUS
