# Marketing Warroom OS update guide

ไฟล์นี้ใช้สำหรับอัปเดต V2.0.3 → V2.0.4 เท่านั้น

1. วางไฟล์ ZIP ไว้ในโฟลเดอร์ Marketing Warroom OS V2.0.3 เดิม โฟลเดอร์เดียวกับ `VERSION`, `company/` และ `data/`
2. แตก ZIP ตรงนั้น จะได้โฟลเดอร์ `marketing-warroom-os-update-v2.0.4/`
3. macOS: ดับเบิลคลิก `Apply Update.command` ภายในโฟลเดอร์อัปเดต
4. Windows: ดับเบิลคลิก `Apply Update.bat` ภายในโฟลเดอร์อัปเดต
5. เมื่อเห็นข้อความว่าอัปเดตสำเร็จ ให้เปิดระบบด้วย `Open Workspace.command` หรือ `Open Workspace.bat` ที่โฟลเดอร์หลัก

ตัวอัปเดตจะสร้าง snapshot ก่อนเปลี่ยนไฟล์ รักษา `company/`, `data/`, `wiki/` และ `output/` ไว้ทุก byte แล้วรัน Golden กับ Company Doctor หากด่านใดไม่ผ่าน ระบบจะคืนไฟล์ V2.0.3 ให้อัตโนมัติ
