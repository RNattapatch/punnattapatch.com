---
name: worker
description: ประมวลผลงานที่ค้างใน Marketing Warroom OS โดยใช้ Claude Code หรือ Codex ที่เปิด workspace นี้
---

# Run one worker pass

ตอบผู้ใช้เป็นภาษาไทยเสมอ ตัว agent ที่เปิด workspace นี้คือ worker ห้ามเปิด `claude` หรือ `codex` ซ้อนเป็น subprocess

1. รัน `node tools/worker-status.mjs` เพื่ออ่านคิวจริง
2. ถ้ามี `scouting` ให้อ่าน `brain/30-scout.md` และ `brain/50-guardrails.md` จากนั้นรับงานเดียวด้วย `node tools/scout-job.mjs claim [job-id]` ทำหลักฐาน แล้วจบด้วย `complete` หรือ `needs-evidence` ผ่าน JSON ใต้ `output/scout-staging/`
3. ถ้ามี `writing` ให้อ่าน `brain/20-jobs.md` แล้วทำ `wr_jobs` ที่ queued ทีละงาน งานเขียนต้องอ่าน Company Context ก่อนและผ่านกฎตรวจของงานนั้น
4. รัน `node tools/worker-status.mjs` ซ้ำ งานผ่านต้องออกจาก queued; Scout job ต้องเป็น `done`, `failed` หรือ `preflight_failed` และสถานะที่ขอหลักฐานต้องมี `reason` กับ `next_action`
5. รายงานจำนวนที่ทำสำเร็จ ล้ม และค้าง พร้อม ID

หนึ่งคำสั่งทำหนึ่งรอบแล้วจบ ไม่เปิด daemon ไม่โพสต์ Social และไม่เก็บ token ใน workspace
