---
name: update
description: อัปเดตเฉพาะส่วนระบบโดยรักษา company, data และ output
---

# Update

อัปเดตได้เฉพาะ `app/`, `brain/`, `tools/`, `.claude/` และ `.agents/` ห้ามแตะ `company/`, `data/`, `wiki/` และ `output/`
