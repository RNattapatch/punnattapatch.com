# Tested with

หลักฐานชุดนี้บันทึกจาก Delivery V2.0.3 เมื่อวันที่ 14 กันยายน 2026 ค่า SHA-256 ของ ZIP อยู่ในไฟล์ `.sha256.txt` ข้างแต่ละ ZIP เพื่อไม่ให้ archive อ้าง hash ของตัวเอง

## Runtime

- Node.js 25.9.0; minimum supported version 20
- macOS Darwin 25.3.0
- Node.js standard library only; no package install and no `node_modules`
- Launchers included for macOS and Windows
- Windows command selection, launcher guards and foreign-port protection verified by automated tests; a physical Windows machine was not used in this release cycle, so smoke-test `Open Workspace.bat` on one real Windows machine before a classroom that uses Windows
- macOS launcher verified by running it with `PATH` stripped to `/usr/bin:/bin`: the login shell still found Node and the workspace started; with no Node reachable it printed the Thai instructions and waited for Enter instead of closing

## Automated verification

- Source suite: 137/137 tests passed
- Reproducible package: unchanged source bytes produce the same ZIP SHA-256 even when file timestamps differ
- Package clean-room suite: 125/125 tests passed in an extracted ZIP
- Parity manifest: 520/520 checks passed
- Golden gate: 26/26 passed, counted as Golden Path 18 steps plus Definition of Ready 8 checks (`install` reports the combined 26/26)
- Launcher scripts: automated checks on the login-shell shebang, the Node fallback list, the Node 20 floor, a pause on every exit path, the executable bit that survives the archive, and CRLF line endings in the Windows file
- Detached launch: an agent-style `node tools/launch.mjs --detach` returned in about one second, the workspace kept serving after the parent process exited, a second call reported `WORKSPACE_ALREADY_RUNNING`, and a port that never answers is reported as a failure instead of success
- Agent skills: Claude Code and Codex copies are byte-equivalent
- Unified worker: queued Content and Intel work is discovered from the same local tables and `/worker` runs one pass in either Claude Code or Codex
- Scout lifecycle: claim, explicit evidence request, atomic completion rollback, staging boundary, media path/existence/size checks and terminal-state protection passed
- Scout intake: public URLs, supported workspace image/video, pasted evidence and advertiser queries classify without network access; private/credential/unsupported URLs are rejected
- Install portability: `DELIVERY-STATUS.json` stores `snapshots/starter-v1` as a relative path and does not expose the workstation path
- Credential scan: no credential pattern found in the delivery workspace
- RSS transport: HTTPS-only, public-address validation on every redirect, DNS pinning against rebinding and a 5 MB response limit
- Source readiness: Company Doctor fetched and parsed both example feeds; an injected 404/non-feed source failed delivery as designed
- Demo freshness: a future-dated rehearsal fetched 3 local feeds, inserted 3 current stories, wrote 3 briefs, materialized the example script and exposed 3 local Intel evidence pages
- Local secret file: Company config is tightened to owner-only permission after every browser write on supported filesystems
- Snapshot recovery: manifest, unlisted-file rejection, corrupt-snapshot refusal, rollback and byte-for-byte restore passed
- Update safety: failed update rolled back every engine byte without changing Company data

## Browser QA

Headless Chrome QA covered five product routes at viewport widths 375, 768 and 1440 pixels, plus the shared Intel research flow.

- Content Center
- News Desk
- Intel Room
- Jobs
- Settings

All 90 browser assertions passed: product-only chrome, white canvas, active notebook tab, Content phrase removal, four News modes, both Intel entry points, target preselection, invalid URL ARIA/focus, valid public-web detection, queue `/worker` copy, keyboard focus and 375px overflow. Content Center also verified all six production stages stay on one horizontal row and scroll inside the board at 375, 768 and 1440 pixels. A separate fresh-load probe confirmed `scrollY=0`, the first heading below the sticky header, no full-page focus frame and no document overflow at 375px. There were no console errors or failed local resources. Screenshots are stored outside the customer ZIP under `output/web-app/marketing-warroom-os-delivery-v2.0.3-classroom/qa-screenshots/`.

## Package evidence

- Master archive: `dist/marketing-warroom-os-delivery-v2.0.3.zip`; exact SHA-256 is in the adjacent `.sha256.txt`
- Classroom Client Edition: `marketing-warroom-os-delivery-v2.0.3-marketing-warroom-os.zip`; exact SHA-256 is in the adjacent `.sha256.txt`
- Master and Client archives passed `unzip -tq`; both agent skill trees are byte-identical

## Recovery drill

The extracted Client Edition passed this full drill:

1. Start Demo Mode.
2. Stop Demo Mode.
3. Confirm the managed workspace hash returned byte-for-byte.
4. Corrupt a Company file deliberately.
5. Restore from the immutable `starter-v1` snapshot.
6. Run Company Doctor successfully.

## Re-run commands

Run from the workspace root:

```bash
node tools/build-kit.mjs
find app tools -type f \( -name '*.mjs' -o -name '*.js' \) -print0 | xargs -0 -n1 node --check
node --test tools/*.test.mjs
node tools/parity-check.mjs
node tools/golden-check.mjs
node tools/doctor.mjs --preflight
node tools/doctor.mjs --demo
```

For a clientized workspace, also run:

```bash
node tools/doctor.mjs --company
```
