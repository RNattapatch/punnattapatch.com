import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

import { lintCandidates } from './lint-copy.mjs';

const OPENINGS = [
  'ยอดเช้าวันนี้', 'ถ้าลูกค้าถาม', 'ใบเสนอราคานี้', 'ทีมหน้าร้านเห็น',
  'ก่อนปิดยอดเดือน', 'เจ้าของเปิดจอ', 'ข้อมูลก้อนเดียว', 'ลองนับเวลาที่หาย',
  'คำถามบนโต๊ะ', 'ร้านข้างบ้านทำ', 'ความเสี่ยงจริง', 'พรุ่งนี้ทีมคุณ'
];

function article() {
  const lines = Array.from({ length: 44 }, (_, index) => `ทีมขายตรวจข้อมูลชุดเดียวก่อนตอบลูกค้ารอบ${index + 1}`);
  return [lines.slice(0, 11).join('\n'), '📍 หลักฐานอยู่บนโต๊ะ', lines.slice(11, 22).join('\n'), '📍 ทีมเห็นจุดเดียวกัน', lines.slice(22, 33).join('\n'), '📍 งานถัดไปชัดขึ้น', lines.slice(33).join('\n')].join('\n');
}

function candidate(id = 'A') {
  const body = article();
  const hooks = OPENINGS.map((opening, index) => ({
    id: `h${index + 1}`,
    style: `style-${index + 1}`,
    text: `${opening}${index < 2 ? 'หรือเปล่า?' : ''} เจ้าของเห็นหลักฐานจากข่าวแล้วจึงเลือกงานหนึ่งชิ้นให้ทีมทำต่อได้ โดยไม่ต้องเดาข้อมูลเพิ่มจากพาดหัว`
  }));
  return {
    id,
    hooks,
    article_md: body,
    glance_line: 'ข้อมูลชุดเดียว | [[ทีมคุณตอบไวขึ้น]]',
    comment_thread: [
      { role: 'cta', text: 'ส่งให้หัวหน้าทีมที่ต้องตรวจข้อมูลทุกเช้า' },
      { role: 'article', text: body },
      { role: 'source', text: 'แหล่งที่มา: https://example.invalid/story' },
      { role: 'angle2', text: 'อีกมุมหนึ่งคือเวลาที่ทีมใช้ตามหาหลักฐาน' },
      { role: 'cases', text: 'พรุ่งนี้เลือกข้อมูลหนึ่งชุดให้ทีมทดลองใช้' }
    ]
  };
}

test('copy lint accepts a complete candidate with the production role order', () => {
  const result = lintCandidates([candidate()]);
  assert.deepEqual(result.red, []);
  assert.deepEqual(result.yellow, []);
  assert.equal(result.ok, true);
});

test('copy lint rejects repeated hook openings across different stories', () => {
  const first = candidate('A');
  const second = candidate('B');
  const result = lintCandidates([first, second]);
  assert.equal(result.ok, false);
  assert.ok(result.red.some((finding) => finding.includes('ข้ามข่าว')));
});

test('copy lint enforces cta, article, source, angle2, cases in that exact order', () => {
  const value = candidate();
  value.comment_thread = [
    { role: 'article', text: value.article_md },
    { role: 'evidence', text: 'หลักฐาน' },
    { role: 'owner', text: 'เจ้าของ' },
    { role: 'action', text: 'ลงมือ' },
    { role: 'source', text: 'แหล่งข่าว' }
  ];
  const result = lintCandidates([value]);
  assert.ok(result.red.some((finding) => finding.includes('cta,article,source,angle2,cases')));
});

test('copy lint reads comma-separated company forbidden words from voice markdown', () => {
  const value = candidate();
  value.hooks[4].text += ' สูตรวิเศษ';
  const result = lintCandidates([value], { voiceText: '# Voice\n\n- Forbidden words: โตไว, สูตรวิเศษ' });
  assert.ok(result.red.some((finding) => finding.includes('สูตรวิเศษ') && finding.includes('company/voice.md')));
});

test('copy lint flags long article lines and excessive hook em dashes as RED', () => {
  const value = candidate();
  value.article_md += `\n${'บรรทัดนี้ยาวเกินกรอบการอ่านบนหน้าจอ'.repeat(3)}`;
  value.comment_thread.find((entry) => entry.role === 'article').text = value.article_md;
  for (let index = 0; index < 4; index += 1) value.hooks[index].text += ' — ตรวจใหม่';
  const result = lintCandidates([value]);
  assert.ok(result.red.some((finding) => finding.includes('บรรทัดยาวเกิน 48')));
  assert.ok(result.red.some((finding) => finding.includes('em-dash')));
});

test('copy lint reports repeated negative parallelism as YELLOW, not RED', () => {
  const value = candidate();
  value.hooks[0].text += ' ไม่ใช่เรื่องเร็ว แต่เป็นเรื่องชัด';
  value.comment_thread[3].text += ' ไม่ใช่เรื่องเครื่องมือ แต่เป็นเรื่องข้อมูล';
  const result = lintCandidates([value]);
  assert.ok(result.yellow.some((finding) => finding.includes('โครง "ไม่ใช่ X แต่ Y"')));
  assert.ok(!result.red.some((finding) => finding.includes('โครง "ไม่ใช่ X แต่ Y"')));
});

test('copy lint rejects hard hook length and emoji violations', () => {
  const value = candidate();
  value.hooks[0].text = 'สั้นเกินไป 🚀';
  const result = lintCandidates([value]);
  assert.ok(result.red.some((finding) => finding.includes('นอกกรอบ 80-175')));
  assert.ok(result.red.some((finding) => finding.includes('มี emoji')));
});

test('copy lint CLI reads the first file without --voice and materializes expected article_lines fixtures', async (t) => {
  const directory = await mkdtemp(path.join(os.tmpdir(), 'warroom-lint-cli-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const bad = candidate('FIRST-FILE');
  bad.article_lines = bad.article_md.split('\n');
  delete bad.article_md;
  bad.comment_thread = bad.comment_thread.map((entry) => entry.role === 'article' ? { ...entry, text: '$article_md' } : entry);
  bad.comment_thread[0].role = 'wrong';
  const good = candidate('SECOND-FILE');
  const badFile = path.join(directory, 'bad.json');
  const goodFile = path.join(directory, 'good.json');
  await writeFile(badFile, JSON.stringify(bad));
  await writeFile(goodFile, JSON.stringify(good));

  const result = spawnSync(process.execPath, [path.resolve('tools/lint-copy.mjs'), badFile, goodFile], { cwd: path.resolve('.'), encoding: 'utf8' });
  assert.equal(result.status, 1);
  assert.match(result.stdout, /FIRST-FILE/);
  assert.match(result.stdout, /cta,article,source,angle2,cases/);
  assert.doesNotMatch(result.stdout, /ได้ 0 ตัวอักษรไทย/);
});
