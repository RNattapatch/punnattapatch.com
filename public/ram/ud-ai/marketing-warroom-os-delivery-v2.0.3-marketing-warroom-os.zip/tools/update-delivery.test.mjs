import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import test from 'node:test';
import { hashTree, makeTestWorkspace } from './delivery-test-helpers.mjs';
import { updateWorkspace } from './update.mjs';

const ENGINE_ROOTS = ['app', 'brain', 'tools', '.claude', '.agents'];

async function engineHash(rootDir) {
  const values = [];
  for (const folder of ENGINE_ROOTS) values.push(`${folder}:${await hashTree(path.join(rootDir, folder))}`);
  return values.join('|');
}

test('failed Golden gate rolls back every engine byte without touching Company data', async (t) => {
  const target = await makeTestWorkspace();
  const source = await makeTestWorkspace();
  t.after(target.cleanup);
  t.after(source.cleanup);
  await writeFile(path.join(source.rootDir, 'tools/golden-check.mjs'), 'process.stderr.write("injected failure\\n"); process.exitCode = 1;\n');
  const engineBefore = await engineHash(target.rootDir);
  const companyBefore = await hashTree(path.join(target.rootDir, 'company'));

  await assert.rejects(updateWorkspace({ rootDir: target.rootDir, sourceDir: source.rootDir }), /rolled back/i);

  assert.equal(await engineHash(target.rootDir), engineBefore);
  assert.equal(await hashTree(path.join(target.rootDir, 'company')), companyBefore);
});

test('successful update reports the real safety snapshot directory', async (t) => {
  const target = await makeTestWorkspace();
  const source = await makeTestWorkspace();
  t.after(target.cleanup);
  t.after(source.cleanup);

  const result = await updateWorkspace({ rootDir: target.rootDir, sourceDir: source.rootDir });

  assert.equal(result.ok, true);
  assert.equal(typeof result.snapshot, 'string');
  assert.match(result.snapshot, /snapshots[/\\]before-update-/);
  const workspaceVersion = (await readFile(path.join(target.rootDir, 'VERSION'), 'utf8')).trim();
  assert.match(await readFile(path.join(result.snapshot, 'manifest.json'), 'utf8'), new RegExp(`"workspace_version": "${workspaceVersion}"`));
});
