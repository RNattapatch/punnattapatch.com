import path from 'node:path';
import { pathToFileURL } from 'node:url';

import { createStore } from '../app/store.mjs';

export async function workerStatus({ rootDir = path.resolve(import.meta.dirname, '..') } = {}) {
  const store = createStore({ rootDir });
  const [writingTable, scoutingTable] = await Promise.all([store.read('wr_jobs'), store.read('newsroom_jobs')]);
  const writingIds = writingTable.items.filter((item) => item.status === 'queued').map((item) => item.id);
  const scoutingIds = scoutingTable.items.filter((item) => item.status === 'queued').map((item) => item.id);
  return {
    writing: { count: writingIds.length, ids: writingIds },
    scouting: { count: scoutingIds.length, ids: scoutingIds },
    total: writingIds.length + scoutingIds.length
  };
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  const status = await workerStatus();
  process.stdout.write(`${JSON.stringify(status, null, 2)}\n`);
  process.stdout.write(status.total ? 'WORK_PENDING — run /worker in the agent\n' : 'WORKER_IDLE — no queued work\n');
}
