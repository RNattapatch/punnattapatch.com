import assert from 'node:assert/strict';
import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

import { createRequestDispatcher } from '../app/server.mjs';
import { TABLES } from '../app/store.mjs';

async function fixture() {
  const rootDir = await mkdtemp(path.join(os.tmpdir(), 'warroom-server-'));
  for (const dir of ['data', 'data/files/newsroom', 'app/views', 'app/assets', 'company', 'examples/web']) await mkdir(path.join(rootDir, dir), { recursive: true });
  for (const table of TABLES) await writeFile(path.join(rootDir, 'data', `${table}.json`), '{"version":1,"items":[]}\n');
  await writeFile(path.join(rootDir, 'app/views/shell.html'), '<h1>{{PRODUCT_NAME}}</h1>');
  await writeFile(path.join(rootDir, 'app/brand.json'), '{"productName":"Warroom","productTagline":"Local"}');
  await writeFile(path.join(rootDir, 'company/config.json'), '{"company_name":"Example Co","max_news_per_day":3,"kie_api_key":""}');
  await writeFile(path.join(rootDir, 'company/business.md'), '# Business\n');
  await writeFile(path.join(rootDir, 'data/files/newsroom/report.md'), '# report\n');
  await writeFile(path.join(rootDir, 'data/.news-daily-run.json'), '{"ran_at":"2026-09-13T02:00:00.000Z","inserted":3,"errors":[]}\n');
  await writeFile(path.join(rootDir, 'examples/web/example-brand.html'), '<!doctype html><title>Example Brand</title><h1>Local evidence</h1>');
  return { rootDir, dispatch: createRequestDispatcher({ rootDir }) };
}

function json(result) { return JSON.parse(String(result.body)); }

test('REST table route supports create, filtered read, patch, and delete', async (t) => {
  const { rootDir, dispatch } = await fixture();
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  const item = { id: 'SRC-1', url: 'https://example.invalid/feed', topic: 'AI', tags: [], type: 'rss', active: true, added_at: '2026-09-05T00:00:00.000Z' };
  assert.equal((await dispatch({ method: 'POST', url: '/api/ca_sources', headers: { 'content-type': 'application/json' }, body: JSON.stringify(item) })).status, 201);
  assert.deepEqual(json(await dispatch({ method: 'GET', url: '/api/ca_sources?active=true' })).items.map((x) => x.id), ['SRC-1']);
  const patched = json(await dispatch({ method: 'PATCH', url: '/api/ca_sources/SRC-1', headers: { 'content-type': 'application/json' }, body: '{"topic":"Sales"}' }));
  assert.equal(patched.topic, 'Sales');
  assert.equal((await dispatch({ method: 'DELETE', url: '/api/ca_sources/SRC-1' })).status, 204);
});

test('meta, company allowlist, similarity, notifications, static files, and markdown write routes work', async (t) => {
  const { rootDir, dispatch } = await fixture();
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  const meta = json(await dispatch({ method: 'GET', url: '/api/meta' }));
  assert.equal(meta.productName, 'Warroom');
  assert.equal(meta.newsDailyLastRun.inserted, 3);
  assert.equal(String((await dispatch({ method: 'GET', url: '/' })).body), '<h1>Warroom</h1>');
  assert.match(String((await dispatch({ method: 'GET', url: '/demo/example-brand' })).body), /Local evidence/);
  assert.equal((await dispatch({ method: 'GET', url: '/demo/not-allowed' })).status, 404);
  assert.match(String((await dispatch({ method: 'GET', url: '/files/newsroom/report.md' })).body), /report/);
  assert.equal((await dispatch({ method: 'GET', url: '/files/../../company/config.json' })).status, 404);
  const similar = json(await dispatch({ method: 'POST', url: '/api/similar', headers: { 'content-type': 'application/json' }, body: '{"query":"AI ทีมขาย","items":[{"content_id":"A","title":"AI สำหรับทีมขาย"}]}' }));
  assert.equal(similar.items[0].content_id, 'A');
  await dispatch({ method:'POST', url:'/api/content_items', headers:{'content-type':'application/json'}, body:JSON.stringify({ content_id:'CNT-2026-09-05-001', title:'AI สำหรับทีมขาย', canonical_angle:'ลดงานค้นข้อมูล', topic_cluster:'AI', funnel_stage:'top', pillar_bucket:'intersection', angle_type:'how_to', acid_test:'pending', offer_link:null, source_type:'webapp', source_ref:'manual', idea_status:'captured', freshness_score:1, similarity_group:null, decision_label:null, created_at:'2026-09-05T00:00:00.000Z', last_used_at:null }) });
  assert.equal(json(await dispatch({method:'GET',url:'/api/similar?q=AI%20ทีมขาย'})).items[0].content_id,'CNT-2026-09-05-001');
  assert.equal((await dispatch({ method: 'PUT', url: '/api/company/business.md', headers: { 'content-type': 'text/markdown' }, body: '# Updated' })).status, 200);
  assert.equal((await dispatch({ method: 'PUT', url: '/api/company/secrets.env', headers: { 'content-type': 'text/plain' }, body: 'bad' })).status, 404);
  const written = json(await dispatch({ method: 'POST', url: '/api/write-md', headers: { 'content-type': 'application/json' }, body: '{"path":"output/content/reel/a.md","content":"# A"}' }));
  assert.equal(written.path, 'output/content/reel/a.md');
  assert.equal(json(await dispatch({ method: 'GET', url: '/api/notifications' })).items.length, 0);
});

test('mutating routes require matching content types and reject oversized or malformed input', async (t) => {
  const { rootDir, dispatch } = await fixture();
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  assert.equal((await dispatch({ method: 'POST', url: '/api/ca_sources', headers: {}, body: '{}' })).status, 415);
  assert.equal((await dispatch({ method: 'POST', url: '/api/ca_sources', headers: { 'content-type': 'application/json' }, body: '{' })).status, 400);
  assert.equal((await dispatch({ method: 'POST', url: '/api/ca_sources', headers: { 'content-type': 'application/json' }, body: 'x'.repeat(1_000_001) })).status, 400);
});

test('query route supports compact PostgREST eq, in, order, and limit operators', async (t) => {
  const { rootDir, dispatch } = await fixture();
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  const base = { url:'https://example.invalid/feed', topic:'AI', tags:[], type:'rss', active:true, added_at:'2026-09-05T00:00:00.000Z' };
  for (const [id, date] of [['SRC-1','2026-09-04T00:00:00.000Z'],['SRC-2','2026-09-05T00:00:00.000Z'],['SRC-3','2026-09-06T00:00:00.000Z']]) await dispatch({method:'POST',url:'/api/ca_sources',headers:{'content-type':'application/json'},body:JSON.stringify({...base,id,added_at:date})});
  const eq = json(await dispatch({method:'GET',url:'/api/ca_sources?topic=eq.AI&order=added_at.desc&limit=1'}));
  assert.deepEqual(eq.items.map((x)=>x.id),['SRC-3']);
  const inside = json(await dispatch({method:'GET',url:'/api/ca_sources?id=in.(SRC-1,SRC-2)&order=added_at.asc'}));
  assert.deepEqual(inside.items.map((x)=>x.id),['SRC-1','SRC-2']);
});
