import assert from 'node:assert/strict';
import { cp, mkdtemp, readFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

import { runDoctor } from './doctor.mjs';
import { resetWorkspace } from './reset.mjs';
import { queuePing } from './ping.mjs';

const sourceRoot = path.resolve(import.meta.dirname, '..');

test('doctor passes a complete extracted workspace', async () => {
  const result = await runDoctor({ rootDir: sourceRoot });
  assert.equal(result.ok, true, JSON.stringify(result.checks));
});

test('reset snapshots current state then loads three-room dummy data', async (t) => {
  const rootDir = await mkdtemp(path.join(os.tmpdir(), 'warroom-reset-'));
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  for (const folder of ['company','data','examples','output','wiki']) await cp(path.join(sourceRoot,folder),path.join(rootDir,folder),{recursive:true});
  await cp(path.join(sourceRoot,'VERSION'),path.join(rootDir,'VERSION'));
  const result = await resetWorkspace({ rootDir, mode: 'demo' });
  assert.match(result.snapshot, /before-reset-demo/);
  assert.equal(JSON.parse(await readFile(path.join(rootDir,'data/content_items.json'),'utf8')).items.length, 2);
  assert.equal(JSON.parse(await readFile(path.join(rootDir,'data/intel_targets.json'),'utf8')).items.length, 3);
});

test('ping is local-only and records phase event', async (t) => {
  const rootDir = await mkdtemp(path.join(os.tmpdir(), 'warroom-ping-'));
  t.after(() => rm(rootDir, { recursive: true, force: true }));
  await cp(path.join(sourceRoot,'VERSION'),path.join(rootDir,'VERSION'));
  const result=await queuePing({rootDir,step:'P7',status:'ready',now:'2026-09-05T00:00:00.000Z'});
  assert.equal(result.sent,false);
  assert.match(await readFile(path.join(rootDir,'data/.events.jsonl'),'utf8'),/"step":"P7"/);
});
