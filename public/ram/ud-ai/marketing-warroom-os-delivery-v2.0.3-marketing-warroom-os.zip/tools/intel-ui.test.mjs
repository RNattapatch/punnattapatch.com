import assert from 'node:assert/strict';
import test from 'node:test';
import { __setStateForTest, announceScriptChanges, defaultTarget, nextLabel, renderTrigger, researchDialogMarkup, rewriteStatus, scriptSignature } from '../app/assets/intel.mjs';
import { scoutJobPresentation } from '../app/assets/scout-intake.mjs';
import { briefLine, hasTranscript, scriptScaffold, suggestedTheme, validateBrief } from '../app/assets/rewrite.mjs';

test('single-source research dialog is understandable without lane knowledge', () => {
  const html = researchDialogMarkup({ targets: [{ id: 'TGT-1', name: 'คู่แข่งหนึ่ง' }], targetId: 'TGT-1' });
  for (const text of ['สืบ URL / ไฟล์', 'URL หรือ path ใน workspace', 'ต้องการดูอะไรเป็นพิเศษ', 'เก็บเข้าแฟ้ม', 'ส่งให้ Agent สืบ']) assert.ok(html.includes(text));
  assert.doesNotMatch(html, /<select[^>]*name="kind"/);
});

test('research dialog escapes targets, preselects the dossier, and exposes inline errors', () => {
  const html = researchDialogMarkup({
    targets: [{ id: 'TGT-1', name: '<img src=x onerror=alert(1)>' }, { id: 'TGT-2', name: 'อีกแฟ้ม' }],
    targetId: 'TGT-2', raw: 'http://127.0.0.1/private', error: 'URL ต้องเป็นแหล่งสาธารณะ'
  });
  assert.ok(html.includes('&lt;img src=x onerror=alert(1)&gt;'));
  assert.doesNotMatch(html, /<img src=x/);
  assert.match(html, /value="TGT-2" selected/);
  assert.match(html, /name="raw"[^>]*aria-invalid="true"[^>]*aria-describedby="scout-input-error"/);
  assert.match(html, /id="scout-input-error"[^>]*role="alert"[^>]*>URL ต้องเป็นแหล่งสาธารณะ/);
});

test('Scout queue states tell the operator what happened and what to do next', () => {
  assert.deepEqual(scoutJobPresentation({ status: 'queued' }), {
    tone: 'warning', title: 'รอ Agent', detail: 'รัน /worker ใน Claude Code หรือ Codex', action: '/worker'
  });
  assert.deepEqual(scoutJobPresentation({ status: 'preflight_failed', result: { reason: 'Meta ไม่ส่งไฟล์ภาพ', next_action: 'แนบ screenshot ของแอด' } }), {
    tone: 'warning', title: 'ต้องส่งหลักฐานเพิ่ม', detail: 'Meta ไม่ส่งไฟล์ภาพ', action: 'แนบ screenshot ของแอด'
  });
});

test('Intel auto-opens the first fired target and uses operator-facing timing labels', () => {
  const targets=[{id:'A',triggers:[]},{id:'B',triggers:[{fired_at:'2026-09-04T00:00:00.000Z'}]}];
  assert.equal(defaultTarget(targets).id,'B');
  const now=new Date('2026-09-05T00:00:00.000Z').getTime();
  assert.equal(nextLabel({next_scout_at:'2026-09-08T00:00:00.000Z'},now),'ถัดไปอีก 3 วัน');
  assert.equal(nextLabel({next_scout_at:'2026-09-03T00:00:00.000Z'},now),'เลยกำหนด 2 วัน');
});

test('trigger rows show state, keywords, fired date, and acknowledgement action', () => {
  const html=renderTrigger({text:'pricing change',keywords:['pricing','plan'],fired_at:'2026-09-05T00:00:00.000Z'},0);
  for(const value of ['⚠️','เช็คคำ:','pricing','ดังเมื่อ','ปิดธง','data-ack="0"'])assert.ok(html.includes(value));
  assert.match(renderTrigger({text:'new offer',keywords:[],fired_at:null},1),/○.*ยังไม่ดัง/s);
});

test('a clip can only be rewritten when the report really carries a timestamped transcript', () => {
  const transcript = Array.from({ length: 8 }, (_, index) => `[0:${String(index * 7).padStart(2, '0')}] ประโยคที่ถอดมาจากคลิปต้นทาง`).join('\n');
  assert.equal(hasTranscript(`# รายงาน\n${transcript}`), true);
  assert.equal(hasTranscript('# รายงาน\nสรุปเฉยๆ ไม่มีบทพูด'), false, 'รายงานที่ไม่มีบทพูด = เกลาไม่ได้');
  assert.equal(hasTranscript('[0:01] สั้นไป'), false, 'บทพูดสั้นเกินไปก็ยังเกลาไม่ได้');
  assert.equal(hasTranscript(null), false);
});

test('the theme hint is lifted from the scout report so the operator is not staring at an empty box', () => {
  assert.equal(suggestedTheme('บรรทัดอื่น\nตัวอย่างที่เอาไปใช้ได้: เปิดด้วยราคาแล้วค่อยเล่าเหตุผล\nท้ายรายงาน'), 'เปิดด้วยราคาแล้วค่อยเล่าเหตุผล');
  assert.equal(suggestedTheme('รายงานที่ไม่มีบรรทัดนั้น'), '');
});

test('the rewrite brief is checked before a job is queued, and fills in safe defaults', () => {
  assert.deepEqual(validateBrief({ theme: 'สั้น' }), { ok: false, error: 'บอกธง/หัวข้อคลิปอย่างน้อย 8 ตัวอักษรก่อน' });
  assert.equal(validateBrief({ theme: 'บอกราคาในคอนเทนต์ ผิดไหม', pillar: 'ไม่มีหมวดนี้' }).ok, false);
  const filled = validateBrief({ theme: '  บอกราคาในคอนเทนต์ ผิดไหม  ', pillar: '', hook_style: 'ไม่รู้จัก', length: '', cta_keyword: '' });
  assert.deepEqual(filled.brief, { theme: 'บอกราคาในคอนเทนต์ ผิดไหม', pillar: null, hook_style: 'auto', length: 'mid', cta_keyword: 'AI', notes: '' });
});

test('the queued script starts as an empty structure that still tells the agent what to write', () => {
  const brief = validateBrief({ theme: 'บอกราคาในคอนเทนต์ ผิดไหม', pillar: 'sales_team', hook_style: 'question', length: 'mid', cta_keyword: 'AI', notes: 'ใส่เคสจริง' }).brief;
  const markdown = scriptScaffold({ item: { id: 'NR-77', title: 'คลิปคู่แข่ง', platform: 'tiktok' }, brief });
  for (const heading of ['# Hook (0-2 วิ', '# Setup (2-10 วิ', '# Body', '↻ Rehook:', '# Payoff', '# CTA', '# 🔤 Hook Text', '# 📝 Caption']) assert.ok(markdown.includes(heading), heading);
  assert.match(markdown, /ยืมโครงจาก: คลิปคู่แข่ง \(tiktok\) · item NR-77/);
  assert.match(markdown, /โน้ต: ใส่เคสจริง/);
  assert.match(markdown, /company\/voice\.md/, 'ต้องชี้ให้ agent ไปอ่านเสียงของบริษัทก่อนเขียน');
  assert.match(markdown, /ห้ามคัดคำ/);
  assert.equal(briefLine(brief), 'ทีมขาย/บริหาร 30% · คำถามเจ็บจุด · 45-75 วิ · DM: AI');
});

test('the rewrite status line tells the operator which stage the script is in, and the toast fires only when something really changed', () => {
  const toasts = [];
  const written = '# ธง\n\n# Hook\nx\n\n# 📝 Caption\n📍 หนึ่ง';
  const scaffold = '# ธง\n\n# QC\n- ยังเป็นโครงเปล่า — รัน `/jobs`';
  const item = { id: 'NR-1' };
  const job = (extra) => ({ id: 'JOB-1', job_type: 'rewrite_reel', payload: { item_id: 'NR-1' }, created_at: new Date(Date.now() - 65_000).toISOString(), started_at: null, finished_at: null, status: 'queued', result: {}, error: null, ...extra });
  __setStateForTest({ rwJobs: [job({})], scripts: [] }, { toast: (message) => toasts.push(message) });
  assert.match(rewriteStatus(item), /⏳ รอ agent หยิบงาน — รัน \/jobs · ส่งเมื่อ 1:0\d นาทีที่แล้ว/);
  __setStateForTest({ rwJobs: [job({ status: 'running', started_at: new Date(Date.now() - 125_000).toISOString() })] });
  assert.match(rewriteStatus(item), /⏳ AI กำลังเกลา… 2:0\d นาที \(ปกติ 5-10 นาที\)/);
  __setStateForTest({ rwJobs: [job({ status: 'done' })], scripts: [{ id: 'IS-1', item_id: 'NR-1', job_id: 'JOB-1', title: 'ธง', script_md: scaffold, content_id: null }] });
  assert.match(rewriteStatus(item), /✍️ agent กำลังเขียนบท "ธง" — เสร็จแล้วส่งเข้า Content Center ให้เอง/);
  __setStateForTest({ rwJobs: [job({ status: 'error', error: 'ไม่พบการ์ดต้นทางในคลัง', finished_at: new Date().toISOString() })], scripts: [] });
  assert.match(rewriteStatus(item), /❌ งานเกลาล่าสุดพัง: ไม่พบการ์ดต้นทางในคลัง/);
  __setStateForTest({ rwJobs: [job({ status: 'done', result: { handoff_error: 'ตั้ง Content ID ไม่ได้' } })], scripts: [{ id: 'IS-1', item_id: 'NR-1', job_id: 'JOB-1', title: 'ธง', script_md: written, content_id: null }] });
  assert.match(rewriteStatus(item), /⚠️ บทเสร็จแล้วแต่ส่งเข้า Content Center ไม่ผ่าน \(ตั้ง Content ID ไม่ได้\) — กด ⬆️ ส่งเองได้/);
  __setStateForTest({ rwJobs: [job({ status: 'done', result: { content_id: 'CNT-2026-09-10-001' } })], scripts: [{ id: 'IS-1', item_id: 'NR-1', job_id: 'JOB-1', title: 'ธง', script_md: written, content_id: 'CNT-2026-09-10-001' }] });
  assert.equal(rewriteStatus(item), '', 'ส่งเข้า Content Center แล้ว = ไม่ต้องมีบรรทัดสถานะ badge บนเวอร์ชันบอกอยู่แล้ว');

  const before = [{ id: 'IS-1', script_md: scaffold, content_id: null }, { id: 'IS-2', script_md: written, content_id: null }];
  assert.notEqual(scriptSignature(before), scriptSignature([{ id: 'IS-1', script_md: written, content_id: null }, before[1]]), 'บทถูกเขียนจริง = signature เปลี่ยน แม้จำนวนเวอร์ชันเท่าเดิม');
  announceScriptChanges(before, [{ id: 'IS-1', script_md: written, content_id: 'CNT-2026-09-10-001' }, { id: 'IS-2', script_md: written, content_id: null }]);
  assert.deepEqual(toasts, ['เกลาเสร็จ ✨ ส่งเข้า Content Center แล้ว — CNT-2026-09-10-001-RL']);
  __setStateForTest({ rwJobs: [job({ status: 'done', result: { handoff_error: 'x' } })] });
  announceScriptChanges([{ id: 'IS-3', job_id: 'JOB-1', script_md: scaffold, content_id: null }], [{ id: 'IS-3', job_id: 'JOB-1', script_md: written, content_id: null }]);
  assert.equal(toasts.at(-1), 'เกลาเสร็จแล้ว ✨ เวอร์ชันใหม่อยู่บนการ์ด (ส่งเข้า Content Center ไม่ผ่าน กด ⬆️ ส่งเองได้)');
  announceScriptChanges([{ id: 'IS-4', script_md: written, content_id: null }], [{ id: 'IS-4', script_md: written, content_id: null }]);
  assert.equal(toasts.length, 2, 'ไม่มีอะไรเปลี่ยน = ไม่เด้ง');
});
