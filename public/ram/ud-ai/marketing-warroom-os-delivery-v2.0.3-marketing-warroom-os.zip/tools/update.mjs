import { access, mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { assertInside, copyReplace, run } from './lib.mjs';
import { createSnapshot } from './snapshot.mjs';

const ENGINE_FOLDERS = ['app', 'brain', 'tools', '.claude', '.agents'];

export async function updateWorkspace({ rootDir = path.resolve(import.meta.dirname, '..'), sourceDir } = {}) {
  if (!sourceDir) throw new Error('ระบุโฟลเดอร์อัปเดต: node tools/update.mjs <update-folder>');
  const source = path.resolve(sourceDir);
  if (source === path.resolve(rootDir)) throw new Error('Update source must be a different folder');
  for (const folder of ENGINE_FOLDERS) await access(path.join(source, folder));
  const snapshot = await createSnapshot({ rootDir, label: 'before-update' });
  const backup = await mkdtemp(path.join(os.tmpdir(), 'workspace-engine-backup-'));
  try {
    for (const folder of ENGINE_FOLDERS) await copyReplace(path.join(rootDir, folder), path.join(backup, folder));
    for (const folder of ENGINE_FOLDERS) await copyReplace(path.join(source, folder), path.join(rootDir, folder));
    const golden = run(process.execPath, ['tools/golden-check.mjs'], { cwd: rootDir, allowFailure: true });
    if (golden.status !== 0 || golden.error) {
      for (const folder of ENGINE_FOLDERS) await copyReplace(path.join(backup, folder), path.join(rootDir, folder));
      throw new Error(`Golden check failed; engine folders rolled back. ${(golden.stderr || '').trim()}`);
    }
    return { ok: true, snapshot: snapshot.directory, updated: [...ENGINE_FOLDERS] };
  } catch (error) {
    if (!/rolled back/i.test(error.message)) {
      for (const folder of ENGINE_FOLDERS) {
        try { await access(path.join(backup, folder)); await copyReplace(path.join(backup, folder), path.join(rootDir, folder)); } catch {}
      }
    }
    throw error;
  } finally {
    await rm(backup, { recursive: true, force: true });
  }
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  const sourceDir = process.argv[2] ? assertInside(process.cwd(), process.argv[2], 'Update source') : undefined;
  const result = await updateWorkspace({ sourceDir });
  process.stdout.write(`✅ อัปเดต ${result.updated.join(', ')} แล้ว\n✅ Golden check ผ่าน\nSnapshot: ${result.snapshot}\n`);
}
