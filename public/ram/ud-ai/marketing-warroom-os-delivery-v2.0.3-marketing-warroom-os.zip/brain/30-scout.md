# Scout Worker

คำสั่ง `/scout` และ `/worker` ใช้ lifecycle เดียวกัน งานหนึ่งต้องจบเป็น `done`, `failed` หรือ `preflight_failed` ห้ามทิ้งไว้ที่ `running`

## Lifecycle

1. ดูคิวด้วย `node tools/worker-status.mjs`
2. รับงานเดียวด้วย `node tools/scout-job.mjs claim [job-id]` แล้วใช้ record ที่พิมพ์ออกมาเป็นขอบเขตงาน
3. รัน `node tools/scout-check.mjs <kind|auto> "<target>"` ก่อนเก็บหลักฐาน ยกเว้น `shot` และ `paste`
4. เขียนรายงานใน `wiki/intel/scout/` และเตรียม item JSON ไม่เกิน 1 MB ใต้ `output/scout-staging/`
5. จบงานด้วยคำสั่งใดคำสั่งหนึ่ง:
   - สำเร็จ: `node tools/scout-job.mjs complete <job-id> output/scout-staging/item.json`
   - ต้องขอหลักฐาน: `node tools/scout-job.mjs needs-evidence <job-id> output/scout-staging/request.json`

ไฟล์ request ต้องมี `reason`, `next_action` และ `source_url` เมื่อมีลิงก์อ้างอิง ไฟล์ complete ใส่ `item` และ `capability_mode`; media ที่เผยแพร่ต้องอยู่ใต้ `data/files/newsroom/` เท่านั้น

## Duplicate Check

| kind | เคยสืบแล้ว | วิธีทำ |
|---|---|---|
| `clip` | ไม่ทำซ้ำ | จบเป็น `failed` พร้อมข้อความจาก `scout-check`; ยกเว้น note มี `intel:` หรือผู้ใช้ระบุ `--force` |
| `page` `web` `ads` | ทำต่อ | เพิ่มหัวข้อ `## ส่วนต่างจากรอบก่อน` พร้อมตัวเลข ราคา หรือสิ่งที่เพิ่ม/หาย |
| `shot` `paste` | ไม่เช็ค | ประมวลผลหลักฐานที่ผู้ใช้ให้โดยตรง |

## Capability Matrix

| Source | ทำได้เมื่อ | ขั้นตอนที่ต้องทำ | ถ้าทำไม่ได้ |
|---|---|---|---|
| Public web | URL เป็น HTTP(S) สาธารณะและ robots อนุญาต | ตรวจ robots, เก็บ title, summary, เวลา และ evidence links; ห้ามเข้าถึง private host | `needs-evidence` พร้อมบอกหน้าหรือไฟล์ที่ต้องส่ง |
| Public clip/page | มี web/media tool ที่ได้รับอนุญาต หรือมีไฟล์ที่ผู้ใช้มีสิทธิ์ใช้ | ใช้ tool แบบ read-only; ถ้ามี `yt-dlp`, `ffmpeg` หรือ transcription tool ในเครื่องจึงใช้กับแหล่งที่อนุญาต | ขอ exported file หรือ transcript ด้วย `needs-evidence` |
| Workspace image/video | เป็น relative path ที่ classifier อนุมัติ | ตรวจเฉพาะไฟล์นั้น; สำเนา/สร้าง artifact ปลายทางใต้ `data/files/newsroom/` | ปฏิเสธ absolute path, traversal, symlink escape และไฟล์เกินขนาด |
| Meta Ads | มี connector ที่เปิด `ads_library_search` | เรียกเฉพาะ `ads_library_search` แบบ read-only; ห้ามเปิด snapshot link และห้าม browser automation บน Meta | ถ้าไม่มี connector ให้ `needs-evidence`; ห้ามรายงานว่าสืบ Ads สำเร็จ |
| Meta creative media | connector ส่ง bytes หรือ safe direct media URL | เก็บ media ที่ตรวจได้ใต้ `data/files/newsroom/` | ถ้าไม่มี media ให้ `needs-evidence` พร้อม snapshot link เดิมและระบุ screenshot/video ที่ต้องการ |
| Pasted evidence | ผู้ใช้ส่งข้อความใน job | วิเคราะห์เฉพาะข้อความนั้นและบอกข้อจำกัด | อย่าเติมข้อเท็จจริงที่ไม่ได้อยู่ในหลักฐาน |

URL `http://127.0.0.1:4173/demo/<slug>` เป็น fixture ที่มากับระบบและใช้ได้เฉพาะ Demo mode; ไม่ใช่สิทธิ์ให้เปิด private URL อื่น

## Report Contract

รายงานต้องมี source, เวลาเก็บ, media ที่มีจริง, transcript หรือ visible copy, findings, reusable structure, verdict, score และ limits ทุกข้ออ้างต้องย้อนกลับไปยังหลักฐานได้

สำหรับคลิป ให้ถอดบทพูดบรรทัดละช่วงเป็น `[m:ss] ข้อความ` และใส่ `ตัวอย่างที่เอาไปใช้ได้: …` หนึ่งบรรทัด ปุ่มเกลาใช้สองส่วนนี้ คัดลอกได้เฉพาะ structure/pattern ห้ามคัดคำของเจ้าของผลงาน

ช่องทางใหม่เขียนลง `handle_suggestions` เท่านั้น ห้ามเพิ่มเข้า `handles` เอง ห้ามโพสต์ ส่งข้อความ หรือล็อกอินแทนผู้ใช้
