import { chmod, readFile, stat, writeFile } from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

import { findSimilar } from './lib/similar.mjs';
import { createStore, TABLES } from './store.mjs';
import { getWorkspaceIdentity } from '../tools/delivery-state.mjs';

const CSP = "default-src 'self'; script-src 'self'; style-src 'self'; font-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'";
const VIEWS = Object.freeze({
  '/': 'shell.html', '/news-desk': 'news-desk.html', '/content': 'content.html', '/intel': 'intel.html',
  '/jobs': 'jobs.html', '/settings': 'settings.html', '/card': 'card.html'
});
const DEMO_PAGES = Object.freeze({
  '/demo/example-brand': 'example-brand.html',
  '/demo/north-star-lab': 'north-star-lab.html',
  '/demo/field-notes-studio': 'field-notes-studio.html'
});
const COMPANY_FILES = new Set(['business.md', 'persona.md', 'offer.md', 'voice.md', 'niche-criteria.md', 'RULES.md', 'pre-work.md', 'config.json']);
const TYPES = Object.freeze({ '.css': 'text/css; charset=utf-8', '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.md': 'text/markdown; charset=utf-8', '.woff2': 'font/woff2', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp' });

function headers(type) {
  return { 'content-type': type, 'content-security-policy': CSP, 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer', 'cache-control': 'no-store' };
}

function result(status, body = '', type = 'text/plain; charset=utf-8') { return { status, headers: headers(type), body }; }
function json(status, body) { return result(status, `${JSON.stringify(body)}\n`, 'application/json; charset=utf-8'); }

function requestError(message, status) {
  const error = new Error(message);
  error.status = status;
  return error;
}

function enforceLocalRequest(requestHeaders, method) {
  const host = String(requestHeaders.host || '').toLowerCase();
  if (host && host !== '127.0.0.1:4173' && host !== 'localhost:4173') throw requestError('Forbidden Host', 403);
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) return;
  const origin = String(requestHeaders.origin || '');
  if (!origin) return;
  let parsed;
  try { parsed = new URL(origin); } catch { throw requestError('Forbidden Origin', 403); }
  if (parsed.protocol !== 'http:' || !host || parsed.host.toLowerCase() !== host) throw requestError('Forbidden Origin', 403);
}

function inside(root, target) {
  const base = path.resolve(root);
  const resolved = path.resolve(target);
  return resolved === base || resolved.startsWith(`${base}${path.sep}`);
}

async function fileResult(target, root) {
  if (!inside(root, target)) return result(404, 'Not found');
  try {
    const info = await stat(target);
    if (!info.isFile()) return result(404, 'Not found');
    return result(200, await readFile(target), TYPES[path.extname(target).toLowerCase()] || 'application/octet-stream');
  } catch (error) {
    return result(error.code === 'ENOENT' ? 404 : 500, error.code === 'ENOENT' ? 'Not found' : 'Unable to read local file');
  }
}

function requireJson(headersValue, body) {
  if (!String(headersValue['content-type'] || '').toLowerCase().startsWith('application/json')) {
    const error = new Error('Content-Type must be application/json');
    error.status = 415;
    throw error;
  }
  if (Buffer.byteLength(body) > 1_000_000) throw new Error('Request body exceeds 1 MB');
  return JSON.parse(body || '{}');
}

export function createRequestDispatcher({ rootDir = path.resolve(import.meta.dirname, '..') } = {}) {
  const store = createStore({ rootDir });
  const viewsRoot = path.join(rootDir, 'app/views');
  const assetsRoot = path.join(rootDir, 'app/assets');
  const filesRoot = path.join(rootDir, 'data/files');

  return async function dispatch({ method = 'GET', url: requestUrl = '/', headers: requestHeaders = {}, body = '' }) {
    try {
      enforceLocalRequest(requestHeaders, method);
      const url = new URL(requestUrl, 'http://127.0.0.1');
      if (url.pathname === '/api/meta' && method === 'GET') {
        const brand = JSON.parse(await readFile(path.join(rootDir, 'app/brand.json'), 'utf8'));
        const config = JSON.parse(await readFile(path.join(rootDir, 'company/config.json'), 'utf8'));
        const newsDailyLastRun = await readFile(path.join(rootDir, 'data/.news-daily-run.json'), 'utf8').then(JSON.parse).catch(() => null);
        return json(200, { ...brand, companyName: config.company_name, sceneCardEnabled: Boolean(config.kie_api_key), newsDailyLastRun, workspace_identity: getWorkspaceIdentity(rootDir) });
      }
      if (url.pathname === '/api/similar' && method === 'POST') {
        const payload = requireJson(requestHeaders, body);
        return json(200, { items: findSimilar(payload.query || '', payload.items || [], Number(payload.threshold ?? 0.22)) });
      }
      if (url.pathname === '/api/similar' && method === 'GET') {
        const ideas = await store.read('content_items');
        return json(200, { items: findSimilar(url.searchParams.get('q') || '', ideas.items, Number(url.searchParams.get('threshold') || 0.22)) });
      }
      if (url.pathname === '/api/write-md' && method === 'POST') {
        const payload = requireJson(requestHeaders, body);
        return json(200, { path: await store.writeMarkdown(payload.path, payload.content) });
      }
      const companyMatch = url.pathname.match(/^\/api\/company\/([^/]+)$/);
      if (companyMatch && !COMPANY_FILES.has(companyMatch[1])) return result(404, 'Not found');
      if (companyMatch && COMPANY_FILES.has(companyMatch[1])) {
        const target = path.join(rootDir, 'company', companyMatch[1]);
        if (method === 'GET') return fileResult(target, path.join(rootDir, 'company'));
        if (method === 'PUT' || method === 'POST') {
          if (Buffer.byteLength(body) > 1_000_000) throw new Error('Request body exceeds 1 MB');
          const type = String(requestHeaders['content-type'] || '').toLowerCase().split(';')[0].trim();
          const allowed = companyMatch[1] === 'config.json' ? ['application/json'] : ['text/markdown', 'text/plain'];
          if (!allowed.includes(type)) return json(415, { error: 'Unsupported Content-Type' });
          if (companyMatch[1] === 'config.json') JSON.parse(body);
          await writeFile(target, `${body.replace(/\n$/, '')}\n`, { mode: 0o600 });
          await chmod(target, 0o600);
          return json(200, { file: companyMatch[1] });
        }
        return json(405, { error: 'Method not allowed' });
      }
      const tableMatch = url.pathname.match(/^\/api\/([a-z_]+)(?:\/([^/]+))?$/);
      if (tableMatch && TABLES.includes(tableMatch[1])) {
        const table = tableMatch[1];
        const id = tableMatch[2] ? decodeURIComponent(tableMatch[2]) : null;
        if (method === 'GET' && !id) return json(200, await store.query(table, Object.fromEntries(url.searchParams)));
        if (method === 'POST' && !id) return json(201, await store.create(table, requireJson(requestHeaders, body)).then((data) => data.items.at(-1)));
        if (method === 'PUT' && id) return json(200, await store.update(table, id, requireJson(requestHeaders, body)));
        if (method === 'PATCH' && id) return json(200, await store.patch(table, id, requireJson(requestHeaders, body)));
        if (method === 'DELETE' && id) return (await store.remove(table, id)) ? result(204) : json(404, { error: 'Record not found' });
        return json(405, { error: 'Method not allowed' });
      }
      if (method !== 'GET' && method !== 'HEAD') return result(405, 'Method not allowed');
      if (Object.hasOwn(DEMO_PAGES, url.pathname)) return fileResult(path.join(rootDir, 'examples/web', DEMO_PAGES[url.pathname]), path.join(rootDir, 'examples/web'));
      if (Object.hasOwn(VIEWS, url.pathname)) {
        const page = await fileResult(path.join(viewsRoot, VIEWS[url.pathname]), viewsRoot);
        if (page.status === 200) {
          const brand = JSON.parse(await readFile(path.join(rootDir, 'app/brand.json'), 'utf8'));
          page.body = page.body.toString('utf8').replaceAll('{{PRODUCT_NAME}}', brand.productName).replaceAll('{{PRODUCT_TAGLINE}}', brand.productTagline);
        }
        return page;
      }
      if (url.pathname.startsWith('/assets/')) return fileResult(path.join(assetsRoot, decodeURIComponent(url.pathname.slice(8))), assetsRoot);
      if (url.pathname.startsWith('/files/')) return fileResult(path.join(filesRoot, decodeURIComponent(url.pathname.slice(7))), filesRoot);
      return result(404, 'Not found');
    } catch (error) {
      const input = error.status || error instanceof SyntaxError || /schema|outside|exceeds|duplicate|cannot change|not found/i.test(error.message);
      return json(error.status || (input ? 400 : 500), { error: error.message || 'Unexpected error' });
    }
  };
}

async function readRequestBody(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 1_000_000) throw new Error('Request body exceeds 1 MB');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf8');
}

export function createAppServer({ rootDir = path.resolve(import.meta.dirname, '..') } = {}) {
  const dispatch = createRequestDispatcher({ rootDir });
  return http.createServer(async (request, response) => {
    const body = ['POST', 'PUT', 'PATCH'].includes(request.method) ? await readRequestBody(request).catch((error) => ({ error })) : '';
    const output = body?.error ? json(400, { error: body.error.message }) : await dispatch({ method: request.method, url: request.url, headers: request.headers, body });
    response.writeHead(output.status, output.headers);
    response.end(request.method === 'HEAD' ? undefined : output.body);
  });
}

const isMain = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  const server = createAppServer();
  server.listen(4173, '127.0.0.1', () => process.stdout.write('Workspace running at http://127.0.0.1:4173\n'));
}
