# Classroom runbook

## ก่อนวันสอน

1. รับ Pre-work และให้ลูกค้ายืนยัน Company Context
2. รัน Clientize → Install → Company Doctor และต้องเห็น `Source health: PASS` จากการยิง feed จริง ห้ามถือว่า URL ขึ้นต้นด้วย HTTPS แล้วพร้อม
3. แตก Client Edition ZIP ในโฟลเดอร์ใหม่ แล้วทดสอบ one-command onboarding บน OS และ agent แบบเดียวกับห้องจริง
4. เก็บ ZIP กับ checksum ไว้ 3 จุด: เครื่องสอน, USB และ cloud link ที่เปิดได้โดยไม่ขอสิทธิ์เพิ่ม
5. เตรียม hotspot และไฟล์ติดตั้ง Node.js 20+ จาก nodejs.org (ตัว LTS แบบ `.pkg` และ `.msi`) ใส่ USB ไปด้วย ให้ผู้เรียนติดตั้งจากไฟล์นี้ ไม่ต้องใช้ Homebrew หรือ nvm
6. บนเครื่อง macOS ของผู้เรียน เปิด `Open Workspace.command` หนึ่งครั้งแบบคลิกขวา → Open เพื่อผ่าน Gatekeeper ก่อนเริ่มคลาส

## เวลา 30 นาทีก่อนเริ่ม

- เปิดเครื่องสอนจาก ZIP ที่แตกใหม่
- รัน `node tools/doctor.mjs --company`
- ยืนยันว่า `Source health` ผ่านทุก feed และมีรายการข่าวอย่างน้อยหนึ่งรายการต่อ feed
- เช็ค `DELIVERY-STATUS.json` เป็น `READY`
- เปิดระบบและเดินทุกห้องหนึ่งรอบ
- ปิด Demo session ที่ค้างอยู่ก่อนรับผู้เรียน

## ลำดับในห้อง

| ช่วง | ผู้เรียนทำ | หลักฐานว่าผ่าน |
|---|---|---|
| Setup | เปิดโฟลเดอร์ใน agent และส่ง one-command prompt | `READY`, Golden 26/26 |
| Demo | `/demo start` | มี `before-demo-*` และข้อมูลครบ 3 ห้อง |
| News | ส่ง `/news-daily` แล้วคัดข่าวหนึ่งเรื่อง | Demo fixture ถูกอ่านเอง ข่าวใหม่เข้า News Desk และ Candidate อยู่ใน News Desk |
| Content | ทำ variant หนึ่งชิ้น | ไฟล์อยู่ใน `output/content/` |
| Intel public fixture | กด `สืบ URL / ไฟล์`, วาง `https://example.com` และส่งให้ Agent | Queue ตรวจเป็น public web โดยผู้เรียนไม่ต้องเลือก lane |
| Evidence fallback | สร้าง Scout job ที่ agent เข้า media ไม่ได้ แล้วให้ `/worker` จบเป็น `ต้องส่งหลักฐานเพิ่ม`; คัดลอกทางต่อและส่ง pasted evidence ที่ยาวอย่างน้อย 80 ตัวอักษรกลับเข้า dialog | Queue มี `reason`, `next_action` และงานหลักฐานชิ้นใหม่ โดยไม่เปิด Meta snapshot |
| Worker | ส่ง `/worker` หลังสร้างงาน | งานถูก claim หนึ่งครั้งและจบเป็น `done`, `failed` หรือ `preflight_failed` |
| Return | `/demo stop` | Company name และ sources กลับชุดจริง |
| First work | ทำงานบริษัทหนึ่งชิ้น | Owner/Reviewer ตรวจได้ |
| Handover | `/snapshot handover` | มี manifest และ checksum |

## ทางหนีทีไล่

- Internet ช้า: ใช้ Demo mode ได้ต่อโดยไม่เปลี่ยนคำสั่ง ทั้ง News และ Intel ใช้ fixture local ที่ `/demo start` เตรียมให้
- Public fixture เข้าไม่ได้: ใช้ local Demo evidence ต่อ แล้วซ้อม evidence fallback ด้วย pasted evidence; ห้ามเปลี่ยนไปเปิด Meta ผ่าน browser automation
- Agent login ไม่ผ่าน: ให้ผู้เรียนจับคู่กับเครื่องที่ login แล้ว ห้ามใช้บัญชีส่วนตัวแทนบัญชีบริษัทเพื่อใส่งานจริง
- Port 4173 ชน: รัน `/doctor` ถ้าเป็น workspace เดิมที่ยังเปิดอยู่ ให้ใช้หน้าต่างเดิมต่อ ถ้าเป็นโปรแกรมอื่น ให้หาด้วย `lsof -nP -iTCP:4173 -sTCP:LISTEN` (macOS) หรือ `netstat -ano | findstr :4173` (Windows) แล้วปิดโปรแกรมนั้น ห้ามเปลี่ยน port สดกลางคลาส
- ดับเบิลคลิกตัวเปิดแล้วหน้าต่างเด้งปิด: เครื่องนั้นยังไม่มี Node.js ให้ติดตั้งจากไฟล์ใน USB แล้วเปิดใหม่ (ตั้งแต่ 2.0.1 ตัวเปิดจะค้างหน้าต่างไว้พร้อมข้อความแทนการปิดเงียบ)
- ผู้เรียนเผลอปิดหน้าต่างดำระหว่างเรียน: เว็บจะดับ ให้ดับเบิลคลิกตัวเปิดใหม่ งานที่บันทึกแล้วไม่หาย
- ข้อมูลพัง: รัน `node tools/reset.mjs --starter` แล้วตรวจ Company Doctor
- เครื่องหนึ่งเปิดไม่ได้: ใช้เครื่องสอนสาธิตต่อ ผู้เรียนรับ ZIP และนัด setup support ตามขอบเขตส่งมอบ

## ก่อนปล่อยผู้เรียนกลับ

ทุกเครื่องต้องผ่าน Company Doctor, ไม่มี Demo session ค้าง, มีงานจริงชุดแรก, มี handover snapshot และผู้เรียนเปิดระบบรอบถัดไปเองได้หนึ่งครั้ง

ระบบ local-first ไม่ได้แปลว่า AI ทำงานแบบ offline: หน้าเว็บ ข้อมูล Demo และ recovery อยู่บนเครื่อง แต่การให้ Claude Code หรือ Codex เขียน/วิเคราะห์ต้อง login และมีอินเทอร์เน็ต รายละเอียดครบอยู่ใน `LOCAL-FEATURE-MATRIX.md`
