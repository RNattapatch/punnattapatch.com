# Local feature matrix

เอกสารนี้บอกตรงๆ ว่าส่วนใดอยู่บนเครื่อง ส่วนใดใช้อินเทอร์เน็ต และ Claude Code หรือ Codex รับงานจากระบบอย่างไร

| Capability | เก็บและรันที่ไหน | ต้องใช้อินเทอร์เน็ต | สถานะในรุ่นนี้ |
|---|---|---:|---|
| หน้า News Desk, Content Center, Intel Warroom และ Settings | `127.0.0.1:4173` บนเครื่องผู้เรียน | ไม่ต้อง | พร้อมใช้ |
| Product-only white UI และ responsive notebook tabs | Browser ในเครื่องผู้เรียน | ไม่ต้อง | พร้อมใช้ |
| Company Context, การ์ด, คิว, รายงาน และบท | ไฟล์ JSON/Markdown ใน workspace | ไม่ต้อง | พร้อมใช้ |
| Demo, snapshot, restore, reset และ checksum | บนเครื่องผู้เรียน | ไม่ต้อง | พร้อมใช้ |
| Demo News และ Demo Intel | fixture ที่แถมใน ZIP วันที่ถูกสร้างใหม่ตอนเริ่ม Demo | ไม่ต้อง | พร้อมใช้ |
| ดึง RSS ของบริษัท | เครื่องมือ local เป็นคนดึง แต่ปลายทางคือเว็บข่าว | ต้อง | พร้อมใช้เมื่อ feed ตอบและเป็น RSS/Atom |
| สืบเว็บสาธารณะ | Agent อ่าน URL ที่ผ่าน public-host check และเขียนหลักฐานกลับเครื่อง | ต้อง | พร้อมใช้เมื่อ robots และเว็บอนุญาต |
| สืบ public clip/page | Agent ใช้ web/media tool ที่บัญชีอนุญาต; ใช้ `yt-dlp`/FFmpeg/transcription เมื่อมีและมีสิทธิ์ | ต้อง | ขอ exported file หรือ transcript เมื่อ tool เข้าไม่ถึง |
| สืบ workspace image/video | Agent อ่าน relative path ที่ระบบอนุมัติ | ไม่ต้อง | พร้อมใช้; media ปลายทางอยู่ใต้ `data/files/newsroom/` |
| สืบ Meta Ads | Connector `ads_library_search` แบบ read-only | ต้องและต้องมี connector | ห้ามเปิด snapshot และห้าม browser automation; ไม่มี connector ต้องขอหลักฐาน |
| Creative media ของ Meta Ads | Bytes หรือ safe direct media URL จาก connector | ต้อง | ถ้าไม่มี ให้ผู้ใช้แนบ screenshot/video |
| เขียน/เกลาบทด้วย AI | Claude Code หรือ Codex ในบัญชีบริษัท | ต้อง | พร้อมใช้แบบ on-demand |
| ประมวลคิวรวม | ส่ง `/worker` ให้ agent ที่เปิด workspace | ต้องสำหรับ AI | พร้อมใช้แบบหนึ่งรอบต่อคำสั่ง |
| การ์ดตัวอักษร | Render บนเครื่อง | ไม่ต้อง | พร้อมใช้ |
| การ์ดซีน AI | kie.ai | ต้องและใช้เครดิต | ของเสริม |
| โพสต์ Social | ผู้ใช้คัดลอกแล้วโพสต์เอง | แล้วแต่แพลตฟอร์ม | ไม่ทำอัตโนมัติ |
| Shared database, multi-user sync, cron และ worker 24 ชั่วโมง | ไม่มีใน Client Edition | — | อยู่นอกขอบเขต |

## Agent worker contract

Claude Code และ Codex ใช้ skill tree ที่ติดมากับ ZIP คนละสำเนาแต่เนื้อหาเดียวกัน ผู้เรียนเปิดโฟลเดอร์ใน agent แล้วเรียก `/news-daily`, `/scout`, `/jobs` หรือ `/worker` ได้เลย Agent อ่าน Company Context ทำงาน และเขียนผลกลับ workspace โดยไม่ต้องให้ผู้เรียนเขียนโค้ด

`/worker` เป็น on-demand worker: ผู้เรียนสั่งหนึ่งครั้ง Agent รับงานด้วย `claim` แล้วจบเป็น `done`, `failed` หรือ `preflight_failed` ก่อนหยุด งานที่ขาดหลักฐานต้องบอกเหตุผลและทางต่อ รุ่นนี้ไม่เปิด process เบื้องหลังและไม่เรียก CLI ของ AI ซ้อน เพราะแต่ละบริษัทต้องใช้บัญชี สิทธิ์ และค่าใช้จ่ายของตัวเอง

## Classroom dependency

เส้นทาง Demo ทั้งสามห้องใช้ fixture local ได้ แม้อินเทอร์เน็ตเข้าเว็บข่าวหรือเว็บคู่แข่งไม่ได้ แต่ขั้นที่ให้ AI เขียนบทหรือวิเคราะห์ยังต้องให้ Claude Code หรือ Codex login อยู่และเชื่อมต่อบริการ AI ได้
