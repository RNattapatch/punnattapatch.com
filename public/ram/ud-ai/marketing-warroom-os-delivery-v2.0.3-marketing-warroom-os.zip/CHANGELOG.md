# Changelog

## Delivery V2 2.0.3 — 2026-09-14

- หน้าแรกคงตำแหน่งบนสุดเมื่อระบบย้าย focus เข้าเนื้อหา จึงไม่ถูก sticky header บังบนมือถือ และไม่มีกรอบ focus ล้อมทั้ง workspace
- Content Center เรียงทั้ง 6 stage ไว้ในแถวเดียวและเลื่อนแนวนอนภายในบอร์ดแบบ Trello; `📊 วิเคราะห์แล้ว` ไม่ตกลงแถวใหม่เมื่อพื้นที่หน้าจอแคบ

รุ่นนี้ย้ายหน้าหลักให้ใช้ visual hierarchy แบบ production และทำ Scout ให้รับหลักฐานหนึ่งแหล่งแล้วส่งต่อ Claude Code หรือ Codex ได้โดยผู้ใช้ไม่ต้องเลือก lane เอง

### UI ตาม production

- ทุกห้องใช้ product-only chrome ชุดเดียวกัน: พื้นขาว, navy/coral, notebook tabs และ borders-only cards ไม่มี tagline หรือ theme switch ในแถบหลัก
- Content Center มี Board/List/Queue, status strip และ quick capture; News Desk คงสี่ work modes ในคอลัมน์อ่านงานเดียว
- Intel คง Targets/Library/Queue, roster, dossier, timeline, gallery, retry และ rewrite พร้อมเพิ่ม evidence tray กับ queue state ที่บอกทางต่อ

### Scout และ worker

- ปุ่ม `สืบ URL / ไฟล์` และ `+ สืบคอนเทนต์รายชิ้น` เปิด dialog เดียวกัน ระบบตรวจ URL, workspace image/video, pasted evidence และ advertiser query โดยไม่ให้ server fetch URL
- `/worker` ใช้ lifecycle `claim` → `complete` หรือ `needs-evidence` งานที่ต้องให้ผู้ใช้ส่งไฟล์เพิ่มจบเป็น `preflight_failed` พร้อมเหตุผลและทางต่อที่คัดลอกได้
- Public web/media ใช้ได้เมื่อแหล่งอนุญาตและ agent มี tool ที่เหมาะสม ถ้าขาดไฟล์หรือ transcript ระบบขอหลักฐานตรงๆ
- Meta Ads ใช้ `ads_library_search` แบบ read-only เมื่อ connector เปิดให้เท่านั้น ห้าม browser automation และห้ามเปิด ad snapshot; ถ้า connector ไม่มี creative media ต้องขอ screenshot/video จากผู้ใช้
- staging JSON ถูกจำกัดใต้ `output/scout-staging/`; media ที่เผยแพร่ถูกจำกัดใต้ `data/files/newsroom/` พร้อมตรวจ path, existence และขนาด

### Delivery gate

- VERSION เปลี่ยนหลัง focused Tasks 1–5 ผ่าน 25/25 เท่านั้น
- หน้าแจกมีสามขั้น: ดาวน์โหลด, เปิดใน agent และตรวจ READY/Golden 26/26
- Producer ปฏิเสธ write target ที่มี `v2.0.2` เมื่อแพ็ก 2.0.3

## Delivery V2 2.0.2 — 2026-09-13

รุ่นพร้อมสอนและส่งลูกค้าที่ปิดช่องว่างจาก clean-room classroom rehearsal โดยไม่แก้ทับ ZIP 2.0.0 หรือ 2.0.1

### Demo สามห้องเดินได้โดยไม่พึ่งเว็บภายนอก

- `/demo start` เลื่อนวันที่ข้อมูลสมมติให้สดตามวันเริ่มรอบ สร้าง RSS local ใต้ `output/demo/rss/` และแถมไฟล์บทที่การ์ด Content อ้างถึงจริง
- `/news-daily` ตรวจพบ Demo source และอ่าน fixture ที่ปลอดภัยเอง จึงได้ข่าวใหม่ 3 ชิ้นโดยไม่ต้องให้ผู้เรียนรู้จัก `--fixtures`
- Intel targets ใน Demo ชี้ไปหน้า evidence local ที่ server ให้เฉพาะ allowlist ใต้ `/demo/<slug>` แทนโดเมนที่ resolve ไม่ได้
- ผลรอบ News ล่าสุดบันทึกใน `data/.news-daily-run.json` และแสดงบนหน้า News Desk

### Delivery และ preflight ที่บอกความจริง

- Company Doctor ยิง active RSS/Atom ทุกแหล่งและ parse รายการจริง; feed ตายหรือไม่ใช่ feed จะเป็น `Source health: FAIL`
- เพิ่ม `LOCAL-FEATURE-MATRIX.md` แยกสิ่งที่ทำ local/offline, สิ่งที่ใช้อินเทอร์เน็ต และสิ่งที่อยู่นอก Client Edition
- เพิ่ม `/worker` สำหรับให้ Claude Code หรือ Codex ประมวลคิว Content + Intel หนึ่งรอบแบบ on-demand โดยไม่เรียก AI CLI ซ้อนและไม่เปิด daemon
- Producer สร้างหน้าแจก static HTML และไฟล์ SHA-256 ข้าง ZIP หน้าเดียวมีปุ่มดาวน์โหลด prompt ติดตั้ง และวิธีตรวจ checksum

### Gate

- Source tests 114 รายการ; extracted package tests 104 รายการ
- Golden 26/26 และ parity manifest 514/514
- Demo News ยืนยัน `fetched: 3`, `inserted: 3`, `briefs: 3`, error 0 บนวันที่จำลองในอนาคต
- RSS transport ตัดการตอบกลับที่เกิน 5 MB เพื่อไม่ให้ feed ผิดปกติใช้หน่วยความจำได้ไม่จำกัด

## Delivery V2 2.0.1 — 2026-09-12

ปิดช่องที่ audit ก่อนส่งมอบจับได้ 3 จุด ทั้งหมดเป็นเรื่องทางเดินของคน ไม่ใช่ฟีเจอร์ใหม่ ไม่มีการเปลี่ยนพฤติกรรมของสามห้อง

### แก้ — ตัวเปิด workspace ล้มแบบเงียบเมื่อเครื่องไม่มี Node.js

- `Open Workspace.command` เปลี่ยนเป็น login shell (`#!/bin/zsh -l`) จึงเห็น PATH ชุดเดียวกับตอนเปิด Terminal เอง เดิมเป็น non-login shell ที่ไม่มี `/opt/homebrew/bin` ทำให้เครื่อง Apple Silicon ที่ลง Node ผ่าน Homebrew หรือ nvm ขึ้น `command not found` แล้วหน้าต่างปิดทิ้งโดยไม่มีข้อความ
- หา Node จาก Homebrew, nvm, Volta และ `/usr/local/bin` เป็นทางสำรอง พร้อมตรวจว่าเป็นเวอร์ชัน 20 ขึ้นไป
- ทุกทางออกจบด้วยข้อความไทยบอกสาเหตุและวิธีแก้ แล้วรอกด Enter ก่อนปิด (เลิกใช้ `exec` ที่ทำให้ไม่มีอะไรทำงานต่อได้)
- `Open Workspace.bat` เช็ค `where node` ก่อน มี `pause` ทุกเส้นทาง ตั้ง `chcp 65001` ให้ข้อความไทยอ่านออก และบันทึกเป็น CRLF เพราะ cmd.exe เลื่อน `goto` ตามตำแหน่ง byte
- เพิ่มวิธีผ่าน Gatekeeper ครั้งแรก (คลิกขวา → Open) และกฎ "ห้ามปิดหน้าต่างดำระหว่างใช้งาน" ลงใน `เริ่มตรงนี้.md` กับ `CLASSROOM-RUNBOOK.md`
- `tools/launcher-scripts.test.mjs` บังคับทั้งหมดนี้ รวมถึง execute bit ของ `.command` ที่ต้องติดมากับ ZIP

### แก้ — Producer แพ็ก Client Edition ทับ Facilitator Master ได้

- ใส่ `--context` แต่ลืม `--output-dir` เดิมจะเขียนลง `dist/` ของ Master ด้วยชื่อไฟล์เดียวกันเป๊ะ ตอนนี้ CLI ปฏิเสธทันทีและบอกว่าต้องใส่ `--output-dir`
- `packageDelivery` ปฏิเสธซ้ำอีกชั้นถ้า output ชี้ไปที่ `dist/` ของ Master แม้สั่งมาตรงๆ
- Client Edition เปลี่ยนชื่อเป็น `marketing-warroom-os-delivery-v<version>-<client-slug>.zip` ชื่อบริษัทที่เป็นภาษาไทยล้วนจะได้ slug จาก hash ที่ไม่ชนกัน
- แฟล็กที่ไม่มีค่าตามหลัง (`--context` ตัวสุดท้าย) เดิมเงียบแล้วสร้าง Master ตอนนี้ปฏิเสธ

### แก้ — `/install` สั่งเปิดระบบด้วยคำสั่งที่ agent ฆ่าตัวเอง

- เพิ่ม `node tools/launch.mjs --detach` ที่ยก server ไปไว้ใน process เบื้องหลัง แล้ว return ทันทีที่พอร์ตตอบ พร้อมรายงาน pid
- เดิม skill สั่ง `node tools/launch.mjs` แบบ foreground ซึ่งค้างจน Ctrl+C พอ Claude Code หรือ Codex timeout ตัด tool call มันจะพา server ที่เพิ่งเปิดตายไปด้วย
- ถ้าพอร์ตไม่ตอบใน 20 วินาที รายงานว่าเปิดไม่สำเร็จพร้อมคำสั่ง doctor แทนการบอกว่าสำเร็จ
- ตัว double-click ยังเป็น foreground เหมือนเดิม เพราะหน้าต่างคือที่จอดของ server

## Delivery V2 2.0.0 — 2026-09-12

รุ่นส่งมอบลูกค้าที่ต่อยอดจาก Marketing Warroom OS 2.2.0 โดยคงสามห้องเดิม และเพิ่มวงจรใช้งานจริง: Clientization, Doctor แยก Preflight/Company/Demo, Snapshot/Restore ที่ตรวจ checksum, Demo isolation, one-command install, launcher กลาง, security boundary และ packaging gate สำหรับ Client Edition

ต้นฉบับ `starter-workspace/marketing-warroom-os/` และ ZIP 2.2.0 ไม่ถูกแก้ไข รุ่นนี้อยู่ใน sibling directory แยกต่างหาก

## 2.2.0 — 2026-09-10

ตามระบบ production ที่เจ้าของผลิตภัณฑ์ใช้จริง (อัปเดต 8 ก.ย. 2569 รอบเย็น) ให้ทัน 2 เรื่อง และเก็บบทเรียนจากระบบต้นทาง 1 เรื่อง

### เปลี่ยน — บทที่เกลาเสร็จเข้า Content Center ให้เอง (Intel Warroom)

- เดิมผู้ใช้ต้องกด `⬆️ ส่งเข้า Content Center` เอง ตอนนี้ `/jobs` ส่งให้ทันทีหลัง agent เขียนบทเสร็จ ผ่าน `node tools/jobs/handoff-script.mjs <script-id>` (ไอเดียชื่อ = ธง · variant RL ที่มีบทอยู่ในช่อง AI · ร่างของผู้ใช้ว่างเสมอ)
- โครงเปล่าไม่หลุดเข้า Content Center — tool ปฏิเสธจนกว่า `script_md` จะครบสามชั้น · ส่งซ้ำไม่สร้างไอเดียซ้ำ
- ผลลัพธ์ (`content_id` หรือ `handoff_error`) บันทึกลง `wr_jobs.result` ของงานนั้น หน้าเว็บจึงบอกได้ว่าส่งผ่านหรือไม่ผ่านโดยไม่ต้องเดา · ส่งไม่ผ่านบทยังอยู่บนการ์ด และปุ่ม `⬆️` ยังส่งมือได้
- การ์ดคลิปมีบรรทัดสถานะใต้หัวข้อ `✍️ บทเวอร์ชันของเรา`: รอ agent (บอกว่าส่งเมื่อ m:ss) → AI กำลังเกลา (m:ss · ปกติ 5-10 นาที) → agent กำลังเขียน → เสร็จ · พังบอกเหตุผล · toast `เกลาเสร็จ ✨ ส่งเข้า Content Center แล้ว — CNT-…-RL` เด้งเองเมื่อบทเข้า Content Center (หน้าเว็บ poll 5 วิ)
- `brain/41-reel-rewrite.md` เพิ่มหัวข้อ `# 🧬 โครงที่ยืมมา` ท้ายบท ให้ผู้ใช้ตรวจได้ว่ายืมโครง ไม่ได้ลอกคำ

### เพิ่ม — เช็คซ้ำก่อนสืบ (Intel Warroom · `/scout`)

- `node tools/scout-check.mjs <kind|auto> "<target>"` บอกว่า target นี้เคยสืบแล้วไหม (วัน · การ์ดเดิม · รายงาน) โดยดูจากคลังและงานที่จบแล้ว — ลิงก์คนละรูปแบบแต่ของเดียวกัน (มี/ไม่มี `www` · `utm`/`fbclid`/`igsh` · `@handle` กับลิงก์ช่อง) นับเป็นตัวเดียวกัน
- กติกาใน `brain/30-scout.md`: คลิปที่เคยแกะแล้วไม่ทำซ้ำ (ยกเว้น note มี `--force` หรือมาจากแฟ้ม `intel:`) ส่วน page/web/ads/post ทำต่อแล้วเขียน `## ส่วนต่างจากรอบก่อน` — ระบบต้นทางเจอการ์ดซ้ำ 11 ใบใน 12 วันก่อนจะมีด่านนี้

### Gate

tests 55 รายการ · parity 514 จุด · golden path 18 ขั้น (ขั้น 16 เปลี่ยนเป็นส่งเข้า Content Center ผ่าน tool จริง) · Definition of ready 8 ข้อ

## 2.1.0 — 2026-09-08

ตามระบบ production ที่เจ้าของผลิตภัณฑ์ใช้จริง (อัปเดต 8 ก.ย. 2569) ให้ทัน 3 เรื่อง

### เพิ่ม — เกลาคลิปที่สืบมาเป็นบทของเรา (Intel Warroom)

- การ์ดชนิดคลิปในคลังมีส่วน `✍️ บทเวอร์ชันของเรา` — ตั้งธง เลือกหมวด Content Mix สไตล์ hook ความยาว และคีย์เวิร์ด DM แล้วส่งเข้าคิว
- งานเข้าคิวเป็น `wr_jobs` ชนิด `rewrite_reel` · รัน `/jobs` แล้ว agent เขียนบทจริงตาม `brain/41-reel-rewrite.md` และเสียงจาก `company/voice.md`
- เวอร์ชันที่ได้เก็บในตารางใหม่ `intel_scripts` แสดงบนการ์ดเดิม คัดลอกได้ ลบได้ และกด `⬆️ ส่งเข้า Content Center` เพื่อเปิดเป็นไอเดีย + variant RL ที่มีบทอยู่ในช่อง AI (ร่างของผู้ใช้ไม่ถูกทับ)
- การ์ดที่ยังไม่มีบทพูดถอดเสียงจะบอกตรงๆ ว่าเกลาไม่ได้ พร้อมปุ่มส่งเข้าคิวแกะใหม่ · รายงานคลิปต้องมีบรรทัด `[m:ss] …` ตาม `brain/30-scout.md`

### เพิ่ม — มุมมอง `⏳ คิว` ใน Content Center

- เห็นว่าการ์ดไหนกำลังให้ AI เกลา งานจาก Intel Warroom เดินถึงไหน และงานไหนพัง
- แถบสุขภาพบอกสิ่งที่ต้องทำต่อ ไม่ใช่แค่บอกว่ามีงานค้าง — งานรอเกิน 30 นาทีหรือค้างสถานะ "กำลังทำ" เกิน 20 นาที ขึ้นเตือนสีแดง
- ตัวกรองตามชนิดงาน · ลองใหม่ · ลบออกจากคิว · เปิด Script Studio ของงานที่เสร็จแล้ว · badge นับงานค้างเห็นได้จากหน้าบอร์ด

### เพิ่ม — แก้ชื่อการ์ดในที่

- แก้ชื่อไอเดียใน Content Center และชื่อการ์ดในคลัง Intel Warroom ได้จากแผงรายละเอียด (Enter บันทึก · Esc ยกเลิก)
- ไอเดียที่เปลี่ยนชื่อ จะเปลี่ยนชื่อ variant ที่ยังใช้ชื่อเดิมตามให้ด้วย ส่วน variant ที่ถูกตั้งชื่อเองแล้วไม่ถูกแตะ

### Gate

tests 49 รายการ · parity 507 จุด · golden path 18 ขั้น · Definition of ready 8 ข้อ

## 2.0.1 — 2026-09-08

### Fix — Content Center ลากการ์ด

- ช่องในบอร์ดรับ drop **เฉพาะการลากที่เริ่มจากการ์ดในบอร์ด** — เดิมรับทุกการลาก (ลากข้อความหรือไฟล์จาก Finder ทับช่องก็ยิงคำสั่งย้ายด้วย id ที่ไม่มีจริง)
- ย้ายไม่สำเร็จแล้ว**บอกผู้ใช้** — เดิมไม่มี error handling เลย เซิร์ฟเวอร์ล่มหรือย้ายไม่ผ่านก็เงียบสนิท การ์ดเด้งกลับที่เดิมโดยไม่มีคำอธิบาย
- ปล่อยการ์ดรัวสองทีไม่ยิงคำสั่งซ้ำ และปล่อยลงช่องที่การ์ดอยู่แล้วไม่เขียนทับเวลาเปลี่ยนสถานะ
- เพิ่ม regression test 2 ชุด (`tools/content.test.mjs`) — รวมเป็น 40 รายการ

### Fix — ZIP ส่งมอบตกไฟล์

- ZIP รุ่น 2.0.0 ขาด `Open Workspace.command` / `Open Workspace.bat` (ตัวเปิด workspace ทั้งสองระบบ) และ `examples/expected/candidates/*.json` — แตกไฟล์แล้ว doctor กับ golden ตก และผู้ใช้ที่ไม่ใช่ dev เปิด workspace ไม่ได้เลย
- 2.0.1 สร้าง ZIP จากทั้ง workspace (ยกเว้น `dist/`) และเก็บชื่อไฟล์ภาษาไทยเป็น UTF-8 — `เริ่มตรงนี้.md` เดิมแตกออกมาเป็นชื่อขยะ


## 2.0.0 — 2026-09-05

### Fix round 2

- `/news-daily` ดึง RSS จริงทุก source ด้วย HTTPS และเขียน brief ต่อข่าว; `--fixtures` ทำงานเฉพาะเมื่อผู้ใช้สั่ง
- ตัดตัวสร้าง hook/บทความสำเร็จรูปออกจาก tool และย้าย golden copy ไป `examples/expected/candidates/`
- ล็อก comment role เป็น `cta`, `article`, `source`, `angle2`, `cases` พร้อม copy lint ที่ตรวจข้ามข่าว คำห้ามของบริษัท บรรทัดยาว em-dash และโครงภาษาซ้ำ
- แก้ลิงก์ News Desk เป็น `/news-desk`

### Base release

รุ่นนี้ย้าย 3 ห้องจากระบบ production ที่เจ้าของผลิตภัณฑ์ใช้งานจริงมาเป็น workspace แบบ offline-first: News Desk, Content Center และ Intel Warroom

เพิ่ม local JSON store 15 ตารางหลักตาม production และ `agent_requests` สำหรับส่งงานแก้ให้ agent, REST dispatcher, News daily fixtures, text card, Content direct-write, Intel channel suggestions, Settings 5 แท็บ, agent skills 8 ชุด, parity manifest 430 จุด และ golden path 16 ขั้นครบสามห้อง

### ความต่างจากระบบ production

| ความสามารถเดิม | รุ่นนี้ |
|---|---|
| เซิร์ฟเวอร์ออนไลน์และฐานข้อมูลกลาง | รันบนเครื่องบริษัท ข้อมูลเป็นไฟล์ในเครื่อง |
| รอบเช้าอัตโนมัติ | ผู้ใช้กด `☀️ รันสมองเช้า` และส่ง `/news-daily` ให้ agent |
| งานเขียนผูกกับผู้ให้บริการเดียว | ใช้ AI ในบัญชีบริษัทและเสียงจาก `company/voice.md` |
| โพสต์อัตโนมัติ | คัดลอก caption กับคอมเมนต์ แล้วผู้ใช้โพสต์เอง |
| สืบตามเวลา | ผู้ใช้สั่ง `/scout`; เลน Meta ต้องตรวจด้วยตา |
| การ์ดซีนพร้อมใช้ | ใช้ได้เมื่อบริษัทใส่ kie.ai key; text card ใช้ได้โดยไม่เสียเครดิต |
| แจ้งเตือนผ่านแชต | ดูที่กระดิ่ง 🔔 ในหน้า |

ไม่รวม shared sheet, multi-user sync, auto-post, cron และ edition อื่น
