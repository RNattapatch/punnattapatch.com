# Prompt Library — 20+ Prompts (offline master file)

*v1 · 2026-04-22 · agent-builder-kit*

> This file aggregates all 20 prompts. Same content as the individual files in this folder. Use the individual files when working with Astro content collection (in punnattapatch.com repo).

---

---
title: "P1-01 — Install Claude Code + first greeting"
tier: starter
phase: 1
slug: p1-01-install-claude-code
prereqs: []
useCase: "เริ่ม session แรกใน Claude Code — ให้ The Architect แนะนำตัวและ detect persona ก่อนสร้าง claude.md"
timeToSetup: "3 นาที"
checkGate:
  - "คุณดาวน์โหลด Claude Code desktop app แล้วใช่มั้ย? (claude.ai/download)"
  - "คุณสร้าง project folder ใหม่สำหรับธุรกิจคุณแล้วใช่มั้ย?"
  - "คุณวาง 5 .md setup files (README + the-architect + skill-business-context + skill-build-agent-team + skill-prompt-library) ใน project folder แล้วใช่มั้ย?"
workedExample:
  industry: "Manufacturing SME (40 employees · ฿80M revenue · ขายอะไหล่รถบรรทุก)"
  scenario: "เจ้าของ Manufacturing SME เพิ่งดาวน์โหลด Claude Code + วาง 5 setup files เสร็จ · ยังไม่เคยใช้ Claude Code มาก่อน"
  inputs: "5 setup files ใน project folder (ยังไม่มี claude.md) + prompt ข้างล่าง"
  output: "The Architect แนะนำตัว + ถาม 2-persona detection + รอคุณตอบ 1 หรือ 2 → route ไป skill-business-context"
  timeSaved: "ถ้าเริ่มเองโดยไม่มี Kit: 30 นาทีงงกับ Claude Code + 2 ชม.ลองผิดลองถูก · ใช้ prompt นี้ 3 นาทีเริ่มได้เลย"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "ต้องการให้ปันมาติดตั้งให้ทั้งทีม? → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
เซสชันแรกของคุณใน Claude Code หลังวาง 5 setup files เสร็จ และยังไม่มี claude.md

## Prerequisite
- ไม่มี (prompt นี้คือจุดเริ่มต้น)

## The Prompt

```
@the-architect ผมเพิ่งดาวน์โหลด Claude Code และวาง 5 ไฟล์ setup ใน project folder นี้แล้ว:
- README.md
- the-architect.md
- skill-business-context.md
- skill-build-agent-team.md
- skill-prompt-library.md

กรุณา onboard ผมตามขั้นตอน — เริ่มจากแนะนำตัว ถามว่าผมเป็น persona ไหน (OWNER / MANAGER)
แล้วบอกขั้นถัดไปว่าจะ route ไป skill ไหนต่อ

ก่อนเริ่ม กรุณาเช็คว่าไฟล์ทั้ง 5 อ่านได้ครบ — ถ้าขาดไฟล์ใด บอกผมว่าไฟล์ไหนและวิธีหา

หลังจากผมตอบ persona แล้ว ให้ประกาศ USER_TYPE=OWNER หรือ USER_TYPE=MANAGER ชัดเจน
แล้วรอคำสั่งจากผมว่า "เริ่มสร้าง claude.md ได้เลย" ก่อน trigger skill ถัดไป
อย่าเพิ่ง deep-dive อะไรในตอนนี้ — แค่ greet + detect + รอ
```

## Expected output
The Architect ยืนยันว่าอ่าน 5 ไฟล์ครบ → แนะนำตัว → ถาม 2-persona detection → รอคำตอบ → ประกาศ USER_TYPE → route ไป skill-business-context

## Worked Example
**Industry:** Manufacturing SME (40 employees · ฿80M revenue · ขายอะไหล่รถบรรทุก)
**Scenario:** เจ้าของบริษัทเพิ่งเริ่มใช้ Claude Code · วาง 5 setup files เสร็จ 2 นาทีที่แล้ว · ยังไม่ได้สร้าง claude.md
**Inputs:** 5 setup files ใน project folder + prompt ข้างบน
**Output:** The Architect ตอบ 4 บรรทัด · รอ user ตอบ "1" · ประกาศ USER_TYPE=OWNER · บอก "พิมพ์ 'เริ่มสร้าง claude.md ได้เลย'"
**Time saved:** ถ้าเริ่มเองโดยไม่มี Kit: 30 นาที + 2 ชม. · ใช้ prompt นี้ 3 นาที

## Next step
→ ใช้ prompt P1-02 (Create claude.md via interview) ต่อทันที


---

---
title: "P1-02 — Create claude.md via interview"
tier: starter
phase: 1
slug: p1-02-claude-md-interview
prereqs: [p1-01-install-claude-code]
useCase: "Trigger skill-business-context 5-phase interview เพื่อสร้าง claude.md ที่เป็น single source of truth ของธุรกิจคุณ"
timeToSetup: "25 นาที"
checkGate:
  - "คุณรัน prompt P1-01 และ The Architect ประกาศ USER_TYPE แล้วใช่มั้ย?"
  - "คุณมีข้อมูลธุรกิจพร้อมตอบ: ชื่อ + จำนวนคน + รายได้ต่อเดือน + กลุ่มลูกค้าหลัก ใช่มั้ย?"
  - "คุณมีเวลาต่อเนื่อง 25 นาทีโดยไม่ขัดจังหวะใช่มั้ย? (interview ต้องตอบทีละข้อ)"
workedExample:
  industry: "Service-based SME (15 employees · ฿35M revenue · บริษัท digital marketing agency)"
  scenario: "เจ้าของ agency ขนาด 15 คน · ผ่าน P1-01 แล้ว · ยังไม่มี claude.md · พร้อมตอบสัมภาษณ์ 25 นาที"
  inputs: "USER_TYPE=OWNER ที่ประกาศไว้แล้ว + คำตอบจากปากผู้ใช้ใน 5 phase ของ skill-business-context"
  output: "ไฟล์ claude.md ใหม่ที่ project root · มี 8 sections (Identity / Business / Audience / Expertise / Goals / Voice / Constraints / File Routing)"
  timeSaved: "เขียนเองตามใจ: 3-4 ชม. + revise อีก 2-3 รอบ · ใช้ skill นี้ 25 นาทีจบ + ได้โครงที่ใช้ได้กับทุก agent"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "ต้องการให้ปันมาติดตั้งให้ทั้งทีม? → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
หลัง P1-01 เสร็จ และ The Architect รอคำสั่งให้ trigger skill ถัดไป

## Prerequisite
- P1-01 (Install Claude Code + first greeting) — ต้องมี USER_TYPE ประกาศแล้ว

## The Prompt

```
@the-architect เริ่มสร้าง claude.md ได้เลย

กรุณา invoke skill-business-context และเดิน 5-phase interview ให้ผม:
- Phase 1: Identity (ชื่อธุรกิจ / brand / handle / location)
- Phase 2: Business model (ขายอะไร · ให้ใคร · ราคาเท่าไหร่ · revenue ปัจจุบัน)
- Phase 3: Audience (target customer · pain · buying trigger)
- Phase 4: Expertise & Voice (ผมถนัดอะไร · พูดยังไง · ห้ามพูดอะไร)
- Phase 5: Goals & Constraints (เป้า 12 เดือน · งบ · ข้อจำกัด)

กฎการสัมภาษณ์:
1. ถามทีละ 1 คำถาม รอให้ผมตอบก่อนถามต่อ
2. ถ้าผมตอบสั้นเกินไป ขอตัวอย่างเพิ่ม
3. ถ้าผมตอบขัดกับคำตอบก่อนหน้า ชี้ให้ผมเห็นแล้วถามว่าจะเอาอันไหน
4. ห้ามเดาแทนผม — ถ้าไม่รู้ให้ถาม

เมื่อสัมภาษณ์ครบ 5 phase แล้ว:
- เขียน claude.md ที่ project root (path: ./claude.md)
- ใช้ structure ตาม template ใน skill-business-context.md
- จบด้วยการ summary 8 sections ให้ผมดูแล้วถามว่าผมยืนยันมั้ย
- ถ้าผมยืนยัน save ไฟล์ — ถ้ายังไม่ ให้ผมแก้ section ไหนก่อน

อย่ารีบ — คุณภาพของ claude.md กำหนดคุณภาพของ agent ทั้งทีมที่จะสร้างต่อไป
```

## Expected output
The Architect เริ่ม Phase 1 → ถามทีละข้อ → รวบ 5 phase → เขียน claude.md → summary ให้ยืนยัน → save ไฟล์ที่ ./claude.md

## Worked Example
**Industry:** Service-based SME (15 employees · ฿35M revenue · บริษัท digital marketing agency)
**Scenario:** เจ้าของ agency ผ่าน P1-01 มาแล้ว · นั่งโต๊ะ 25 นาที พร้อมตอบ
**Inputs:** USER_TYPE=OWNER + คำตอบจากผู้ใช้ใน 5 phase
**Output:** ./claude.md (~250 บรรทัด · 8 sections) ที่ผ่านการยืนยัน
**Time saved:** เขียนเอง 3-4 ชม. + revise · ใช้ skill 25 นาทีจบ

## Next step
→ ใช้ prompt P1-03 (Audit claude.md for gaps) ถ้าต้องการ stress-test ก่อนสร้าง agent · หรือไป Phase 2 (P2-01) เลยถ้ามั่นใจ


---

---
title: "P1-03 — Audit existing claude.md for gaps"
tier: intermediate
phase: 1
slug: p1-03-audit-claude-md
prereqs: [p1-02-claude-md-interview]
useCase: "ถ้าคุณมี claude.md อยู่แล้ว (เขียนเองหรือ generate มาก่อน) — ให้ Claude สแกนหา section ที่ขาด/อ่อน/ขัดกัน ก่อนเอาไปสร้าง agent"
timeToSetup: "10 นาที"
checkGate:
  - "คุณมีไฟล์ claude.md อยู่ที่ project root แล้วใช่มั้ย?"
  - "claude.md มีเนื้อหาอย่างน้อย 50 บรรทัดใช่มั้ย? (ถ้าน้อยกว่า ให้ใช้ P1-02 สร้างใหม่แทน)"
  - "คุณมี skill-business-context.md อยู่ใน project folder ใช่มั้ย? (audit ใช้เป็น reference)"
workedExample:
  industry: "Solo founder (1 person · ฿8M revenue · freelance B2B sales consultant)"
  scenario: "Solo consultant เขียน claude.md เองตอนเริ่มใช้ Claude Code 3 เดือนที่แล้ว · ตอนนี้ agent ตอบไม่แม่น สงสัย claude.md อาจขาดข้อมูล"
  inputs: "claude.md ปัจจุบัน (~120 บรรทัด) + skill-business-context.md (เป็น reference template)"
  output: "Audit report 5 หมวด: ครบ / ขาด / อ่อน / ขัดกัน / ซ้ำซ้อน · แต่ละ gap มี suggested fix + cite บรรทัด"
  timeSaved: "อ่านเองหา gap: 1-2 ชม. + ยังไม่แน่ใจว่าเช็คครบมั้ย · ใช้ prompt 10 นาที + ได้ report ที่อิง template มาตรฐาน"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "อยากเห็น pattern advanced กว่านี้? → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
มี claude.md อยู่แล้ว และอยาก stress-test ว่าครบ/ตรง/ไม่ขัดกัน ก่อนเอาไปสร้าง agent

## Prerequisite
- claude.md ที่ project root (จะเขียนเองหรือ generate ผ่าน P1-02 มาก็ได้)
- skill-business-context.md (เป็น reference สำหรับ template มาตรฐาน)

## The Prompt

```
ผมมี claude.md อยู่ที่ ./claude.md แล้ว — ขอให้คุณ audit ให้ละเอียด

ขั้นตอน:
1. อ่าน skill-business-context.md ก่อน — ดู section structure ที่เป็น "มาตรฐาน 8 sections"
2. อ่าน ./claude.md ทั้งไฟล์
3. เปรียบเทียบ field-by-field กับ template มาตรฐาน

Report ใน 5 หมวด — แต่ละ gap ต้อง cite บรรทัดของ claude.md และเสนอ fix ที่เขียนได้เลย:

หมวด 1 — ครบ (sections ที่มีและตรง template)
หมวด 2 — ขาด (sections ใน template ที่ไม่มีใน claude.md ของผม)
หมวด 3 — อ่อน (มี section นั้น แต่ข้อมูลตื้นเกินไปจน agent ใช้ไม่ได้ เช่น "ขายของ B2B" โดยไม่บอกว่า ขายอะไร ใคร เท่าไหร่)
หมวด 4 — ขัดกัน (เนื้อหาในไฟล์ขัดกันเอง เช่น Identity บอก solo founder แต่ Business model พูดเรื่องทีม 20 คน)
หมวด 5 — ซ้ำซ้อน (พูดเรื่องเดียวกัน 2 ที่ ในรูปต่างกัน — เสี่ยง agent งง)

จบ report ด้วย verdict 1 บรรทัด:
- "พร้อมใช้สร้าง agent ทันที" หรือ
- "ควรแก้ก่อน — gap ที่ blocker คือ [ระบุ section]"

ห้ามแก้ ./claude.md เอง — แค่ report ให้ผมตัดสินใจ
```

## Expected output
Audit report 5 หมวด พร้อม line citation + suggested fix · จบด้วย verdict 1 บรรทัดว่าใช้ได้ทันทีหรือต้องแก้ก่อน

## Worked Example
**Industry:** Solo founder (1 person · ฿8M revenue · freelance B2B sales consultant)
**Scenario:** Solo consultant เขียน claude.md เอง 3 เดือนก่อน · agent ตอบไม่แม่น · อยากเช็คก่อนแก้
**Inputs:** ./claude.md ~120 บรรทัด + skill-business-context.md
**Output:** Report 5 หมวด · พบ "ขาด section Audience" + "อ่อน Voice (ไม่มีตัวอย่างประโยคจริง)" + verdict "ควรแก้ก่อน"
**Time saved:** อ่านเอง 1-2 ชม. ไม่แน่ใจครบมั้ย · ใช้ prompt 10 นาทีได้ report อิง template

## Next step
→ ถ้า verdict "พร้อมใช้" ไป P2-01 · ถ้า "ควรแก้ก่อน" รัน P1-02 เฉพาะ section ที่ blocker


---

---
title: "P1-04 — Multi-project claude.md structure"
tier: advanced
phase: 1
slug: p1-04-multi-project-claude-md
prereqs: [p1-02-claude-md-interview]
useCase: "ถ้าคุณมีหลาย project / หลายบริษัท / agency หลาย client — ออกแบบ shared claude.md + per-project override pattern เพื่อไม่ต้องเขียนซ้ำ"
timeToSetup: "20 นาที"
checkGate:
  - "คุณมี project Claude Code มากกว่า 1 folder ใช่มั้ย? (เช่น holding มี 3 บริษัทย่อย / agency มี 5 client)"
  - "คุณมี base claude.md ที่ใช้ได้กับทุก project แล้ว (จาก P1-02) ใช่มั้ย?"
  - "คุณเข้าใจ symlink หรือ git submodule พื้นฐานใช่มั้ย? (pattern นี้ต้องใช้อย่างใดอย่างหนึ่ง)"
workedExample:
  industry: "Solo founder (1 person · ฿8M revenue · freelance B2B sales consultant)"
  scenario: "Solo consultant ทำงานให้ 4 client พร้อมกัน · แต่ละ client มี project Claude Code แยก · ไม่อยากเขียน Identity/Voice/Constraints ซ้ำ 4 รอบ"
  inputs: "base claude.md (shared) + ข้อมูลเฉพาะ 4 client + decision: symlink หรือ override-file pattern"
  output: "โครงสร้าง 1 base claude.md (~/agent-base/claude.md) + 4 per-client override files + คำแนะนำว่าเมื่อไหร่ใช้ pattern ไหน"
  timeSaved: "เขียนซ้ำ 4 รอบ + ตามแก้ทุกรอบที่ base เปลี่ยน: หลัก ชม.ต่อสัปดาห์ · pattern นี้ตั้งครั้งเดียว 20 นาที"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "ใช้ pattern นี้ใน workshop → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
มี Claude Code project มากกว่า 1 ที่ต้อง share Identity/Voice/Constraints ตัวเดียวกัน

## Prerequisite
- P1-02 (มี base claude.md แล้ว)
- ความเข้าใจ symlink พื้นฐาน หรือยอม import file

## The Prompt

```
ผมมี base claude.md อยู่แล้วที่ ./claude.md
แต่ตอนนี้ผมต้องดูแล [N] project พร้อมกัน:
- Project A: [ชื่อ + sector]
- Project B: [ชื่อ + sector]
- Project C: [ชื่อ + sector]

ทุก project แชร์: Identity, Voice, Constraints, Brand rules
แต่ต่างกันที่: Business model, Audience, Goals, File routing

ขอให้คุณออกแบบ multi-project pattern ให้ผม โดยพิจารณา 2 ทางเลือก:

ทางเลือก A — Symlink pattern
- ตั้ง ~/agent-base/claude-shared.md (เก็บ section ที่แชร์)
- แต่ละ project มี claude.md ที่เริ่มด้วย import line ชี้ไป shared file
- per-project sections เขียนใต้ import line

ทางเลือก B — Override file pattern
- แต่ละ project มี claude.md เต็มไฟล์ (copy จาก base)
- เพิ่ม claude.local.md สำหรับ override per-project
- กฎ: ถ้า field ขัดกัน claude.local.md ชนะ

วิเคราะห์ให้ผมตามนี้:
1. แต่ละทางเลือกเหมาะกับ user แบบไหน (จำนวน project / ความถี่ที่ base เปลี่ยน / ทีมเดียว vs หลายทีม)
2. Trade-off ของแต่ละทาง (ความง่าย vs ความยืดหยุ่น vs risk drift)
3. แนะนำทางเลือกสำหรับเคสผม + เหตุผล
4. เขียนตัวอย่าง file structure ที่ผมเอาไป implement ได้ตรง
5. ระบุ section ใน claude.md ของผมที่ต้องย้ายเข้า shared vs ที่ต้องอยู่ per-project

ห้ามแนะนำทางเลือกที่ 3 ที่ผสม pattern — เลือก A หรือ B เท่านั้น
```

## Expected output
การวิเคราะห์ 2 pattern + คำแนะนำเฉพาะเคสคุณ + ตัวอย่าง file structure ที่ implement ได้ตรง + รายการ section ที่ต้องย้าย

## Worked Example
**Industry:** Solo founder (1 person · ฿8M revenue · freelance B2B sales consultant)
**Scenario:** Solo consultant ดูแล 4 client พร้อมกัน · ไม่อยากเขียน base ซ้ำ 4 รอบ
**Inputs:** base claude.md + ข้อมูล 4 client (sector + ชื่อ)
**Output:** เลือก Symlink pattern + structure ~/agent-base/ + 4 client folders ที่ import shared + รายการ section ที่ย้าย 6 อัน
**Time saved:** เขียนซ้ำ 4 รอบ + sync drift หลัก ชม./สัปดาห์ · ตั้ง pattern ครั้งเดียว 20 นาที

## Next step
→ ใช้ prompt P2-01 สร้าง agent ตัวแรกใน project ที่ pattern พร้อมแล้ว


---

---
title: "P2-01 — Spawn Sale Agent (owner template)"
tier: starter
phase: 2
slug: p2-01-sale-agent-owner
prereqs: [p1-02-claude-md-interview]
useCase: "สร้าง agent ตัวแรกในทีม — Sale Team Leader ที่อ่าน claude.md เป็น context และตอบคำถาม sales/CRM/proposal ได้"
timeToSetup: "8 นาที"
checkGate:
  - "คุณมี claude.md ที่ project root (ผ่าน P1-02 หรือ P1-03 audit แล้ว) ใช่มั้ย?"
  - "USER_TYPE ของคุณคือ OWNER ใช่มั้ย? (template นี้ออกแบบสำหรับเจ้าของธุรกิจ)"
  - "คุณมี skill-build-agent-team.md อยู่ใน project folder ใช่มั้ย?"
workedExample:
  industry: "Manufacturing SME (40 employees · ฿80M revenue · ขายอะไหล่รถบรรทุก)"
  scenario: "เจ้าของโรงงานอะไหล่ผ่าน claude.md เสร็จ · อยากได้ agent ที่ช่วยจัดการ pipeline + เขียน follow-up ลูกค้า + draft proposal"
  inputs: "./claude.md + skill-build-agent-team.md (มี OWNER template) + prompt ข้างล่าง"
  output: "ไฟล์ ./agents/sales/sale-team-leader.md (~150 บรรทัด) ที่ inherit context จาก claude.md + พร้อมเรียกผ่าน @sale-team-leader"
  timeSaved: "เขียน agent prompt เองจากศูนย์: 2-3 ชม. + ลองใช้แล้วแก้ · ใช้ prompt 8 นาทีได้ agent ที่ใช้ได้ทันที"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "ต้องการให้ปันมาติดตั้งให้ทั้งทีม? → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
มี claude.md พร้อมแล้ว และต้องการ agent ตัวแรกของทีม sales

## Prerequisite
- P1-02 (claude.md ที่ project root)
- skill-build-agent-team.md

## The Prompt

```
ผมต้องการสร้าง agent ตัวแรกของทีม — Sale Team Leader

ขั้นตอนที่ผมอยากให้คุณทำ:
1. อ่าน ./claude.md ทั้งไฟล์ — โดยเฉพาะ section Identity, Business model, Audience, Voice
2. อ่าน skill-build-agent-team.md — ดู template "Sale Team Leader (OWNER)"
3. สร้างไฟล์ใหม่ที่ path: ./agents/sales/sale-team-leader.md
4. โครงสร้างไฟล์ตาม template มี 6 sections:
   - Role & Mission (1 ย่อหน้าสั้น)
   - Context inheritance (อ้างอิง ./claude.md ชัดเจน — ห้าม copy เนื้อหา)
   - Responsibilities (CRM update / follow-up / proposal draft / pipeline review)
   - Tone (อ้างอิง Voice section ของ claude.md)
   - Hand-off rules (เมื่อไหร่ส่งงานให้ agent อื่น เช่น proposal-writer หรือ orchestrator)
   - Working files (path ของ CRM / proposal templates / output folder)

กฎสำคัญ:
- ห้าม hard-code business detail ที่อยู่ใน claude.md อยู่แล้ว — ใช้ "อ่าน claude.md ก่อนทุกครั้ง" แทน
- ทุก path ใน Working files ต้องเป็น absolute หรือ ./relative-from-project-root
- ถ้า claude.md ไม่มีข้อมูลที่ template ต้องการ (เช่น CRM URL) ให้ note ว่า "TODO: ใส่ค่านี้หลัง P2-04 เสร็จ" — ห้ามแต่งค่าเอง

หลังเขียนไฟล์เสร็จ:
- summary ให้ผม 4 บรรทัด: path / lines / inherited sections / TODO ที่เหลือ
- บอก next step: เรียก @sale-team-leader ทดสอบด้วยคำสั่งอะไรเป็น smoke test
```

## Expected output
ไฟล์ ./agents/sales/sale-team-leader.md ใหม่ + summary 4 บรรทัด + smoke test command ที่เรียก @sale-team-leader ดูว่า inherit context ถูก

## Worked Example
**Industry:** Manufacturing SME (40 employees · ฿80M revenue · ขายอะไหล่รถบรรทุก)
**Scenario:** เจ้าของโรงงาน · มี claude.md พร้อม · อยากได้ Sale Agent ตัวแรก
**Inputs:** ./claude.md + skill-build-agent-team.md (OWNER template)
**Output:** ./agents/sales/sale-team-leader.md (~150 บรรทัด) + 1 TODO รอ CRM URL จาก P2-04
**Time saved:** เขียนเอง 2-3 ชม. + ลองแก้ · prompt 8 นาทีจบ

## Next step
→ ใช้ prompt P2-02 (Spawn Content Agent) เพื่อขยายทีม


---

---
title: "P2-02 — Spawn Content Agent"
tier: starter
phase: 2
slug: p2-02-content-agent
prereqs: [p2-01-sale-agent-owner]
useCase: "สร้าง Content Team Leader agent ที่เขียน FB post / reel script / carousel ตาม Voice ของคุณ"
timeToSetup: "8 นาที"
checkGate:
  - "คุณมี ./claude.md ที่ระบุ Voice + Audience ชัดเจนใช่มั้ย?"
  - "คุณมี ./agents/sales/sale-team-leader.md จาก P2-01 แล้วใช่มั้ย? (เป็น sibling reference)"
  - "คุณรู้ platform ที่จะโพสต์: FB / IG / TikTok / LinkedIn ใช่มั้ย? (อย่างน้อย 1)"
workedExample:
  industry: "Service-based SME (15 employees · ฿35M revenue · บริษัท digital marketing agency)"
  scenario: "เจ้าของ agency ต้องโพสต์ content เองทุกสัปดาห์ · ไม่อยากจ้าง content writer · ต้องการ agent ช่วย draft ที่ tone ตรงตน"
  inputs: "./claude.md + skill-build-agent-team.md + รายการ platform ที่ใช้ (เช่น FB + IG + LinkedIn)"
  output: "./agents/content/content-team-leader.md (~140 บรรทัด) ที่ถาม brief 5 ข้อก่อน draft + เขียนตาม Voice"
  timeSaved: "เขียน content เอง: 1-2 ชม.ต่อชิ้น · agent draft 10 นาที + edit อีก 5 นาที"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "ต้องการให้ปันมาติดตั้งให้ทั้งทีม? → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
มี Sale Agent แล้ว และต้องการเพิ่ม agent ที่จัดการเนื้อหาบน social

## Prerequisite
- P2-01 (มี ./agents/sales/sale-team-leader.md เป็น reference structure)

## The Prompt

```
ผมต้องการสร้าง Content Team Leader agent

ขั้นตอน:
1. อ่าน ./claude.md — focus ที่ Voice + Audience + Constraints (เช่น คำต้องห้าม / ห้าม mention คู่แข่ง)
2. อ่าน ./agents/sales/sale-team-leader.md — ใช้เป็น reference สำหรับ structure ที่ consistent
3. อ่าน skill-build-agent-team.md — ดู template "Content Team Leader"
4. สร้างไฟล์ที่ ./agents/content/content-team-leader.md

โครงสร้าง 7 sections:
- Role & Mission
- Context inheritance (อ้าง ./claude.md ตรงๆ)
- Platform scope (ระบุ FB / IG / TikTok / LinkedIn ที่ผมใช้จริง — ถามผมก่อนถ้าไม่แน่ใจ)
- Content types (post / reel script / carousel / long-form — ระบุที่ผมโพสต์จริง)
- Brief intake (5 คำถามที่ agent ต้องถามผมทุกครั้งก่อน draft: topic / goal / audience-mood / CTA / length)
- Voice rules (อ้าง Voice section ของ claude.md + เพิ่มกฎ "ห้าม emoji เกิน 2/post" ถ้า claude.md ไม่ได้ระบุ)
- Hand-off rules (เมื่อไหร่ส่งให้ sale-team-leader ทำ proposal ต่อ / เมื่อไหร่ส่ง orchestrator routing)

กฎสำคัญ:
- platform scope ต้องตรงกับที่ผมใช้จริง — ถ้า claude.md ไม่บอก ถามผมก่อนเขียน
- Brief intake 5 ข้อ ห้ามรวบเป็นข้อเดียว — ถามทีละข้อตอน agent run จริง
- ห้าม hard-code ตัวอย่าง post — ใช้ link "ดูตัวอย่างใน claude.md หรือไฟล์ใน ./content-samples/" แทน

หลังเสร็จ summary 4 บรรทัด + smoke test: "@content-team-leader ขอ draft FB post เรื่อง [topic ที่ผมจะบอก]"
```

## Expected output
./agents/content/content-team-leader.md ใหม่ + summary 4 บรรทัด + smoke test command

## Worked Example
**Industry:** Service-based SME (15 employees · ฿35M revenue · digital marketing agency)
**Scenario:** เจ้าของ agency โพสต์เองทุกสัปดาห์ · อยากได้ agent ช่วย draft
**Inputs:** ./claude.md + ./agents/sales/sale-team-leader.md + platform list (FB + IG + LinkedIn)
**Output:** ./agents/content/content-team-leader.md ~140 บรรทัด + Brief intake 5 ข้อ
**Time saved:** เขียนเอง 1-2 ชม./ชิ้น · agent draft 10 นาที + edit 5 นาที

## Next step
→ ใช้ prompt P2-03 (Spawn Personal Secretary) เพิ่มผู้ช่วยส่วนตัว


---

---
title: "P2-03 — Spawn Personal Secretary"
tier: starter
phase: 2
slug: p2-03-personal-secretary
prereqs: [p2-01-sale-agent-owner]
useCase: "สร้าง agent ผู้ช่วยส่วนตัวที่จัดการ inbox / calendar reminder / daily summary / meeting prep"
timeToSetup: "8 นาที"
checkGate:
  - "คุณมี ./claude.md ที่ระบุ working hours + meeting cadence ใช่มั้ย? (ถ้าไม่มี ให้เพิ่มก่อนรัน prompt นี้)"
  - "คุณรู้ว่าจะให้ secretary ทำอะไรบ้าง: inbox triage / calendar / daily summary / meeting prep ใช่มั้ย? (เลือกอย่างน้อย 2)"
  - "คุณมี ./agents/ folder จาก P2-01/P2-02 แล้วใช่มั้ย?"
workedExample:
  industry: "Solo founder (1 person · ฿8M revenue · freelance B2B sales consultant)"
  scenario: "Solo consultant มีลูกค้า 6-8 คนพร้อมกัน · พลาด follow-up + ลืมเตรียม meeting · ต้องการผู้ช่วยที่ runs daily"
  inputs: "./claude.md + รายการ task ที่อยากให้ secretary ทำ + working hours"
  output: "./agents/operations/personal-secretary.md (~130 บรรทัด) + daily routine 3 jobs (morning brief / lunch checkpoint / EOD wrap)"
  timeSaved: "จัดการเอง 30-45 นาที/วัน · secretary 10 นาที/วัน + ไม่พลาด follow-up"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "ต้องการให้ปันมาติดตั้งให้ทั้งทีม? → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
มี Sale + Content agent แล้ว และต้องการ agent ที่ดูแล operations ส่วนตัว

## Prerequisite
- P2-01 (มี ./agents/ folder structure)
- claude.md ที่ระบุ working hours

## The Prompt

```
ผมต้องการสร้าง Personal Secretary agent

ขั้นตอน:
1. อ่าน ./claude.md — focus ที่ working hours / meeting cadence / priority of life
2. อ่าน skill-build-agent-team.md — ดู template "Personal Secretary"
3. ก่อนเขียนไฟล์ ถามผม 3 คำถาม:
   - อยากให้ secretary ทำงานอะไรบ้าง? (inbox / calendar / daily summary / meeting prep / errand reminder)
   - ต้องการ daily routine กี่ครั้ง? (1 ครั้ง morning เท่านั้น / 2 ครั้ง morning+EOD / 3 ครั้ง morning+lunch+EOD)
   - ความสัมพันธ์กับ sale-team-leader — ให้ secretary ส่งเคสให้ sale agent ตอนไหน

4. หลังได้คำตอบ สร้างไฟล์ที่ ./agents/operations/personal-secretary.md

โครงสร้าง 6 sections:
- Role & Mission
- Context inheritance
- Daily routine (ระบุเวลา + jobs ตามคำตอบข้อ 2)
- Task scope (ตามคำตอบข้อ 1 — แต่ละงานต้องบอก input/output ชัด)
- Hand-off rules (ตามคำตอบข้อ 3)
- Boundaries (ห้ามทำอะไร เช่น ห้ามตอบ email แทนผม / ห้ามนัดประชุมโดยไม่ confirm)

กฎสำคัญ:
- Boundaries section บังคับเขียน — ป้องกัน secretary over-act
- ทุก job ใน Daily routine ต้องมี output ที่จับต้องได้ (ไม่ใช่ "monitor inbox" แต่เป็น "list 3 emails ที่ต้องตอบวันนี้")
- ห้ามสมมติ tool integration (Gmail MCP / Calendar MCP) — ถ้าผมยังไม่ setup ให้เขียนเป็น TODO

หลังเสร็จ summary 4 บรรทัด + smoke test: "@personal-secretary ขอ morning brief วันนี้"
```

## Expected output
./agents/operations/personal-secretary.md + summary + smoke test · มี Boundaries section ที่ป้องกัน over-act

## Worked Example
**Industry:** Solo founder (1 person · ฿8M revenue · freelance B2B sales consultant)
**Scenario:** Solo มีลูกค้า 6-8 ราย · พลาด follow-up · ต้องการ daily ops
**Inputs:** ./claude.md + คำตอบ 3 คำถาม (เลือก inbox+calendar+daily summary, 3 ครั้ง/วัน, ส่ง sale agent เมื่อ lead reply)
**Output:** ./agents/operations/personal-secretary.md ~130 บรรทัด + 3-routine schedule
**Time saved:** จัดการเอง 30-45 นาที/วัน · secretary 10 นาที/วัน

## Next step
→ ใช้ prompt P2-04 (CRM Bot with Google Sheet) ถ้าใช้ Sheet เก็บลูกค้า · หรือ P2-05 ถ้าอยาก proposal writer ก่อน


---

---
title: "P2-04 — Spawn CRM Bot with Google Sheet integration"
tier: intermediate
phase: 2
slug: p2-04-crm-bot-sheets
prereqs: [p2-01-sale-agent-owner]
useCase: "เชื่อม Google Sheet (CRM) เข้ากับ agent — อ่าน lead / append row / update status ผ่าน @crm-bot"
timeToSetup: "15 นาที"
checkGate:
  - "คุณมี Google Sheet ที่ใช้เก็บลูกค้าอยู่แล้วใช่มั้ย? (มี Sheet ID พร้อม)"
  - "Sheet นี้ตั้ง share permission เป็น 'anyone with link can view' หรือคุณ setup Apps Script/Service account แล้วใช่มั้ย?"
  - "คุณรู้ว่า column ปัจจุบันมีอะไรบ้าง: ชื่อ / phone / status / notes / ฯลฯ ใช่มั้ย?"
workedExample:
  industry: "Manufacturing SME (40 employees · ฿80M revenue · ขายอะไหล่รถบรรทุก)"
  scenario: "เจ้าของโรงงานเก็บลูกค้าใน Google Sheet 200+ rows · พนักงาน sales 4 คน update มือ · อยากให้ agent อ่าน + append แทน"
  inputs: "./claude.md + Google Sheet ID + รายการ column ปัจจุบัน + skill-build-agent-team.md"
  output: "./agents/sales/crm-bot.md + ./agents/sales/crm-bot.config.json (เก็บ Sheet ID + column map) · เรียกผ่าน @crm-bot"
  timeSaved: "Update Sheet มือ + ค้น lead: 15-20 นาที/วัน · agent ทำให้ 2 นาที + ไม่พลาด field"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "อยากเห็น pattern advanced กว่านี้? → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
มี sale-team-leader แล้ว และอยากให้ agent อ่าน/เขียน CRM ใน Google Sheet โดยตรง

## Prerequisite
- P2-01 (sale-team-leader.md เป็น parent)
- Google Sheet ที่ตั้ง share หรือ Apps Script พร้อม

## The Prompt

```
ผมต้องการสร้าง CRM Bot ที่เชื่อมกับ Google Sheet ของผม

ก่อนเริ่ม ขอให้คุณถามผม 3 ข้อ:
1. Google Sheet ID อะไร? (ดึงจาก URL: docs.google.com/spreadsheets/d/<ID>/edit)
2. ชื่อ tab ที่เก็บ lead คืออะไร? (default: Sheet1)
3. ขอรายการ column ทั้งหมดเรียงตามลำดับใน sheet (เช่น: A=ชื่อ B=phone C=status D=last-contact E=notes)

หลังได้ข้อมูลครบ ทำ 2 ไฟล์พร้อมกัน:

ไฟล์ 1 — ./agents/sales/crm-bot.config.json
{
  "sheetId": "<ตามที่ผมให้>",
  "tabName": "<ตามที่ผมให้>",
  "columnMap": {
    "name": "A",
    "phone": "B",
    "status": "C",
    "lastContact": "D",
    "notes": "E"
  },
  "accessMethod": "csv-export | apps-script | service-account",
  "csvExportUrl": "<ถ้า accessMethod = csv-export ให้สร้าง URL ตาม pattern>"
}

ไฟล์ 2 — ./agents/sales/crm-bot.md
- Role: read/append/update CRM rows
- Context inheritance: claude.md + sale-team-leader.md (parent)
- Capabilities: 4 commands (list-leads / find-lead / append-lead / update-status)
- Each command: input format + output format + which config field used
- Error handling: ถ้า Sheet inaccessible ให้ตอบอย่างไร / ถ้า column map ไม่ตรงให้ทำยังไง
- Boundaries: ห้ามลบ row · ห้ามเปลี่ยน column structure · ห้ามแชร์ข้อมูลลูกค้านอก context

กฎสำคัญ:
- ห้าม hard-code Sheet ID ใน .md — ต้องอ่านจาก config.json เท่านั้น
- ทุก command ต้อง cite row number ของ Sheet เวลาตอบ (ให้ผม audit ได้)
- หลังเสร็จ test สมมติ 1 รอบ: "@crm-bot list-leads status=hot" — show output คาดหวัง
```

## Expected output
2 ไฟล์ใหม่ (config.json + crm-bot.md) + sample test response ที่ cite row number

## Worked Example
**Industry:** Manufacturing SME (40 employees · ฿80M revenue · ขายอะไหล่รถบรรทุก)
**Scenario:** Sheet 200+ rows · sales 4 คน update มือ · อยากให้ agent ดูแล
**Inputs:** ./claude.md + Sheet ID + 5 columns (ชื่อ/phone/status/last-contact/notes) + access via csv-export
**Output:** crm-bot.config.json + crm-bot.md (~120 บรรทัด) + 4 commands พร้อม
**Time saved:** มือ 15-20 นาที/วัน · agent 2 นาที + zero missed field

## Next step
→ ใช้ prompt P2-05 (Proposal Writer with brand voice) เพื่อเชื่อม CRM → proposal


---

---
title: "P2-05 — Spawn Proposal Writer with brand voice"
tier: intermediate
phase: 2
slug: p2-05-proposal-writer-brand-voice
prereqs: [p2-01-sale-agent-owner]
useCase: "สร้าง agent เขียน proposal ที่ tone ตรงแบรนด์ + เรียนจาก 3 closed-won deals ที่คุณเคยปิดได้"
timeToSetup: "20 นาที"
checkGate:
  - "คุณมี ./claude.md ที่มี Voice section ครบ (มีตัวอย่างประโยคจริง ไม่ใช่แค่ keyword) ใช่มั้ย?"
  - "คุณมี proposal 3 ฉบับที่ปิดดีล closed-won (text หรือ docx) พร้อมจะ paste/upload ใช่มั้ย?"
  - "คุณรู้ proposal format ของคุณ: docx / pdf / Notion / web · เลือก 1 ใช่มั้ย?"
workedExample:
  industry: "Service-based SME (15 employees · ฿35M revenue · บริษัท digital marketing agency)"
  scenario: "เจ้าของ agency มี proposal 3 ฉบับที่ปิดดีล 200k+ · อยากให้ agent เขียนใหม่ tone เดียวกัน · ลด time-to-proposal จาก 2 วันเหลือ 2 ชม."
  inputs: "./claude.md + 3 proposal ฉบับ closed-won + format choice (docx)"
  output: "./agents/sales/proposal-writer.md + ./agents/sales/proposal-samples/ (3 ไฟล์ที่ paste มา) + voice-fingerprint extracted"
  timeSaved: "เขียน proposal เอง 4-8 ชม./ฉบับ · agent draft 30 นาที + edit 1 ชม."
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "อยากเห็น pattern advanced กว่านี้? → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
ปิดดีลได้บ่อยพอที่ proposal เริ่มเป็น bottleneck และอยาก scale โดยไม่เสีย tone

## Prerequisite
- P2-01 (sale-team-leader.md เป็น parent reference)
- claude.md ที่มี Voice section + ตัวอย่างประโยคจริง

## The Prompt

```
ผมต้องการสร้าง Proposal Writer agent ที่ tone ตรงแบรนด์ผม

ขั้นตอนที่ผมอยากให้คุณทำตามลำดับ:

Step 1 — ขอ samples
ขอให้ผม paste proposal 3 ฉบับที่ปิดดีลแล้ว (closed-won) — ทีละฉบับ
หลังได้ครบ save เป็น ./agents/sales/proposal-samples/sample-1.md, sample-2.md, sample-3.md

Step 2 — Extract voice fingerprint
อ่าน 3 samples + claude.md Voice section
สรุปเป็น voice fingerprint 8 bullet:
- Average sentence length
- คำเชื่อมที่ใช้บ่อย (top 5)
- คำที่ไม่เคยใช้ (forbidden list)
- โครงสร้าง opening paragraph (3 รูปแบบที่เจอ)
- โครงสร้าง pricing section
- CTA pattern
- ระดับ formal/casual (1-10)
- Signature elements (เช่น มี case study เสมอ / มี timeline เสมอ / ฯลฯ)

แสดง fingerprint ให้ผมดู — ถามว่าตรงมั้ย — แก้ตามที่ผมบอก

Step 3 — สร้าง agent file
หลังผมยืนยัน fingerprint สร้าง ./agents/sales/proposal-writer.md โครงสร้าง 7 sections:
- Role & Mission
- Context inheritance (claude.md + sale-team-leader.md)
- Voice fingerprint (paste จาก step 2)
- Reference samples (link ไป ./agents/sales/proposal-samples/)
- Brief intake (8 ข้อก่อน draft: client / industry / pain / scope / budget-range / timeline / format / deadline)
- Draft workflow (3 phase: outline → fill → polish)
- Quality gate (ก่อนส่งให้ผม ต้อง self-check ว่า fingerprint match ทุก bullet)

กฎ:
- ห้าม draft proposal ใน chat — เขียน file ใน ./output/proposals/<client>-<date>.md เท่านั้น
- Format export ตามที่ผมเลือก (docx/pdf/Notion/web) — ระบุใน Draft workflow
- ทุกครั้งก่อน draft ต้องอ่าน 3 samples ใหม่ — ห้าม cache ในหัว
```

## Expected output
3 sample files saved + voice fingerprint 8 bullet (ผ่านการ confirm) + ./agents/sales/proposal-writer.md พร้อมใช้

## Worked Example
**Industry:** Service-based SME (15 employees · ฿35M revenue · digital marketing agency)
**Scenario:** มี proposal 3 ฉบับ closed-won 200k+ · อยากลด time-to-proposal
**Inputs:** ./claude.md + 3 proposal text + format=docx
**Output:** 3 samples saved + 8-bullet fingerprint + proposal-writer.md ~180 บรรทัด
**Time saved:** เขียนเอง 4-8 ชม./ฉบับ · agent 30 นาที draft + 1 ชม. edit

## Next step
→ ใช้ prompt P2-06 (Custom Department Head) ถ้าต้อง agent หมวดที่ template ไม่มี


---

---
title: "P2-06 — Design custom department head agent"
tier: intermediate
phase: 2
slug: p2-06-custom-department-head
prereqs: [p2-01-sale-agent-owner]
useCase: "Meta-prompt: ออกแบบ agent หมวดใหม่ที่ template ไม่มี (เช่น HR / Procurement / Compliance / Logistics) ผ่าน guided Q&A"
timeToSetup: "20 นาที"
checkGate:
  - "คุณรู้ชื่อหมวดที่อยากสร้าง agent ใหม่ใช่มั้ย? (เช่น HR head / Procurement / R&D)"
  - "คุณมี ./claude.md ที่ระบุว่า business มีหมวดนี้จริงใช่มั้ย? (ถ้าไม่มี เพิ่มก่อน)"
  - "คุณมีตัวอย่าง task ที่ agent ตัวนี้ต้องทำอย่างน้อย 5 อันใช่มั้ย?"
workedExample:
  industry: "Solo founder (1 person · ฿8M revenue · freelance B2B sales consultant)"
  scenario: "Solo consultant อยากได้ agent หมวด 'Learning & Knowledge' ที่จัดการ note + book summary + idea backlog · template ไม่มีหมวดนี้"
  inputs: "./claude.md + ชื่อหมวด + 5 sample task + decision: standalone หรือ child ของ existing agent"
  output: "./agents/learning/knowledge-curator.md (~150 บรรทัด) + บันทึก rationale ว่าทำไม design แบบนี้"
  timeSaved: "ออกแบบเองโดยไม่มี framework: หลัก ชม. + agent ตอบไม่ตรง · meta-prompt 20 นาทีได้ structure ที่ทดสอบแล้ว"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "อยากเห็น pattern advanced กว่านี้? → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
ต้องการ agent หมวดที่ skill-build-agent-team.md ไม่มี template ให้

## Prerequisite
- P2-01 (เข้าใจ structure agent file พื้นฐาน)
- claude.md ที่ระบุว่า business มีหมวดนี้

## The Prompt

```
ผมอยากออกแบบ agent หมวดใหม่ที่ template ไม่มีให้ — กรุณาใช้ meta-prompt mode พาผมออกแบบ

หมวดที่ผมอยากสร้าง: [ชื่อหมวด]
ตัวอย่าง: HR head / Procurement / Compliance / R&D / Logistics / Customer Success / [อื่นๆ]

ขั้นตอนที่ผมอยากให้คุณทำ:

Phase 1 — Discovery (ถามทีละข้อ)
1. หมวดนี้แก้ปัญหาอะไรในธุรกิจผม?
2. ใครเป็น user หลักของ agent ตัวนี้? (ผมคนเดียว / ทีม / ลูกค้า)
3. ขอ 5 task จริงที่ agent ต้องทำได้ (concrete ไม่ใช่ abstract)
4. agent ตัวนี้ standalone หรือเป็น child ของ existing agent (เช่น sale / content / operations)?
5. ต้อง integrate tool ภายนอกมั้ย? (Sheet / DB / API / file folder)

Phase 2 — Design proposal
หลังถามครบ 5 ข้อ เสนอ design ให้ผม 1 หน้า:
- ชื่อ agent (kebab-case)
- Path ที่จะ save (./agents/<dept>/<name>.md)
- Sections ที่จะมี (อย่างน้อย Role / Context / Capabilities / Boundaries)
- Hand-off graph (รับงานจากใคร / ส่งงานให้ใคร)
- Tool dependencies + วิธี integrate

ถามผมว่า design นี้โอเคมั้ย — ถ้าไม่ ปรับตามที่บอก

Phase 3 — Build
หลังผม approve เขียนไฟล์จริง โครงสร้าง consistent กับ agent อื่นใน ./agents/

Phase 4 — Rationale log
เขียนเหตุผลการ design ลง ./agents/<dept>/_rationale.md (1 หน้า)
- ทำไมเลือก standalone vs child
- ทำไม capabilities แบ่งแบบนี้
- Trade-off ที่ตัดสินใจ

กฎ:
- ห้ามข้าม Phase 1 — discovery สำคัญที่สุด
- ห้าม design agent ที่ overlap หน้าที่เกิน 30% กับ agent ที่มีอยู่แล้ว — ถ้าใกล้กันชี้ให้ผมตัดสิน
- Boundaries section บังคับมี อย่างน้อย 3 ข้อ
```

## Expected output
4-phase walk-through จบที่ agent file ใหม่ + rationale log บันทึก decision

## Worked Example
**Industry:** Solo founder (1 person · ฿8M revenue · freelance B2B sales consultant)
**Scenario:** อยากได้ Learning & Knowledge agent · template ไม่มี
**Inputs:** ./claude.md + ชื่อหมวด "knowledge-curator" + 5 task + standalone choice
**Output:** ./agents/learning/knowledge-curator.md + _rationale.md
**Time saved:** ออกแบบเอง หลัก ชม. + ตอบไม่ตรง · meta-prompt 20 นาที + structure ทดสอบแล้ว

## Next step
→ ใช้ prompt P2-07 (Orchestrator router) ถ้าทีม agent มี 4+ ตัวแล้วเริ่มซับซ้อน


---

---
title: "P2-07 — Orchestrator pattern (router agent)"
tier: advanced
phase: 2
slug: p2-07-orchestrator-router
prereqs: [p2-01-sale-agent-owner, p2-02-content-agent, p2-03-personal-secretary]
useCase: "เมื่อทีม agent มี 4+ ตัวแล้วเริ่มงงว่า task ไหนเรียกใคร — สร้าง orchestrator ที่รับ task แล้ว route ไปยัง specialist"
timeToSetup: "25 นาที"
checkGate:
  - "คุณมี agent อย่างน้อย 4 ตัวใน ./agents/ แล้วใช่มั้ย?"
  - "คุณเคยเจอ pain ว่า 'ไม่รู้จะเรียก agent ไหน' หรือ 'เรียกผิด agent' ใช่มั้ย?"
  - "คุณ list หน้าที่ของ agent แต่ละตัวได้ใน 1 ประโยคใช่มั้ย? (ถ้าไม่ได้ revise agent file ก่อน)"
workedExample:
  industry: "Manufacturing SME (40 employees · ฿80M revenue · ขายอะไหล่รถบรรทุก)"
  scenario: "เจ้าของโรงงานมี 5 agent: sale / content / secretary / crm-bot / proposal-writer · พนักงานเริ่มเรียกผิด agent · อยากได้ single entry point"
  inputs: "./claude.md + ทุกไฟล์ใน ./agents/ + รายการ task ตัวอย่างที่เคยเรียกผิด"
  output: "./agents/orchestrator.md + routing table 12 patterns + fallback rule + escalation rule"
  timeSaved: "เรียกผิด + redo: 2-3 ครั้ง/วัน · orchestrator route ถูกครั้งแรก + ลด cognitive load"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "ใช้ pattern นี้ใน workshop → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
ทีม agent โตจนเริ่ม route ผิด และต้องการ single entry point

## Prerequisite
- มี agent อย่างน้อย 4 ตัว
- แต่ละ agent มี Role 1 บรรทัดที่ชัด (ถ้าไม่ revise ก่อน)

## The Prompt

```
ผมต้องการสร้าง Orchestrator agent ที่รับ task ทุกอย่างจากผม แล้ว route ไปยัง specialist agent ที่เหมาะสม

ขั้นตอน:

Step 1 — Inventory
อ่านทุกไฟล์ใน ./agents/ (recursively)
สรุปเป็น table: agent name | path | role 1 บรรทัด | สามารถทำอะไร (3-5 capabilities) | สิ่งที่ทำไม่ได้

Step 2 — Routing table design
จาก inventory ออกแบบ routing table 10-15 patterns ครอบคลุมงานที่เจอบ่อย
แต่ละ row: trigger phrase pattern | route to | reason
ตัวอย่าง:
- trigger "ขอ proposal สำหรับ [client]" → proposal-writer · reason: เป็น output ที่ writer ดูแล
- trigger "lead ใหม่ชื่อ [name]" → crm-bot first, then sale-team-leader · reason: ต้อง record ก่อน follow-up

Step 3 — Edge cases
ระบุ 3 กฎสำหรับ edge case:
- Ambiguous (เข้าได้หลาย agent) → orchestrator ถามผมก่อน route
- Cross-agent (ต้องใช้ 2+ agent) → orchestrator วาง plan แล้วเรียกตามลำดับ
- Out of scope (ไม่มี agent ที่ทำได้) → orchestrator แนะนำว่าควรสร้าง agent ใหม่ผ่าน P2-06

Step 4 — สร้าง file
เขียน ./agents/orchestrator.md โครงสร้าง 8 sections:
- Role & Mission
- Context inheritance (claude.md + index ของทุก agent)
- Inventory table (จาก step 1)
- Routing table (จาก step 2)
- Edge case rules (จาก step 3)
- Logging (ทุก route decision เขียนลง ./agents/_routing-log.md)
- Boundaries (orchestrator ห้ามทำงานเอง — route only)
- Smoke tests (5 sample task + expected route)

กฎเหล็ก:
- Orchestrator ห้าม execute task เอง — route only เสมอ
- ถ้า specialist agent ไม่ตอบ ให้ escalate กลับมาหาผม ห้ามแทน
- Routing log ต้อง append ทุกครั้ง — ใช้ analyze pattern ภายหลัง
```

## Expected output
Inventory table + Routing table 10-15 row + 3 edge case rules + ./agents/orchestrator.md + 5 smoke tests

## Worked Example
**Industry:** Manufacturing SME (40 employees · ฿80M revenue · ขายอะไหล่รถบรรทุก)
**Scenario:** มี 5 agent · พนักงานเรียกผิด · ต้องการ entry point
**Inputs:** ./agents/ ทุกไฟล์ + รายการ task ที่เคยเรียกผิด
**Output:** orchestrator.md + 12-row routing table + log file pattern
**Time saved:** เรียกผิด 2-3 ครั้ง/วัน · route ถูกครั้งแรก

## Next step
→ ใช้ prompt P2-08 (Agent-to-agent handoff) เพื่อให้ agent ส่งงานต่อกันได้โดย orchestrator ไม่ต้องคุม


---

---
title: "P2-08 — Agent-to-agent handoff workflow"
tier: advanced
phase: 2
slug: p2-08-agent-handoff
prereqs: [p2-07-orchestrator-router]
useCase: "ให้ agent ส่งงานต่อกันโดยตรง พร้อม context bundle ที่ structured — ไม่ต้องผ่าน orchestrator ทุกครั้ง"
timeToSetup: "20 นาที"
checkGate:
  - "คุณมี orchestrator.md จาก P2-07 แล้วใช่มั้ย?"
  - "คุณมี agent อย่างน้อย 2 ตัวที่ต้องส่งงานต่อกันบ่อย (เช่น content → sale, crm → proposal) ใช่มั้ย?"
  - "คุณยอมรับว่า direct handoff bypass orchestrator (จะต้อง trade-off กับ logging) ใช่มั้ย?"
workedExample:
  industry: "Service-based SME (15 employees · ฿35M revenue · บริษัท digital marketing agency)"
  scenario: "ทีม agent ของ agency: content-team-leader draft post → ต้องส่งให้ sale-team-leader ดูว่าตรงกับ pitch ลูกค้ามั้ย · ผ่าน orchestrator ทุกรอบช้า"
  inputs: "./agents/orchestrator.md + 2 agent ที่ handoff บ่อย + sample task ที่ต้องส่งต่อ"
  output: "Handoff protocol .md + update 2 agent files + format ของ context bundle (JSON-like header) + handoff log"
  timeSaved: "ผ่าน orchestrator ทุกรอบ: +1 hop/round · direct handoff ลด round-trip 50% · งาน complex 5-step ลดเวลา 30%"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "ใช้ pattern นี้ใน workshop → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
มี orchestrator แล้ว และเจอว่าบาง pair handoff บ่อยจน orchestrator hop เปล่า

## Prerequisite
- P2-07 (orchestrator พร้อม + routing log ทำงานอยู่)

## The Prompt

````
ผมต้องการเพิ่ม direct agent-to-agent handoff pattern โดยไม่ทำลาย orchestrator structure

ขั้นตอน:

Step 1 — Identify handoff pairs
อ่าน ./agents/_routing-log.md (จาก orchestrator)
หา pair ที่ orchestrator route A→B บ่อยกว่า 5 ครั้ง/สัปดาห์
เสนอ pair ที่ควรเปิด direct handoff (สูงสุด 3 pair) + เหตุผล
ถามผมว่า approve pair ไหน

Step 2 — Design context bundle format
ออกแบบ structured context bundle ที่ agent A ส่งให้ B:

```json
{
  "from": "content-team-leader",
  "to": "sale-team-leader",
  "task": "review FB post draft for client X",
  "context": {
    "client": "ชื่อ + industry + stage",
    "draft_path": "./output/content/draft-2026-04-22.md",
    "review_focus": ["ตรง pitch มั้ย", "tone match มั้ย"],
    "deadline": "today EOD"
  },
  "expected_output": "approve | revise (with specific change list) | reject (with reason)",
  "handoff_id": "<uuid หรือ timestamp>"
}
```

Step 3 — Update agent files
ใน agent A เพิ่ม section "Direct handoff to B":
- เมื่อไหร่ใช้ (trigger condition)
- วิธีสร้าง context bundle
- รอ response กี่นาทีก่อน escalate กลับ orchestrator

ใน agent B เพิ่ม section "Receive handoff from A":
- รับ bundle structure ไหน
- response format
- เมื่อไหร่ส่งกลับ A · เมื่อไหร่ escalate orchestrator

Step 4 — Logging
ทุก handoff ต้อง append ./agents/_handoff-log.md:
- timestamp / from / to / task / handoff_id / outcome (success/escalated/timeout)

Step 5 — Update orchestrator.md
เพิ่ม section "Direct handoff exceptions"
ระบุ pair ที่ bypass orchestrator + กฎว่าเมื่อไหร่ orchestrator ยังต้องเข้ามาแทรก (เช่น ถ้า handoff fail 2 ครั้งติด)

Step 6 — Smoke test
สมมติ task 1 อัน + เดิน handoff 1 รอบเต็ม + แสดง log ที่ append

กฎ:
- เปิด direct handoff สูงสุด 3 pair — เกินนี้ระบบ debug ยาก
- ทุก handoff ต้อง logged — ห้ามเปิด silent handoff
- ถ้า handoff timeout > 5 นาที → auto-escalate orchestrator
````

## Expected output
List 3 pair ที่ approve + context bundle format + 2 agent file updates + orchestrator update + handoff log file + smoke test ที่เดินครบ

## Worked Example
**Industry:** Service-based SME (15 employees · ฿35M revenue · digital marketing agency)
**Scenario:** content-team-leader → sale-team-leader handoff บ่อย · ผ่าน orchestrator ช้า
**Inputs:** _routing-log.md + 2 agent files + sample task
**Output:** 1 pair approved + bundle format + 2 file updates + smoke test เดินครบ
**Time saved:** ลด round-trip 50% · งาน complex 5-step ลดเวลา 30%

## Next step
→ Phase 2 จบแล้ว · ใช้ pattern นี้ใน workshop → ดู In-House Workshop


---

---
title: "P3-01 — Daily briefing from Personal Secretary"
tier: starter
phase: 3
slug: p3-01-daily-briefing
prereqs: [p1-02-claude-md-interview, p2-03-personal-secretary]
useCase: "รัน prompt นี้ทุกเช้า — Personal Secretary อ่าน log เมื่อวาน + calendar วันนี้ + งาน priority สูง แล้วสรุปเป็น 5-bullet briefing"
timeToSetup: "5 นาที setup ครั้งแรก · 30 วินาทีรันทุกเช้า"
checkGate:
  - "คุณมี ./agents/operations/personal-secretary.md จาก P2-03 แล้วใช่มั้ย?"
  - "คุณมี ./logs/ folder ที่เก็บ daily log เมื่อวาน (text file หรือ md) ใช่มั้ย? (ถ้าไม่มี secretary จะ skip step นั้น)"
  - "คุณมี calendar input — Google Calendar export หรือ paste meeting list ของวันนี้ — พร้อมใช่มั้ย?"
workedExample:
  industry: "Manufacturing SME (40 employees · 80M revenue · ขายอะไหล่รถบรรทุก)"
  scenario: "เจ้าของโรงงานเปิดวันด้วย backlog 30+ unread message · 3 meeting + 5 follow-up ค้าง · อยากรู้ใน 60 วินาทีว่าวันนี้ต้องโฟกัสอะไร"
  inputs: "personal-secretary.md + ./logs/2026-04-21.md (เมื่อวาน) + paste calendar 3 meeting วันนี้ + รายการ 5 deal ที่ pending"
  output: "5-bullet briefing: 1) priority deal ที่ค้างนานสุด 2) meeting prep ที่ต้องทำก่อนบ่าย 3) decision pending จากเมื่อวาน 4) blocker ที่ต้องแก้ก่อน 5) win เล็กที่ฉลองได้"
  timeSaved: "อ่าน log เอง 25-40 นาที/เช้า · briefing 30 วินาที + คุณเลือกทำตามได้เลย"
phaseCtaHref: "/training/p1-ai-workshop-1-day#waitlist"
phaseCtaLabel: "ต้องการให้ปันมาติดตั้งให้ทั้งทีม? → ดู P1 Public Training Waitlist"
published: 2026-04-22
---

## Use when
ทุกเช้าก่อนเปิดงานจริง · ต้องการ context กลับมาใน 60 วินาทีหลังพักไป 10+ ชั่วโมง

## Prerequisite
- P1-02 (claude.md ที่ระบุ priority weighting)
- P2-03 (personal-secretary.md พร้อม daily routine)
- ./logs/ folder ที่มีไฟล์เมื่อวาน (optional แต่แนะนำ)

## The Prompt

```
@personal-secretary ขอ morning briefing วันนี้

ขั้นตอนที่ผมอยากให้คุณทำตามลำดับ:

Step 1 — Gather context
อ่าน 3 source ตามลำดับ:
- ./claude.md section "Priority weighting" + "Working hours"
- ./logs/<yesterday-date>.md (ถ้าไม่มีไฟล์ ให้ระบุ "no log found" แล้วไปต่อ)
- Paste ของผมข้างล่าง: calendar วันนี้ + รายการ deal pending

Step 2 — Synthesize ไม่ใช่ list
ห้าม dump ทุกอย่างมาเป็น list ยาว · เลือกแค่ 5 item ที่ตรงเงื่อนไขนี้:
- Item 1: deal ที่ค้างนานสุดและ revenue impact สูงสุด (ระบุชื่อ + จำนวนวันที่ค้าง)
- Item 2: meeting วันนี้ที่ต้อง prep ก่อน (ระบุเวลา + 1 ประโยคว่าต้องเตรียมอะไร)
- Item 3: decision ที่ค้างจากเมื่อวาน (ผมต้องตัดสินใจอะไร · option A vs B)
- Item 4: blocker — task ที่หยุดงานอื่นไว้ ถ้าไม่แก้วันนี้จะ cascade
- Item 5: win เล็ก — สิ่งที่ดีที่เกิดเมื่อวาน (เพื่อ momentum · 1 ประโยค)

Step 3 — Format
ส่งกลับมาเป็น markdown แบบนี้:
🌅 Morning Briefing — <today-date>
1. [Priority deal] ...
2. [Meeting prep] ...
3. [Decision pending] ...
4. [Blocker] ...
5. [Win] ...
สรุปเวลาที่แนะนำ: เช้านี้ทำ X · บ่ายทำ Y · ที่เหลือ defer

กฎ:
- ห้ามใส่ item ที่ไม่ actionable วันนี้ — ถ้า item ที่ 4 หรือ 5 หาไม่เจอ ให้เขียน "ไม่มี blocker / ไม่มี win เด่นเมื่อวาน"
- ห้าม recommend tool หรือ workflow ใหม่ใน briefing — focus ที่ today only
- ห้าม briefing ยาวเกิน 200 คำ — ถ้าเกิน ตัดให้เหลือ

Calendar วันนี้ + deal pending ของผม:
[paste ที่นี่]
```

## Expected output
5-bullet markdown briefing ความยาว 150-200 คำ + คำแนะนำเวลา (เช้า/บ่าย/defer) · actionable ทุก item

## Worked Example
**Industry:** Manufacturing SME (40 employees · 80M revenue · อะไหล่รถบรรทุก)
**Scenario:** Backlog 30+ message · 3 meeting + 5 follow-up ค้าง · ต้อง context-switch กลับมาทำงาน
**Inputs:** personal-secretary.md + log เมื่อวาน + calendar paste + 5 deal pending
**Output:** 5-bullet briefing 180 คำ · จัดเวลาเช้า/บ่าย/defer · ใช้เวลาอ่าน 45 วินาที
**Time saved:** อ่านเอง 25-40 นาที/เช้า · briefing 30 วินาที

## Next step
→ ใช้ prompt P3-02 (@agent direct task format) เพื่อสั่งงานต่อจาก briefing แบบ shortcut


---

---
title: "P3-02 — @agent direct task format"
tier: starter
phase: 3
slug: p3-02-agent-direct-task
prereqs: [p2-01-sale-agent-owner]
useCase: "เรียนรู้รูปแบบ @agent <task> shortcut + 3 variant: single-agent / multi-agent CC / agent-handoff — ใช้สั่งงานเร็วโดยไม่ต้องอธิบาย context ซ้ำ"
timeToSetup: "ไม่ต้อง setup — เป็น syntax pattern ที่ใช้ได้ทันที"
checkGate:
  - "คุณมี agent อย่างน้อย 1 ตัวใน ./agents/ แล้วใช่มั้ย? (เช่น sale-team-leader.md จาก P2-01)"
  - "คุณรู้ชื่อ agent ที่จะเรียก (filename ไม่รวม .md) ใช่มั้ย?"
  - "คุณเข้าใจว่า @agent ใน prompt = บอก Claude Code ให้ใช้ context จาก agent file นั้นเป็น primary system prompt ใช่มั้ย?"
workedExample:
  industry: "Service-based SME (15 employees · 35M revenue · digital marketing agency)"
  scenario: "เจ้าของ agency มี 3 agent (sale / content / personal-secretary) · ต้องการสั่งงานทั้ง 3 รูปแบบใน 1 วันโดยไม่พิมพ์ context ซ้ำ"
  inputs: "agent files พร้อมใช้ + 3 task ตัวอย่าง (lead เข้ามาใหม่ · plan content สัปดาห์ · ส่งต่อให้ sale ตาม secretary)"
  output: "3 prompt template พร้อม fill-in-the-blank — ใช้ได้ทุกวัน"
  timeSaved: "พิมพ์ context เต็ม 200-300 คำ/ครั้ง · @agent shortcut 20-50 คำ/ครั้ง · 10+ ครั้ง/วัน"
phaseCtaHref: "/training/p1-ai-workshop-1-day#waitlist"
phaseCtaLabel: "ต้องการให้ปันมาติดตั้งให้ทั้งทีม? → ดู P1 Public Training Waitlist"
published: 2026-04-22
---

## Use when
หลังมี agent 2+ ตัว และเริ่มเบื่อกับการพิมพ์ context ยาวทุกครั้ง

## Prerequisite
- P2-01 หรือ agent ใดๆ ใน ./agents/

## The Prompt

```
ผมต้องการเรียนรู้ pattern @agent direct task สำหรับสั่งงานเร็ว
อธิบาย 3 variant ให้ผมเห็นภาพ + ให้ template ที่ใช้ได้จริง

Variant 1 — Single agent
รูปแบบ:
  @<agent-name> <task ใน 1-2 ประโยค>

  [optional: paste data หรือ context เพิ่มข้างล่าง]

ตัวอย่าง:
  @sale-team-leader qualify lead นี้ให้หน่อย
  - ชื่อ: บริษัท ABC
  - revenue: 50M
  - pain: ลด lead time order
  - source: referral

กฎ: ห้าม agent ขอ context ซ้ำที่อยู่ใน agent file ตัวเอง — ถ้าขอ ให้ตอบกลับว่า "อ่าน ./agents/sale/sale-team-leader.md อีกรอบ"

Variant 2 — Multi-agent CC (consult parallel)
รูปแบบ:
  @<agent-1> @<agent-2> <task>

  Format ขอให้ทั้งสองตอบสั้น 3-5 บรรทัดต่อคน · highlight ตรงไหนที่เห็นต่างกัน

ตัวอย่าง:
  @sale-team-leader @content-team-leader ผมจะออก service ใหม่ราคา 30k ระยะเวลา 1 เดือน — แต่ละคนเห็นยังไง
  - sale: เห็น risk / opportunity ในแง่ pricing + funnel
  - content: เห็น angle ที่จะ market ได้

ใช้ตอน: ตัดสินใจ cross-functional ที่ต้องฟัง 2 มุมก่อน

Variant 3 — Agent handoff (sequential)
รูปแบบ:
  @<agent-1> ทำ task A → ส่งต่อให้ @<agent-2> ทำ task B → return ให้ผม

ตัวอย่าง:
  @personal-secretary ดู inbox วันนี้ → ถ้ามี lead reply ส่งต่อ @sale-team-leader ให้ qualify + ร่าง follow-up → return draft ให้ผม approve

กฎ handoff:
- agent-1 ต้องประกาศชัดว่า "ส่งต่อให้ <agent-2>" ก่อน switch context
- agent-2 ห้าม assume — ต้อง summarize สิ่งที่รับมาก่อนเริ่มงาน
- output สุดท้ายให้ผม decide เสมอ — ห้าม auto-execute (ส่ง email / นัดประชุม) โดยไม่ confirm

หลังอธิบาย 3 variant ทำ 1 อย่างเพิ่ม:
- list 3 task ที่ใช้ทั้ง 3 variant ได้ในธุรกิจของผม (อ่าน ./claude.md ก่อน) — เพื่อให้ผมลองใช้ทันที
```

## Expected output
อธิบาย 3 variant ชัด + template fill-in-the-blank + 3 task ตัวอย่างที่ตรงกับธุรกิจ (จาก claude.md)

## Worked Example
**Industry:** Service-based SME (15 employees · 35M revenue · digital marketing agency)
**Scenario:** มี 3 agent · เบื่อพิมพ์ context · ต้องการ shortcut
**Inputs:** sale + content + secretary agent files + claude.md
**Output:** 3 variant template + 3 task ตัวอย่าง (lead intake / weekly plan / handoff)
**Time saved:** context ยาว 200-300 คำ/ครั้ง · shortcut 20-50 คำ/ครั้ง · 10+ ครั้ง/วัน

## Next step
→ ใช้ prompt P3-03 (Weekly content plan via team meeting) สำหรับงาน multi-agent ที่ซับซ้อนขึ้น


---

---
title: "P3-03 — Weekly content plan via team meeting"
tier: intermediate
phase: 3
slug: p3-03-weekly-content-plan-meeting
prereqs: [p2-02-content-agent]
useCase: "ทุกวันอาทิตย์: รัน meeting ระหว่าง content agent ทั้งหมด (leader + reel writer + carousel + post writer + analyst) → ออก weekly plan 3 platform x 7 วัน"
timeToSetup: "15 นาที setup ครั้งแรก · 20-30 นาที meeting ทุกอาทิตย์"
checkGate:
  - "คุณมี agent ใน ./agents/content/ อย่างน้อย 3 ตัว (leader + 1 platform writer + analyst) ใช่มั้ย?"
  - "คุณมี ./output/content/ folder ไว้เก็บ plan ใช่มั้ย?"
  - "คุณรู้ business goal สัปดาห์นี้ (1 ประโยค) ใช่มั้ย? เช่น 'launch service ใหม่' หรือ 'warm leads ที่เก็บมา 2 เดือน'"
workedExample:
  industry: "Solo founder (1 person · 8M revenue · freelance B2B sales consultant)"
  scenario: "Solo consultant ทำ content เอง 3 platform · เคยทำแบบ ad-hoc แล้วซ้ำ topic / ลืม cross-promote · ต้องการ plan ที่ coherent"
  inputs: "content agent files + business goal สัปดาห์นี้ + paste 3 post ที่ engagement ดีล่าสุด + 1 weak topic ที่อยากเลิก"
  output: "./output/content/weekly-plan-<date>.md — 21 ช่อง (3 platform x 7 วัน) · แต่ละช่องมี: angle / hook / CTA / asset type / agent ที่จะเขียน · พร้อม 1 cross-promote thread"
  timeSaved: "วาง plan เอง 2-3 ชม./สัปดาห์ + คุณภาพไม่สม่ำเสมอ · meeting 25 นาที + agent ทำ draft ตามแผนได้เลย"
phaseCtaHref: "/training/p1-ai-workshop-1-day#waitlist"
phaseCtaLabel: "อยากเห็น pattern advanced กว่านี้? → ดู P1 Public Training Waitlist"
published: 2026-04-22
---

## Use when
ทุกวันอาทิตย์ก่อนเริ่มสัปดาห์ใหม่ · มี content agent หลายตัวและต้องการ plan ที่ coordinated

## Prerequisite
- P2-02 (content team agent setup เรียบร้อย)
- ./output/content/ folder

## The Prompt

```
ผมจะรัน weekly content meeting — ขอให้ content agent ทุกตัว join

@content-team-leader ทำหน้าที่ chair meeting
@reel-script-writer @carousel-builder @facebook-post-writer @content-analyst ทุกคน join

Business goal สัปดาห์นี้: [paste 1 ประโยค]
Top performer 3 post ล่าสุด: [paste]
Weak topic ที่อยากเลิก: [paste 1 topic]

Agenda meeting (chair บังคับ flow ตามนี้):

Round 1 — Analyst report (3 บรรทัด)
@content-analyst สรุปอะไรที่ engagement ดีและทำไม · ห้ามเกิน 3 บรรทัด

Round 2 — Theme proposal (chair-led)
@content-team-leader เสนอ weekly theme 1 อัน + sub-angle 3 อันที่ derive จาก theme
ห้ามเสนอ theme ที่ซ้ำกับ 4 สัปดาห์ก่อน (ถ้าไม่มี log ให้ระบุ)

Round 3 — Platform allocation (each writer claims slots)
@reel-script-writer claim 7 slot สำหรับ TikTok/IG Reel
@carousel-builder claim 4 slot สำหรับ IG Carousel + 3 slot Facebook image post
@facebook-post-writer claim 7 slot สำหรับ Facebook text post
แต่ละ slot ต้องระบุ: วัน · angle · hook (1 บรรทัด) · CTA · asset type

Round 4 — Cross-promote check
@content-team-leader ระบุ 1 thread ที่จะ cross-promote across 3 platform (เช่น Reel teaser → Carousel deep → FB post drive DM)

Round 5 — Conflict resolve
ถ้า 2 agent claim angle ซ้ำ chair ตัดสิน · ถ้า slot ไหนไม่มีคน claim chair assign

Output สุดท้าย:
สร้างไฟล์ ./output/content/weekly-plan-<date>.md โครง:
- Goal & theme
- Top performer + lesson learned
- 21-slot table (วัน × platform)
- Cross-promote thread
- Risk / assumption (ที่ chair flag)

กฎ:
- ห้าม writer เขียน full draft ใน meeting นี้ — meeting คือ plan เท่านั้น · draft ทำในวันนั้นๆ
- ห้าม slot ที่ไม่มี hook ชัด — chair reject แล้วให้ writer คิดใหม่
- meeting จบใน 5 round · ห้ามเกิน
```

## Expected output
./output/content/weekly-plan-<date>.md ที่มี 21 slot ครบ + theme + cross-promote thread + risk · พร้อมให้ writer แต่ละคน draft ตามแผน

## Worked Example
**Industry:** Solo founder (1 person · 8M revenue · freelance B2B sales consultant)
**Scenario:** ทำ content เอง 3 platform · ad-hoc · ลืม cross-promote
**Inputs:** content agent files + goal + 3 top post + 1 weak topic
**Output:** weekly-plan-2026-04-22.md · 21 slot · 1 cross-promote thread · 2 risk flagged
**Time saved:** plan เอง 2-3 ชม./สัปดาห์ · meeting 25 นาที

## Next step
→ ใช้ prompt P3-04 (Lead qualification pipeline) สำหรับ workflow sale ที่ parallel กับ content


---

---
title: "P3-04 — Lead qualification pipeline prompt"
tier: intermediate
phase: 3
slug: p3-04-lead-qualification-pipeline
prereqs: [p2-01-sale-agent-owner, p2-04-crm-bot-sheets]
useCase: "ป้อน raw lead input (referral / web form / DM / nametag) → Sale Agent qualify ด้วย ICP จาก claude.md → output qualified/not + reason + next-step recommendation"
timeToSetup: "10 นาที setup template ครั้งแรก · 60-90 วินาที/lead หลังจากนั้น"
checkGate:
  - "claude.md ของคุณมี ICP section ที่ระบุ revenue range / industry / team size / pain pattern แล้วใช่มั้ย? (ถ้าไม่มี ต้องเพิ่มก่อน — sale agent ต้องอ่านได้)"
  - "คุณมี ./agents/sales/sale-team-leader.md จาก P2-01 แล้วใช่มั้ย?"
  - "คุณรู้ next-step ที่ใช้บ่อย (เช่น discovery call / send case study / referral nurture / decline politely) — list ไว้ใน claude.md หรือยัง?"
workedExample:
  industry: "Manufacturing SME (40 employees · 80M revenue · ขายอะไหล่รถบรรทุก)"
  scenario: "เจ้าของได้ lead จาก 5 ช่องทาง/สัปดาห์ · เคย qualify เอง 15 นาที/lead · บางครั้งคุยลูกค้าที่ไม่ fit ICP เลยเสียเวลา 2 ชม./คน"
  inputs: "raw lead text (paste 1 lead จากการ chat ใน LINE) + claude.md ICP section + sale-team-leader.md"
  output: "Verdict (qualified / not / borderline) + 3 reason ที่ map กับ ICP criteria + next-step recommendation 1 อัน + draft message 3-4 บรรทัดสำหรับ next-step"
  timeSaved: "qualify เอง 15 นาที/lead · agent 60 วินาที + draft message พร้อมส่ง"
phaseCtaHref: "/training/p1-ai-workshop-1-day#waitlist"
phaseCtaLabel: "อยากเห็น pattern advanced กว่านี้? → ดู P1 Public Training Waitlist"
published: 2026-04-22
---

## Use when
ทุกครั้งที่มี lead เข้ามา · ก่อนตัดสินใจว่าจะนัดคุย / ส่ง case study / decline

## Prerequisite
- P2-01 (sale-team-leader.md)
- P2-04 (CRM bot — สำหรับบันทึกผล qualification ลง sheet)
- claude.md ที่มี ICP + next-step list ครบ

## The Prompt

```
@sale-team-leader qualify lead นี้ตาม ICP ของผม

Step 1 — อ่าน context
อ่าน 2 ไฟล์ก่อนเริ่ม:
- ./claude.md section "ICP" + "Next-step playbook"
- ./agents/sales/sale-team-leader.md section "Qualification rules"
ห้าม assume — ถ้า ICP ไม่ชัดในจุดใด ถามผมก่อน 1 รอบ

Step 2 — Parse raw lead
Raw lead:
[paste lead text — เช่น chat log / web form / nametag note]

Extract 6 field (ถ้าหาไม่เจอใน raw ให้เขียน "unknown" — ห้ามเดา):
- ชื่อ + ตำแหน่ง
- บริษัท + industry
- revenue (ถ้ามี) หรือ team size
- pain ที่ระบุ
- timeline / urgency signal
- source / referrer

Step 3 — ICP match scoring
Map กับ ICP criteria แต่ละข้อ — score 3 ระดับ:
- Match (ตรงทุกอย่าง)
- Partial (ตรงบางส่วน · ระบุข้อที่ตรง/ไม่ตรง)
- Mismatch (ไม่ตรง · ระบุเหตุผล)
ห้ามใช้ตัวเลข % — ใช้คำ 3 ระดับนี้เท่านั้น

Step 4 — Verdict
ออก verdict 1 ใน 3:
- ✅ Qualified — match ICP เต็ม · ควรนัดคุย
- ⚠️ Borderline — partial · ต้อง discovery สั้นก่อนตัดสิน
- ❌ Not qualified — mismatch · decline politely

ระบุ 3 reason ที่ support verdict — แต่ละ reason ต้อง quote ICP criterion จริง

Step 5 — Next-step recommendation
เลือก 1 next-step จาก list ใน claude.md "Next-step playbook"
ถ้า playbook ไม่มี option ที่เหมาะ ให้ flag "ต้องเพิ่ม next-step ใน claude.md: <ชื่อ>"

Step 6 — Draft message
ร่าง message 3-4 บรรทัด สำหรับ next-step ที่เลือก · tone ตาม claude.md Voice section · ไม่ commit เวลา (ปล่อยให้ผม fill)

กฎสุดท้าย:
- ห้าม flag qualified ถ้า revenue/team size ยัง "unknown" — ต้อง flag borderline แล้ว recommend discovery
- ห้าม draft message ที่ promise outcome หรือ refund (ดู Forbidden Patterns ใน claude.md)
- หลังเสร็จ ถามผม: "บันทึก lead นี้ลง CRM sheet มั้ย?" (ถ้าตอบ yes → handoff ให้ @crm-bot)
```

## Expected output
6-field extract + ICP match table + verdict + 3 reason + 1 next-step + draft message · พร้อม handoff CRM

## Worked Example
**Industry:** Manufacturing SME (40 employees · 80M revenue · อะไหล่รถบรรทุก)
**Scenario:** Lead 5/สัปดาห์ · เสียเวลากับลูกค้า not-fit
**Inputs:** raw chat lead + claude.md ICP + sale agent
**Output:** verdict "Borderline" + 3 reason quote ICP + next-step "discovery 20-min" + draft 3-line message
**Time saved:** qualify เอง 15 นาที/lead · agent 60 วินาที

## Next step
→ ใช้ prompt P3-05 (Multi-agent strategic planning) สำหรับ session รายเดือนที่ scale ขึ้น


---

---
title: "P3-05 — Multi-agent strategic planning session"
tier: advanced
phase: 3
slug: p3-05-multi-agent-strategic-planning
prereqs: [p2-07-orchestrator-router]
useCase: "ทุกต้นเดือน: dept head ทุกตัว generate 30-day strategy ร่วมกัน · cross-functional input · ออกเอกสาร 1 ฉบับ"
timeToSetup: "30 นาที setup ครั้งแรก · 60-90 นาที session/เดือน"
checkGate:
  - "คุณมี orchestrator agent จาก P2-07 + dept head อย่างน้อย 3 ตัว (sale / content / operations) ใช่มั้ย?"
  - "คุณมี ./output/strategy/ folder + เดือนก่อนหน้าจริง (ผล จริง vs target) พร้อม paste ใช่มั้ย?"
  - "คุณรู้ business goal Q ปัจจุบัน + 1 strategic question ที่อยากให้ทีมตอบ ใช่มั้ย?"
workedExample:
  industry: "Service-based SME (15 employees · 35M revenue · digital marketing agency)"
  scenario: "เจ้าของ agency ทำ planning meeting รายเดือนกับ dept head 3 คน · ใช้เวลา 4 ชม. + เอกสาร 5 ฉบับกระจาย · อยาก compress + structured"
  inputs: "orchestrator + 3 dept head agent + Q goal + 1 strategic question (เช่น 'จะ retain client เพิ่ม 20% ทำยังไง') + เดือนก่อน actual vs target"
  output: "./output/strategy/2026-04-strategy.md — 1 ฉบับ · 6 section: Q recap / cross-functional analysis (ทุก head ตอบ) / 3 strategic option / 1 recommended option + reason / 30-day execution plan / risk + mitigation"
  timeSaved: "meeting จริง 4 ชม. + เขียน notes + กระจาย action 2 ชม. = 6 ชม./เดือน · session AI 90 นาที + เอกสารพร้อม"
phaseCtaHref: "/training/p1-ai-workshop-1-day#waitlist"
phaseCtaLabel: "ใช้ pattern นี้ใน workshop → ดู P1 Public Training Waitlist"
published: 2026-04-22
---

## Use when
ทุกต้นเดือนหรือเมื่อต้องตัดสินใจ strategic ที่ต้องฟัง 3+ มุม

## Prerequisite
- P2-07 (orchestrator-router agent)
- Dept head agent อย่างน้อย 3 ตัว
- ./output/strategy/ folder + actual vs target เดือนก่อน

## The Prompt

```
@orchestrator-router รัน strategic planning session สำหรับเดือนใหม่

Context:
- Business goal Q ปัจจุบัน: [paste 1-2 ประโยค]
- Strategic question ที่ต้องตอบ: [paste 1 question]
- เดือนก่อน actual vs target: [paste table หรือ bullet]

Orchestrator task — รัน session 6 round ตามลำดับ · บังคับ flow ห้ามข้าม:

Round 1 — Recap (orchestrator-led, 5 บรรทัด)
สรุปเดือนก่อน · highlight 1 win + 1 miss + 1 surprise
ห้ามเกิน 5 บรรทัด

Round 2 — Cross-functional analysis
เรียก dept head ทุกตัว ทีละคน (sale → content → operations) ตอบ strategic question จากมุมตัวเอง
แต่ละคนต้อง:
- อ่าน claude.md + agent file ของตัวเอง
- ตอบ 4 บรรทัด: 1 observation จากเดือนก่อน · 1 opportunity · 1 risk · 1 ask จาก dept อื่น

Round 3 — Conflict + synergy mapping
@orchestrator-router สรุป:
- Conflict ที่เห็นระหว่าง dept (เช่น sale ขอ content แบบ A · content คิดว่าควรทำ B)
- Synergy ที่เห็น (โอกาส cross-functional)
ห้ามเกิน 6 bullet

Round 4 — 3 strategic option
จาก analysis · เสนอ 3 option ที่ตอบ strategic question
แต่ละ option ต้องมี:
- ชื่อ option
- ใช้ resource จาก dept ไหน (ระบุ %)
- expected outcome (วัดได้)
- assumption ที่ต้องเป็นจริง

Round 5 — Recommend 1 option
@orchestrator-router เลือก 1 option + เหตุผล 3 ข้อ · ระบุว่า dept ไหน disagree (ถ้ามี)
ผมต้อง confirm ก่อน round 6 — รอผมพิมพ์ "ไป" หรือ "เปลี่ยน option"

Round 6 — 30-day execution plan
หลังผม confirm · break option เป็น weekly milestone (week 1-4)
แต่ละ week ระบุ: dept owner / deliverable / decision gate / risk ที่ต้อง watch

Output สุดท้าย:
สร้าง ./output/strategy/<YYYY-MM>-strategy.md โครงตาม 6 round

กฎ:
- ห้าม dept head ตอบ round 2 โดยไม่อ่าน agent file ตัวเอง
- ห้ามเลือก option ที่ใช้ resource เดียวกัน 100% (ขัด multi-functional ของ session)
- หลัง execution plan ออก orchestrator ต้อง flag 1 metric ที่จะ track ทุกสัปดาห์ (ไม่ใช่รายเดือน)
```

## Expected output
./output/strategy/<YYYY-MM>-strategy.md ที่มี 6 section ครบ + 1 weekly metric ที่ track ได้

## Worked Example
**Industry:** Service-based SME (15 employees · 35M revenue · digital marketing agency)
**Scenario:** Planning meeting 4 ชม./เดือน · เอกสารกระจาย · ต้องการ compress
**Inputs:** orchestrator + 3 dept head + Q goal + strategic question + เดือนก่อน actual
**Output:** 2026-04-strategy.md · 6 section · 1 weekly KPI · weekly milestone 4 week
**Time saved:** meeting + notes + action distribution 6 ชม. · session AI 90 นาที

## Next step
→ ใช้ prompt P4-01 (Monthly agent audit) เพื่อ tune agent ที่ใช้ใน session นี้


---

---
title: "P4-01 — Monthly agent performance audit"
tier: intermediate
phase: 4
slug: p4-01-monthly-agent-audit
prereqs: [p1-02-claude-md-interview]
useCase: "ทุกสิ้นเดือน: audit output quality ของแต่ละ agent ใน 30 วันที่ผ่านมา · identify drift / improvement idea / agent ที่ควร deprecate"
timeToSetup: "20 นาที setup ครั้งแรก · 45-60 นาที audit/เดือน"
checkGate:
  - "คุณมี agent อย่างน้อย 3 ตัวที่ใช้จริง 30+ วัน ใช่มั้ย?"
  - "คุณมี ./output/ folder ที่เก็บงานจริงที่ agent generate (proposal / content / brief / etc.) ใช่มั้ย?"
  - "คุณพร้อมจะ deprecate agent ที่ไม่ได้ใช้แล้วใช่มั้ย? (ห้าม keep ทุกตัวเพราะเสียดาย)"
workedExample:
  industry: "Solo founder (1 person · 8M revenue · freelance B2B sales consultant)"
  scenario: "Solo มี 6 agent · ใช้จริง 4 ตัว · 1 ตัวเริ่ม drift (proposal voice เพี้ยน) · 1 ตัวไม่เคยใช้เลย · ต้องการ audit เพื่อตัดสินใจ"
  inputs: "list 6 agent + ./output/ ที่ agent generate ใน 30 วัน + claude.md baseline + 2-3 feedback ที่เคยให้ agent"
  output: "./output/audits/agent-audit-<YYYY-MM>.md — table 6 agent x 4 metric (usage count / output quality / drift signal / value delivered) + verdict (keep-as-is / tune / deprecate) + 3 specific improvement"
  timeSaved: "audit เอง 4-5 ชม. (อ่าน output + เปรียบเทียบ + judgment) · session 60 นาที + เอกสารพร้อม decision"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "อยากเห็น pattern advanced กว่านี้? → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
ทุกสิ้นเดือน · agent stack เริ่มเยอะและบางตัวอาจ drift / ไม่ได้ใช้

## Prerequisite
- claude.md baseline (เพื่อเทียบ agent voice + behavior)
- ./output/ ที่มีงานจริง 30 วัน
- list agent ครบ

## The Prompt

```
ผมต้องการ audit agent ทั้งหมดของผมในรอบเดือน

Step 1 — Inventory
List agent ทุกตัวใน ./agents/ — group ตาม folder (sales / content / operations / ฯลฯ)
สำหรับแต่ละ agent ดึง 3 ข้อ:
- Last modified date
- Lines of code (ตัวเลข approximate)
- Has-been-used signal (เจอ output ใน ./output/ ที่ generate โดย agent นี้มั้ย — yes/no)

Step 2 — Sample output review
สำหรับ agent ที่ used = yes · pick 3 sample output ล่าสุดจาก ./output/
อ่านแต่ละ sample + เทียบกับ:
- claude.md Voice section
- agent file ตัวเอง (Quality gate / Boundaries section)
- ใน sample เจอ behavior อะไรที่ละเมิด rule บ้าง

Step 3 — 4-metric scoring
สร้าง table — 1 row ต่อ agent · 4 column:
- Usage (heavy / occasional / unused) — based on output count
- Output quality (consistent / variable / declining) — based on sample review
- Drift signal (none / minor / major) — เทียบกับ baseline
- Value delivered (high / medium / unclear) — ตอบคำถาม "ถ้าไม่มี agent นี้ ผมเสียอะไร"

Step 4 — Verdict + reason
ออก verdict 1 ใน 3 ต่อ agent:
- Keep-as-is — ทำงานดี · ไม่ต้องแตะ
- Tune — มีปัญหาเล็ก · ระบุ tune อะไรเฉพาะเจาะจง (เช่น "เพิ่ม forbidden word ใน Boundaries: ขับเคลื่อน, ตอบโจทย์ทุก")
- Deprecate — ไม่ได้ใช้ / value ไม่ชัด · move ไป ./agents/_deprecated/

ห้าม "keep all" เพราะเสียดาย · ถ้า unused 60+ วัน → deprecate

Step 5 — 3 improvement
จาก audit · เลือก 3 improvement ที่ impact สูงสุด · ระบุ:
- Agent ไหน
- Change อะไร (เฉพาะเจาะจง · paste section ที่จะเขียนใหม่)
- Expected effect

Step 6 — Save audit
สร้าง ./output/audits/agent-audit-<YYYY-MM>.md โครง:
- Inventory table
- Sample review notes
- 4-metric table
- Verdict per agent
- 3 improvement
- Action item (ผมต้องทำอะไรในสัปดาห์หน้า)

กฎ:
- ห้าม audit agent ที่ deploy < 30 วัน (data ไม่พอ)
- ห้ามให้ verdict โดยไม่ quote sample จริง
- ทุก "tune" ต้องมี diff text ที่ผม copy-paste ลง agent file ได้เลย
```

## Expected output
./output/audits/agent-audit-<YYYY-MM>.md + 3 improvement พร้อม diff + verdict ครบทุก agent

## Worked Example
**Industry:** Solo founder (1 person · 8M revenue · freelance B2B sales consultant)
**Scenario:** มี 6 agent · 4 ตัวใช้จริง · 1 ตัว drift · 1 ตัวไม่ใช้
**Inputs:** 6 agent + ./output/ 30 วัน + claude.md baseline
**Output:** audit-2026-04.md · 6-row table · 1 deprecate + 2 tune + 3 keep · 3 improvement พร้อม diff
**Time saved:** audit เอง 4-5 ชม. · session 60 นาที

## Next step
→ ใช้ prompt P4-02 (Automation gate) เพื่อตัดสินว่า agent task ไหนควร upgrade เป็น n8n


---

---
title: "P4-02 — Automation gate: agent → n8n workflow"
tier: advanced
phase: 4
slug: p4-02-automation-gate-n8n
prereqs: [p4-01-monthly-agent-audit]
useCase: "Decision matrix: task ไหนของ agent ที่ควร upgrade เป็น n8n scheduled workflow · criteria: frequency / time saved / risk / maintainability"
timeToSetup: "45 นาที setup + 1-3 ชม. build n8n workflow (ถ้าผ่าน gate)"
checkGate:
  - "คุณมี audit รายเดือนจาก P4-01 พร้อม list agent task ที่ 'heavy usage' ใช่มั้ย?"
  - "คุณมี n8n instance (cloud หรือ self-host) ที่ login ได้ใช่มั้ย?"
  - "คุณเข้าใจว่า n8n automation = deterministic (no LLM in critical path ถ้าเป็นไปได้) ต่างจาก agent = judgment-based ใช่มั้ย?"
workedExample:
  industry: "Manufacturing SME (40 employees · 80M revenue · ขายอะไหล่รถบรรทุก)"
  scenario: "เจ้าของมี 5 agent task heavy · 3 ใน 5 = repetitive (lead routing / invoice reminder / daily KPI dump) · ต้องการตัดสินว่าอันไหนควรย้ายไป n8n · อันไหนยังให้ agent ทำต่อ"
  inputs: "list 5 heavy task + audit from P4-01 + n8n instance URL + sample data ของแต่ละ task"
  output: "./output/automation/gate-matrix-<YYYY-MM>.md — 5-row table × 4 criteria (frequency / time saved / risk / maintainability) + verdict (n8n / keep agent / hybrid) + สำหรับ task ที่ผ่าน gate: n8n workflow spec (trigger / nodes / credential / error handling)"
  timeSaved: "task repetitive ถ้ายังให้ agent ทำ = 10-15 นาที/ครั้ง · n8n = 0 นาที (scheduled) · scale linearly ตาม frequency"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "ใช้ pattern นี้ใน workshop → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
หลัง P4-01 audit และพบ agent task ที่ heavy + repetitive · ก่อน build n8n workflow

## Prerequisite
- P4-01 audit ล่าสุด
- n8n instance พร้อม
- เข้าใจ agent vs n8n decision

## The Prompt

```
ผมมี agent task ที่ heavy usage — ต้องการตัดสินว่าควร upgrade เป็น n8n มั้ย

Step 1 — Inventory candidates
List task ที่มาจาก P4-01 audit — group ตาม agent owner
สำหรับแต่ละ task ดึง 5 field:
- Task name
- Current agent owner
- Frequency (per day / week / month)
- Avg time/run (นาที)
- Input source (manual paste / file / external API / email)

Step 2 — 4-criteria gate
สำหรับแต่ละ task ให้ score 4 criteria — ใช้ 3 ระดับ (high / medium / low):
- Frequency — ≥1/วัน = high · 1-5/สัปดาห์ = medium · <1/สัปดาห์ = low
- Time saved — ≥10 นาที/run = high · 3-10 นาที = medium · <3 นาที = low
- Risk if automated — deterministic logic + low-stakes = low risk · judgment-required or customer-facing = high risk
- Maintainability — stable schema/endpoint = high · frequently changing format = low

Step 3 — Verdict logic (บังคับตาม rule นี้)
- n8n ถ้า: Frequency ≥ medium · Time saved ≥ medium · Risk = low · Maintainability ≥ medium
- Keep agent ถ้า: Risk = high (judgment-required) หรือ Maintainability = low (schema เปลี่ยนบ่อย)
- Hybrid ถ้า: task มี deterministic part + judgment part — n8n handle deterministic · agent handle judgment · ระบุ handoff point

ห้าม auto-pick "n8n" เพียงเพราะ frequency สูง ถ้า risk = high

Step 4 — Spec task ที่ผ่าน gate
สำหรับ verdict = n8n หรือ hybrid · เขียน spec:
- Trigger (schedule / webhook / manual / email)
- Node sequence (ระบุ node type — ห้ามลึก config ตอนนี้)
- Credential ที่ต้อง setup (ระบุ list)
- Error handling (ถ้า step ไหน fail ให้ทำอะไร — retry / notify / fallback to agent)
- Success metric (จะวัดยังไงว่า workflow ทำงานถูก)

ห้าม generate workflow JSON ตอนนี้ — spec อย่างเดียว · build จะทำใน step ถัดไป

Step 5 — Hand-off instruction
สำหรับ task ที่ verdict = hybrid ระบุชัด:
- n8n ทำอะไรถึงจุดไหน
- agent รับต่อตอนไหน + รับ input อะไร
- ใครเป็น "source of truth" ถ้า 2 ฝั่งให้ผลไม่ตรง

Step 6 — Save
สร้าง ./output/automation/gate-matrix-<YYYY-MM>.md โครง:
- Inventory table
- 4-criteria matrix
- Verdict per task
- Spec สำหรับ task ที่ผ่าน gate
- Build priority (เริ่ม task ไหนก่อน — ดู time-saved × frequency)
```

## Expected output
./output/automation/gate-matrix-<YYYY-MM>.md + spec พร้อม build + build priority order

## Worked Example
**Industry:** Manufacturing SME (40 employees · 80M revenue · อะไหล่รถบรรทุก)
**Scenario:** 5 heavy task · 3 repetitive · ต้องการ gate
**Inputs:** audit P4-01 + 5 task list + n8n URL + sample data
**Output:** gate-matrix-2026-04.md · 3 task → n8n · 1 → keep agent · 1 → hybrid · spec 4 workflow
**Time saved:** task repetitive 10-15 นาที/ครั้ง → 0 นาที หลัง n8n deploy

## Next step
→ ใช้ prompt P4-03 (MCP integration) เพื่อ integrate tool ภายนอกเข้า agent stack


---

---
title: "P4-03 — MCP server integration pattern"
tier: advanced
phase: 4
slug: p4-03-mcp-integration
prereqs: [p2-07-orchestrator-router]
useCase: "ติดตั้ง + ใช้ MCP server สำหรับ external tool (Slack / Notion / Google Drive / Gmail / etc.) · ครอบคลุม config + agent integration + safety"
timeToSetup: "30-60 นาที/MCP ครั้งแรก · 5-10 นาทีต่อ MCP เพิ่ม"
checkGate:
  - "คุณรู้ว่าจะ integrate tool อะไร + มี account/credential พร้อมแล้วใช่มั้ย?"
  - "คุณรู้ว่า MCP token cost สูง (~18,000 token/MCP/message) ใช่มั้ย? — บังคับ MCP hygiene (เปิดเฉพาะที่ใช้)"
  - "คุณมี agent ใน ./agents/ ที่จะใช้ MCP นี้อยู่แล้วใช่มั้ย? (ถ้ายังไม่มี ต้อง spawn ก่อนผ่าน P2-06)"
workedExample:
  industry: "Service-based SME (15 employees · 35M revenue · digital marketing agency)"
  scenario: "Agency ใช้ Notion เป็น client workspace · ต้องการให้ content agent อ่าน brief + เขียน draft กลับ Notion โดยตรง · ไม่ต้อง copy-paste"
  inputs: "Notion API credential + list 3 use case (อ่าน brief / update status / เขียน draft) + content agent ที่จะใช้ MCP"
  output: "./mcp/notion-config.md (config + credential placement) + updated ./agents/content/<agent>.md (เพิ่ม MCP section + safety rule) + smoke test prompt 3 ตัว"
  timeSaved: "copy-paste Notion ↔ Claude Code 5-10 นาที/task · MCP 0 นาที (direct) · ลด error จาก manual copy"
phaseCtaHref: "/services/ai-workshop"
phaseCtaLabel: "ใช้ pattern นี้ใน workshop → ดู In-House Workshop"
published: 2026-04-22
---

## Use when
มี agent ที่ต้องอ่าน/เขียนข้อมูลจาก external tool บ่อย · copy-paste เป็น bottleneck

## Prerequisite
- P2-07 (orchestrator เพื่อ manage MCP routing)
- Account + credential ของ tool พร้อม
- เข้าใจ MCP hygiene (token cost)

## The Prompt

```
ผมต้องการ integrate MCP server สำหรับ [ชื่อ tool — เช่น Notion / Slack / Gmail]

Step 1 — Scope check
ถามผม 3 คำถาม ก่อนเริ่ม install:
- 3 use case หลักที่จะใช้ MCP นี้คืออะไร (ต้อง concrete · ห้ามตอบ "integrate ทุกอย่าง")
- Agent ตัวไหนจะใช้ MCP นี้ (1-3 ตัว · ห้ามให้ทุก agent เข้าถึง)
- Sensitivity ของ data ที่จะ touch (public / internal / confidential) — ถ้า confidential ต้องมี Boundaries เพิ่ม

ห้ามไปต่อ step 2 ถ้า 3 ข้อยังตอบไม่ครบ

Step 2 — Install + config
Research MCP server official (ถ้าเป็น Anthropic maintained list)
สร้าง ./mcp/<tool-name>-config.md ที่มี:
- Install command (ระบุ exact command · ห้าม pseudocode)
- Credential placement (ระบุ path · ห้าม hardcode ในไฟล์ agent)
- Scopes ที่ request — ขั้นต่ำเท่าที่จำเป็น (least privilege)
- Test command ที่จะยืนยันว่า install สำเร็จ

ถ้า MCP server ไม่มี official ให้ flag "ต้องใช้ community server หรือ build เอง" + ระบุ risk

Step 3 — Agent integration
เปิด agent file ที่จะใช้ (ตามคำตอบ step 1)
เพิ่ม 3 section:
- MCP access — ระบุชื่อ MCP server + scope
- Usage pattern — 3 use case จาก step 1 · แต่ละ use case เขียน prompt template
- Safety rules — ตามระดับ sensitivity:
  * public: ห้าม write operation โดยไม่ confirm กับ user
  * internal: ห้าม share data กับ agent ตัวอื่น โดยไม่ confirm
  * confidential: ห้าม write เลย · read-only · และห้าม quote content เต็มใน chat (summary เท่านั้น)

Step 4 — MCP hygiene rule
เพิ่มใน ./claude.md section "MCP Hygiene":
- MCP นี้เปิดเมื่อไหร่ (ระบุ session type — ห้ามเปิดตลอด)
- ต้อง disconnect เมื่อไหร่
- ใช้ token เท่าไหร่ estimate

Step 5 — Smoke test
เขียน 3 prompt test — 1 ต่อ use case จาก step 1
แต่ละ prompt ต้อง:
- เรียก @agent ที่ setup
- Execute use case บน sample data จริง (ห้ามใช้ mock)
- ยืนยันว่า output ถูกต้อง (มี checklist 3 ข้อต่อ test)

Step 6 — Rollback plan
ระบุวิธี disable MCP ถ้าเจอปัญหา:
- Command disconnect
- วิธี revoke credential
- วิธี clean ข้อมูลที่ MCP write ไว้ (ถ้ามี)

กฎ:
- ห้าม install MCP ที่ไม่มี rollback plan
- ห้ามให้ agent ทำ destructive operation (delete / overwrite) โดยไม่ confirm
- ถ้า MCP fail ระหว่าง task agent ต้อง fallback เป็น manual instruction (paste link / ให้ผม copy เอง) · ห้าม silent fail
```

## Expected output
./mcp/<tool>-config.md + updated agent file + claude.md MCP Hygiene entry + 3 smoke test ที่ pass + rollback plan

## Worked Example
**Industry:** Service-based SME (15 employees · 35M revenue · digital marketing agency)
**Scenario:** ใช้ Notion เป็น client workspace · ต้องการ agent อ่าน/เขียนตรง
**Inputs:** Notion credential + 3 use case + content agent
**Output:** notion-config.md + content agent อัปเดต + claude.md MCP Hygiene + 3 smoke test pass
**Time saved:** copy-paste 5-10 นาที/task · MCP direct 0 นาที · ลด manual error

## Next step
→ กลับไปที่ P3-05 (Strategic planning) เพื่อรวม MCP data ใหม่เข้า monthly decision


---

*End — 20 prompts · agent-builder-kit v1*
