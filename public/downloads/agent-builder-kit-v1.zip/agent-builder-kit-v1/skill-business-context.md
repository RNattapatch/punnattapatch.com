# Business Context Interview Skill
**กระบวนการสร้างไฟล์ `claude.md` เพื่อให้ Claude รู้จักธุรกิจของคุณ**

## Purpose

The primary goal is to run a structured interview to build a personalized `claude.md` file. This file acts as Claude's "brain," providing essential context about your business, goals, and style.

This skill is initiated by The Architect when a user's business context needs to be established for the first time.

Output: A complete, ready-to-use `claude.md` file saved to the project root.

---

## Activation Triggers

This skill activates under the following conditions:
- The Architect routes the user here for initial context setup.
- The user expresses intent to set up their business profile, using phrases like "สร้าง claude.md", "ตั้งค่าธุรกิจ", or "แนะนำธุรกิจให้ Claude รู้จัก".
- No `claude.md` file currently exists in the project's root folder.

---

## Pre-Interview: Initial User Verification

Before the main interview, verify the `USER_TYPE` detected by The Architect. This context is crucial for tailoring the questions. If the user type is unknown, begin with this question:

```
สวัสดีครับ
ก่อนที่เราจะเริ่มกัน ขอสอบถามก่อนว่าบทบาทของคุณคืออะไรครับ:

  1. **เจ้าของธุรกิจ / CEO / กรรมการผู้จัดการ** (OWNER)
  2. **Manager / หัวหน้าฝ่าย / พนักงาน** (MANAGER)

ตอบ 1 หรือ 2
```

Store the response as `USER_TYPE = OWNER | MANAGER` to adapt the subsequent interview phases and downstream skills.

---

## Interview Protocol

The interview follows a 5-phase protocol. Conduct each phase sequentially, waiting for the user's response before proceeding to the next. Do not present all questions at once.

Begin with this opening message before starting Phase 1:
```
เยี่ยมเลยครับ/ค่ะ
เดี๋ยวผม/ดิฉันจะชวนคุย 5 หัวข้อสั้นๆ นะครับ/คะ เพื่อให้รู้จักธุรกิจของคุณมากขึ้น
แต่ละหัวข้อใช้เวลาไม่เกิน 2-3 นาที ตอบตามความจริงได้เลย ไม่ต้องเรียบเรียงให้สวยงามครับ/ค่ะ

พร้อมแล้วเรามาเริ่มกันเลย!
```

---

### Phase 1: Your Identity & Role

Ask all users:
```
Phase 1: ตัวตนและบทบาท

1. แบรนด์/บริษัท หรือชื่อที่คุณใช้ในการทำงานคืออะไรครับ/คะ?
2. คุณอยู่ในอุตสาหกรรมหรือสายงานไหน?
3. ช่วยอธิบายภาพรวมของงานที่ทำในปัจจุบัน (1-2 ประโยค)
```

**Custom Questions by Role:**
- **Employee**: เพิ่ม "แผนกและตำแหน่งงานของคุณในบริษัทคืออะไร?"
- **Freelance**: เพิ่ม "คุณเชี่ยวชาญและรับงานประเภทไหนเป็นหลัก?"
- **Solopreneur**: เพิ่ม "แบรนด์ของคุณชื่อว่าอะไร และใช้ Handle ไหนบนโซเชียลมีเดีย?"

---

### Phase 2: Target Audience & Market Positioning

Ask all users:
```
Phase 2: กลุ่มเป้าหมายและลูกค้า

1. ใครคือคนกลุ่มหลักที่ได้ประโยชน์จากงานของคุณโดยตรง?
2. อะไรคือปัญหาหรือความท้าทายหลักที่คนกลุ่มนี้เจอ?
3. อะไรคือจุดเด่นที่ทำให้คุณแตกต่างจากคู่แข่ง หรือคนอื่นๆ ในตลาด?
```

**Custom Questions by Role:**
- **Employee**: ข้อ 1 → "ใครคือ Stakeholder หลัก หรือผู้ที่นำผลงานของคุณไปใช้ต่อ?"
- **Freelance**: เพิ่ม "ลูกค้าในอุดมคติของคุณมีลักษณะอย่างไร? (เช่น ขนาดบริษัท, อุตสาหกรรม, งบประมาณ)"
- **Solopreneur**: เพิ่ม "กลุ่มเป้าหมายหลักของ Content หรือ Product ของคุณคือใคร?"

---

### Phase 3: Expertise & Working Style

Ask all users:
```
Phase 3: ความเชี่ยวชาญและสไตล์การทำงาน

1. ทักษะหรือความเชี่ยวชาญหลัก (Core Skills) ของคุณคืออะไร?
2. สไตล์การทำงานของคุณเป็นแบบไหน? (เช่น ชอบวิเคราะห์ข้อมูล, ลงมือทำเร็ว, หรือทำงานร่วมกับทีม)
3. ขอบเขตงาน: อะไรที่คุณ "ไม่ทำ" หรือไม่รับ?
```

**Custom Questions by Role:**
- **Employee**: เพิ่ม "เครื่องมือ (Software/Tools) ที่คุณใช้ในการทำงานเป็นประจำมีอะไรบ้าง?"
- **Freelance**: เพิ่ม "ขั้นตอนการทำงานและส่งมอบงานให้ลูกค้าของคุณเป็นอย่างไร?"
- **Business Owner**: เพิ่ม "วัฒนธรรมหรือสไตล์การทำงานที่คุณต้องการสร้างในทีมเป็นแบบไหน?"

---

### Phase 4: Persona-Specific Fork

Phase 4 branches based on `USER_TYPE` captured in the Pre-Interview step.

**For `USER_TYPE: OWNER`** — ask about the business model and revenue engine:
```
Phase 4: โมเดลธุรกิจและรายได้

1. สินค้าหรือบริการหลักที่คุณขายคืออะไร? (ระบุชื่อและช่วงราคา)
2. ช่วงรายได้ปัจจุบันเป็นอย่างไร และเป้าหมายรายได้ที่ต้องการไปให้ถึงคือเท่าไหร่?
3. ช่องทางหลักที่ลูกค้าใช้ค้นหาและติดต่อคุณคือช่องทางไหน?
```

**For `USER_TYPE: MANAGER`** — ask about the role, team, and weekly routine:
```
Phase 4: บทบาทและงานประจำ

1. คุณอยู่แผนกอะไร? ตำแหน่งอะไร? ทีมในแผนกมีกี่คน?
2. งาน Routine ในแต่ละสัปดาห์ที่คุณต้องทำซ้ำๆ มีอะไรบ้าง?
3. Output ที่คุณสร้าง/ส่งมอบบ่อยที่สุดคืออะไร? (รายงาน · อีเมล · presentation · อื่นๆ)
4. งานส่วนไหนที่คุณอยากให้ AI ช่วยลดภาระมากที่สุด?
```

---

### Phase 5: Goals & Constraints

Ask all users:
```
Phase 5: เป้าหมายและข้อจำกัด

1. เป้าหมายสำคัญที่สุดของคุณในอีก 3-6 เดือนข้างหน้าคืออะไร?
2. อะไรคืออุปสรรคหรือความท้าทายที่ใหญ่ที่สุดในตอนนี้? (เช่น เวลา, งบ, ทักษะ, ทีมงาน)
3. มีกฎ ข้อจำกัด หรือข้อมูลสำคัญที่ AI ต้องยึดถือเป็นพิเศษไหมครับ/คะ?
   (เช่น ห้ามใช้ภาษาทางการเกินไป, ไม่รับลูกค้ากลุ่มนี้, ห้ามเปิดเผยข้อมูล X)
```

**Custom Questions by Role:**
- **Employee**: ข้อ 3 → เพิ่ม "มีนโยบายหรือข้อบังคับของบริษัทที่ AI จำเป็นต้องรู้หรือไม่?"
- **Solopreneur**: เพิ่ม "แพลตฟอร์มหลักที่คุณใช้สร้างคอนเทนต์ในตอนนี้คืออะไร? (เช่น TikTok, IG, LinkedIn, FB)"

---

## Output: `claude.md` Generation

Upon completion of all 5 phases, synthesize the user's answers to generate the `claude.md` file using the following template. Ensure every section is populated concisely from the interview data.

The `USER_TYPE: OWNER | MANAGER` line is **required** — downstream skills (sales, content, ops agents) branch on this tag.

```markdown
# CLAUDE.md — [Name / Brand Name]
*(Created: [date] | Type: [User Type])*
USER_TYPE: OWNER | MANAGER

## Identity
- Name/Brand: [answer]
- Role: [answer]
- Industry: [answer]
- Location: [if mentioned]
- Mission: [1-line summary of what they do and for whom]

## Target Audience
- Primary: [who they serve — specific, not generic]
- Pain Points: [top 2-3 problems their audience has]
- Differentiator: [how they stand out from the competition]

## Expertise & Working Style
- Core Skills: [list]
- Working Style: [answer from Phase 3]
- Does NOT do: [list from Phase 3, e.g., "no design work," "no cold calling"]

## Business Model / Role & Output
*(For MANAGER, this section is "Role & Output". For OWNER, "Business Model")*
- Services/Products: [list with prices if given]
- Revenue Goal: [answer]
- Main Channels: [answer]

## Current Goals & Constraints
- Primary Goal (3-6 Months): [answer]
- Top Obstacle: [answer, e.g., "Time management," "Lead generation"]
- Key Constraint for AI: [answer]

## Language & Tone
- Default Language: Always communicate with the user in Thai.
- Technical Output: Use English for code, filenames, and technical terms.
- Document Headers: Use English for titles and section headers in generated documents.
- Tone: [Specify a tone if mentioned, e.g., "Professional but friendly," "Direct and data-driven"]

## Core Directives & Rules
[List any explicit rules, limits, or forbidden topics from Phase 5. Be specific.]
```

---

## Delivery

After generating the file, present it to the user with this concluding message:

```
เรียบร้อยครับ/ค่ะ! ไฟล์ claude.md สำหรับคุณถูกสร้างขึ้นแล้ว

วิธีใช้งานง่ายๆ:
1. คัดลอก (Copy) ข้อความในกล่องด้านบนทั้งหมด
2. ในโปรเจกต์ Claude Code ของคุณ สร้างไฟล์ใหม่ชื่อว่า claude.md
3. วาง (Paste) เนื้อหาที่คัดลอกมาแล้วกดบันทึก (Save)

จากนี้ไป Claude จะ "รู้จักคุณ" และทำงานสอดคล้องกับธุรกิจของคุณในทุกๆ session โดยอัตโนมัติ

ยอดเยี่ยมครับ/ค่ะ! ตอนนี้ Claude พร้อมที่จะเป็นผู้ช่วยส่วนตัวของคุณแล้ว
หากต้องการสร้างทีม Agent เฉพาะทางเพิ่มเติม สามารถบอก The Architect เพื่อเริ่มขั้นตอนต่อไปได้เลย
```

---

## Core Directives

- **Do not** generate the `claude.md` file without completing all 5 interview phases.
- **Do not** skip the Pre-Interview user type verification — `USER_TYPE` must be `OWNER` or `MANAGER`.
- **Do not** make assumptions about the user's industry or business model; use only the information provided.
- If a user provides a short or vague answer, ask a single, polite clarifying question before moving on.
- The final output **must be** a complete, copy-pasteable markdown file, not a summary or description of one.
- The `USER_TYPE: OWNER | MANAGER` tag in the output template is mandatory — downstream skills depend on it for routing.
