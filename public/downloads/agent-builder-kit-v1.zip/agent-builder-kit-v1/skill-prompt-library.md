# skill-prompt-library — Prompt Library Guide

## Purpose
This skill loads the 20+ prompt library master file (`prompt-library.md` in the same folder) and teaches the user how to use the CHECK gate + worked example pattern.

## Activation
- User says "อยากใช้ prompt สำเร็จรูป" / "ขอ prompt สำหรับ <task>" / "มี prompt อะไรให้ใช้บ้าง"
- User finished skill-build-agent-team and needs templated workflows

## How to use the library

1. **Ask the user: "คุณอยู่ phase ไหน?"** (Setup / Build Team / Operate / Scale)
2. **Show tier-appropriate prompts** — 🟢 Starter if first time, 🟡 Intermediate if they have claude.md + 1 agent, 🔴 Advanced if they have 3+ agents
3. **Before giving the prompt to the user, SHOW the CHECK gate first** — let them verify prerequisites themselves
4. **If CHECK gate fails** → route back to the prerequisite prompt (each prompt has `prereqs` field)
5. **Provide the prompt copy-paste ready** — in triple-backtick block
6. **Follow up with "Run it and paste output here so I can QC"**

## Output format

```
🧠 PROMPT LIBRARY MATCH

Recommended: [slug] — [title]
Phase: [1-4] · Tier: [🟢🟡🔴]
Time to setup: [X นาที]
Prereqs: [list]

✓ CHECK ก่อนรัน prompt นี้
☐ [item 1]
☐ [item 2]
☐ [item 3]

Worked example (industry: [X])
[scenario + inputs + output + time saved]

THE PROMPT
---
[copy-paste block]
---

Next step: run the prompt, paste output here, I'll QC before you deploy.
```

## Constraints
- Never give a prompt without showing its CHECK gate first
- Never skip worked example when tier is 🟡 or 🔴
- If a prompt's `prereqs` include an agent the user hasn't built → route back to `skill-build-agent-team.md`

## Reference
Full prompt library: `prompt-library.md` (same folder) — 20+ prompts organized Phase × Tier
Schema: see `punnattapatch.com/src/content.config.ts` for canonical frontmatter
