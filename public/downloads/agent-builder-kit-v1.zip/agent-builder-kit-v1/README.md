# AI Agent Team Setup Kit — punnattapatch.com Edition

*Built by Pun Nattapatch (@pun_nattapatch) · B2B Sales Consultant + Agentic AI Transformation for Thai SMEs ฿30-200M*

## What you got

4 programs inside this zip:

1. 📕 `Manual.docx` — 50-page Hybrid Beauty+Workbook that walks you from 0 → AI Agent ที่รู้จักธุรกิจคุณ
2. ⚙️ Setup files (this README + 4 more .md files) — drop into a Claude Code project to make Claude "รู้จักคุณ"
3. 🧠 `prompt-library.md` (20+ prompts, organized 4 phase × 3 tier) — copy-paste ใช้งานจริง
4. 🎁 Bonus stack (ส่งทาง LINE ภายใน 7 วัน หลังคุณกรอกฟอร์ม) — Custom GPT "Pun's Sales OS" + 30-day LINE OA install support + Office Hours invite

## เริ่มใน 3 ขั้น (90 นาที)

### Step 0 — อ่าน Manual Part 1 (Why) ก่อน (15 นาที)
อ่าน Chapter 6 "STEP 0: Build Audit" ก่อนเลย — เช็ค 5 ข้อว่าธุรกิจพร้อม install AI agent แล้วยัง

### Step 1 — วาง 5 .md files ใน Claude Code project (5 นาที)
เปิด Claude Code (desktop app) → สร้าง project ใหม่ชื่อธุรกิจคุณ → วาง `README.md` + `the-architect.md` + `skill-business-context.md` + `skill-build-agent-team.md` + `skill-prompt-library.md` ทั้งหมดใน project root

### Step 2 — พูดกับ The Architect (15 นาที)
ใน Claude Code พิมพ์: `@the-architect ผมเพิ่ง install AI Agent Team Setup Kit กรุณา onboard ผมครับ`
The Architect จะสัมภาษณ์ 5 หัวข้อเกี่ยวกับธุรกิจคุณแล้วสร้างไฟล์ `claude.md` ให้คุณอัตโนมัติ

### Step 3 — สร้าง agent ตัวแรก (55 นาที)
เปิด `prompt-library.md` → เลือก Phase 1 · P1-01 Starter (🟢) → copy-paste prompt ไป Claude Code → ทำตาม CHECK gate ก่อนรัน → ได้ agent ตัวแรกพร้อมใช้

## ติดปัญหา?

LINE OA: `https://lin.ee/ioSnSUG` (ทักได้เลย · ปันดูทุกข้อความ Mon-Fri ภายใน 24 ชม.)

## อยากไปไกลกว่า Kit นี้?

- In-house Workshop (on-site ที่ออฟฟิศคุณ) → https://punnattapatch.com/services/ai-workshop
- Public P1 Training (1 วัน public cohort · cap 12 ที่) → https://punnattapatch.com/training/p1-ai-workshop-1-day

## Version

v1.0 — shipped 2026-04-22 · source: `product/agent-builder-kit-punnattapatch-com/` in claude-code-pun-nattapatch repo
