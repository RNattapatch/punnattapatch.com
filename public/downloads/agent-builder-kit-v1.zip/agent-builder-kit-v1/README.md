# AI Agent Team Setup Kit — punnattapatch.com Edition

*Built by Pun Nattapatch (@pun_nattapatch) · B2B Sales Consultant + Agentic AI Transformation for Thai SMEs ฿30-200M*

## What you got

4 programs inside this zip:

1. 📕 `Manual.pdf` — คู่มือครบ 4 Part: ทำไม → ติดตั้ง → Operate & Scale → Prompt Library 20 ท่า
2. ⚙️ Setup files (this README + 4 more .md files) — drop into a Claude Code project to make Claude "รู้จักคุณ"
3. 🧠 `prompt-library.md` (20+ prompts, organized 4 phase × 3 tier) — copy-paste ใช้งานจริง
4. 🎁 Bonus stack (ส่งทาง LINE ภายใน 7 วัน หลังคุณกรอกฟอร์ม) — 30-day LINE OA install support + Office Hours invite

## อ่าน Manual ออนไลน์

คู่มือมีเวอร์ชันเว็บที่อัปเดตเสมอ — เข้าได้เฉพาะ URL นี้ (ไม่มีในเมนูเว็บ):

- [Part 1 — ทำไม SME ไทยต้องสร้าง AI ทีมงาน](https://punnattapatch.com/agent-builder-kit/manual/part-1)
- [Part 2 — ติดตั้ง Claude Code + สร้างทีม AI ตัวแรก](https://punnattapatch.com/agent-builder-kit/manual/part-2)
- [Part 3 — Operate, Scale + MCP Connectors](https://punnattapatch.com/agent-builder-kit/manual/part-3)
- [Part 4 — Prompt Library 20 ท่า + Next Steps](https://punnattapatch.com/agent-builder-kit/manual/part-4)

## เริ่มใน 3 ขั้น (90 นาที)

### Step 0 — อ่าน Manual Part 1 ก่อน (15 นาที)
เปิด `Manual.pdf` (หรือ [อ่านออนไลน์](https://punnattapatch.com/agent-builder-kit/manual/part-1)) → อ่าน §6 "STEP 0: Build Audit" — เช็ค 5 ข้อว่าธุรกิจพร้อม install AI agent แล้วยัง

### Step 1 — วาง 5 .md files ใน Claude Code project (5 นาที)
เปิด Claude Code (desktop app) → สร้าง project ใหม่ชื่อธุรกิจคุณ → วาง `README.md` + `the-architect.md` + `skill-business-context.md` + `skill-build-agent-team.md` + `skill-prompt-library.md` ทั้งหมดใน project root

### Step 2 — พูดกับ The Architect (15 นาที)
ใน Claude Code พิมพ์: `@the-architect ผมเพิ่ง install AI Agent Team Setup Kit กรุณา onboard ผมครับ`
The Architect จะสัมภาษณ์ 5 หัวข้อเกี่ยวกับธุรกิจคุณแล้วสร้างไฟล์ `claude.md` ให้คุณอัตโนมัติ

### Step 3 — สร้าง agent ตัวแรก (55 นาที)
เปิด `prompt-library.md` → เลือก Phase 1 · P1-01 Starter (🟢) → copy-paste prompt ไป Claude Code → ทำตาม CHECK gate ก่อนรัน → ได้ agent ตัวแรกพร้อมใช้

## ติดปัญหา?

LINE OA: `https://lin.ee/ioSnSUG` (ทักได้เลย · ปันดูทุกข้อความ Mon-Fri ภายใน 24 ชม.)

## อยากไปไกลกว่า Kit นี้?

- In-house Workshop (on-site ที่ออฟฟิศคุณ) → https://punnattapatch.com/services/ai-workshop
- Public P1 Training (1 วัน · hands-on · max 20 ที่) → https://punnattapatch.com/training/p1-ai-workshop-1-day

## Version

v1.0 — shipped 2026-04-22 · source: `product/agent-builder-kit-punnattapatch-com/` in claude-code-pun-nattapatch repo
