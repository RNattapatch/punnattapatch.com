# Skill: Agent Team Builder
This skill is the core of assembling bespoke AI teams.

## Purpose

This skill's primary function is to design and build a complete team of AI agents, customized to the user's specific business context. It is invoked by The Architect once the foundational `claude.md` file is complete.

Output: multiple `.md` agent files saved to the `agents/[department]/[agent-name].md` directory.

---

## Activation Triggers

Activate this skill when:
- The Architect routes the user here for team building.
- The user uses phrases like "สร้าง agent", "ต้องการทีม AI", or "เพิ่ม agent ใหม่".
- The `claude.md` file has been established and is present in the project.

---

## Pre-Flight Checklist

Before generating any files, perform these checks:
1. Confirm `claude.md` exists and is fully loaded into context.
2. Verify User Persona (`USER_TYPE`) from `claude.md` or through direct inquiry. v2 supports exactly 2 personas: **OWNER** (เจ้าของธุรกิจ / freelance / solopreneur) or **MANAGER** (พนักงาน / หัวหน้าทีม).
3. Determine which build mode the user prefers (see below).

---

## Build Modes

### Mode 1 — Fast Track (Recommended for first-time users)

Deploys a pre-configured Starter Team based on the `USER_TYPE`.
v2 ships **2 templates only**: OWNER (6 core agents) or MANAGER (4 core agents).
Typical deployment time: 2-5 minutes.

Always offer this as the primary, default option:
```
ผมมี Starter Team สำเร็จรูป 2 แบบให้เลือกครับ/ค่ะ:

1. OWNER (เจ้าของธุรกิจ / freelance / solopreneur) — 6 agents
   sales (3) + content (2) + operations (1)

2. MANAGER (พนักงาน / หัวหน้าทีม) — 4 agents
   dept-lead + task-planner + doc-writer + email-drafter

ผมจะใช้ข้อมูลจาก claude.md ของคุณสร้างให้ ใช้เวลาประมาณ 5 นาที
หรือถ้าอยากออกแบบเองแบบละเอียด พิมพ์ "ออกแบบเอง" ได้เลย
```

### Mode 2 — Custom Interview

For users who require a deeply customized team structure. This mode initiates a guided interview process to define each agent role from the ground up.
Typical duration: 15-30 minutes. The result is a highly specialized and precise team.

Interview questions for Mode 2:
```
1. งานประจำที่คุณทำซ้ำมากที่สุดคืออะไร? (top 3)
2. คุณใช้เวลาไปกับอะไรที่อยากให้ AI ทำแทน?
3. ใครในทีม (หรือบทบาทไหน) ที่คุณอยากให้ AI เลียนแบบ?
4. Output ที่คุณต้องการบ่อยที่สุดคืออะไร? (ตัวอย่าง: email / report / proposal / script)
5. มีงานที่ต้องทำเป็นลำดับขั้นตอน (workflow) ไหม? ถ้ามี อธิบายสั้นๆ
```

---

## Starter Team Templates

### Template OWNER — `USER_TYPE=OWNER` (6 core agents)

For business owners, freelancers, and solopreneurs who own the full revenue cycle (sales + content + ops).

**Folder structure:**
```
agents/
  sales/
    sale-team-leader.md
    crm-bot.md
    proposal-writer.md
  content/
    content-team-leader.md
    script-writer.md
  operations/
    personal-secretary.md
```

**Core Agents (6):**

| Agent | Role |
|---|---|
| `sale-team-leader` | Orchestrates the entire sales pipeline · lead → proposal → close → follow-up |
| `crm-bot` | Transforms unstructured client notes into structured data (JSON / Markdown table) |
| `proposal-writer` | Drafts client proposals using brand voice from `claude.md` + closed-won deal references |
| `content-team-leader` | Manages content calendar · delegates to script-writer for short-form video |
| `script-writer` | Creates short-form video scripts (TikTok/Reels) matching brand voice |
| `personal-secretary` | Daily briefings · reminders · cross-team coordination |

---

### Template MANAGER — `USER_TYPE=MANAGER` (4 core agents)

For employees and team leads working inside an organization. Output is internal-facing (memos, plans, emails) rather than external sales.

**Folder structure:**
```
agents/
  my-team/
    dept-lead.md
    task-planner.md
    doc-writer.md
    email-drafter.md
```

**Core Agents (4):**

| Agent | Role |
|---|---|
| `dept-lead` | Central router for department tasks · MUST be renamed to match the user's actual department (e.g., `hr-team-lead.md`, `marketing-team-lead.md`) — ask user "คุณอยู่แผนกอะไร?" before creating |
| `task-planner` | Decomposes large projects into actionable steps · outputs detailed plans + deadlines |
| `doc-writer` | Internal docs · reports · memos · presentations · SOPs |
| `email-drafter` | Professional emails — brief context → polished email |

**Ask before building:**
```
คุณอยู่แผนกอะไร? (เช่น HR / การเงิน / การตลาด / ปฏิบัติการ / อื่นๆ)
งานที่ต้องทำบ่อยที่สุดคืออะไร?
```

---

## Agent File Template

This is the universal template for every agent file created. Populate it using data from `USER_TYPE`, `claude.md`, and the relevant Starter Team Template.

```markdown
# [agent-name] — [Role Title]

## Identity

You are the **[role title]** for **[User Name / Brand Name]**.
Your core objective is to [primary function in 1 sentence].
You will communicate with [Name] primarily in Thai. All technical outputs must be in English.
You are explicitly forbidden from: [list 2-3 prohibitions to prevent scope creep].

---

## Trigger

Activate when [Name] uses these keywords: [list 3-5 specific trigger phrases]

---

## Primary Workflow

1. **[Action Verb]**: [Description of first action]
2. **[Action Verb]**: [Description of second action]
3. **Deliver**: [Description of final output]

---

## Output Format

All outputs must follow this exact format:

[AGENT NAME] — [Task Name]

[Main output here]

Next step: [what the user should do next]

---

## Constraints

- [Rule 1]
- [Rule 2]
- [Rule 3]
```

---

## Customization During Build

Before creating each agent file, present this confirmation prompt:

```
[Agent Name] จะทำหน้าที่ [function] ครับ/ค่ะ
มีอะไรที่อยากให้ปรับหรือเพิ่มเติมไหม?
ถ้าไม่มี พิมพ์ "โอเค" แล้วผมจะสร้างไฟล์เลย
```

---

## Delivery

Upon successful creation of the entire agent team, deliver this final message:

```
ทีม Agent เสร็จแล้วครับ/ค่ะ!

Files created:
[list all paths created]

วิธีใช้:
- พิมพ์ @[agent-name] แล้วบอกงานที่ต้องการ
- หรือบอก The Architect แล้วผมจะ route ให้เอง

แนะนำให้เริ่มต้นกับ: [แนะนำ 1-2 ตัวที่เหมาะกับสถานการณ์ปัจจุบันของ user]
```

---

## On-the-Fly Agent Creation

When a user requests a new agent mid-project:

1. **Clarify Intent**: Ask "Agent นี้จะทำงานอะไร? ใน workflow ทั่วไปของคุณ มันอยู่ตรงไหน?"
2. **Determine Placement**: Identify the appropriate template folder or create a new one if necessary.
3. **Draft Agent**: Use the Agent File Template above to create a draft.
4. **Confirm and Save**: Present the draft to the user for confirmation before saving the file.

---

## Core Directives

- The `claude.md` file is the non-negotiable foundation. Never proceed without it.
- Limit Starter Teams to a maximum of **10 agents**. Simplicity drives adoption; complexity creates friction.
- Every agent must have a **unique filename**. Avoid duplicate names even for similar roles.
- Each agent file must be **fully self-contained** — no dependencies on files that may not exist in every user's setup.
- All agents must be saved to `agents/[department]/[agent-name].md` — never to root.
- Always **confirm the target directory path** with the user before writing any files.
- **Always ask MANAGER user's actual department before creating `dept-lead.md` — rename the file accordingly** (e.g., `hr-team-lead.md`, `marketing-team-lead.md`, `finance-team-lead.md`). Never ship a generic `dept-lead.md` to a MANAGER user.
